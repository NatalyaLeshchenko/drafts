"""Physical right-hand grasp attempt using RGB-D-derived sugar box coordinates."""
import argparse
import json
import math
import time
from pathlib import Path

import numpy as np
import rclpy
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from manipulation import Robot

NAMES = [f'{name}_r_joint' for name in ('shoulder_pitch', 'shoulder_roll', 'shoulder_yaw',
                                       'elbow_pitch', 'elbow_yaw', 'wrist_pitch', 'wrist_roll')]


class Manipulator:
    def __init__(self, robot):
        self.robot = robot
        self.bias = np.zeros(7)
        self.low = np.array([robot.kinematics.limits[n][0] + .025 for n in NAMES])
        self.high = np.array([robot.kinematics.limits[n][1] - .025 for n in NAMES])

    def current(self):
        return np.array([self.robot.joints[n] for n in NAMES])

    def transform(self, angles):
        joints = dict(self.robot.joints)
        joints.update(zip(NAMES, angles))
        return self.robot.kinematics.transform('right_tcp_link', joints)

    def ik(self, position, rotation, preferred=None):
        preferred = self.current() if preferred is None else np.array(preferred)
        def error(angles):
            transform = self.transform(angles)
            return np.r_[transform[:3, 3] - position,
                         .20 * Rotation.from_matrix(rotation.T @ transform[:3, :3]).as_rotvec(),
                         .002 * (angles - preferred)]
        candidates = []
        for initial in [preferred] + [np.random.default_rng(i).uniform(self.low, self.high) for i in range(5)]:
            result = least_squares(error, np.clip(initial, self.low, self.high), bounds=(self.low, self.high), max_nfev=220)
            candidates.append(result)
        valid = [r for r in candidates if np.linalg.norm(error(r.x)[:6]) < .003]
        if not valid:
            raise RuntimeError('Grasp pose is outside the right arm workspace')
        return min(valid, key=lambda r: np.linalg.norm(r.x - preferred)).x

    def cartesian(self, position, rotation, label, speed=.4):
        current = self.current()
        start = self.transform(current)[:3, 3]
        count = max(3, int(np.ceil(np.linalg.norm(position - start) / .012)))
        path = [current]
        for index in range(1, count + 1):
            point = start + (position - start) * index / count
            previous = path[-1]
            def error(angles):
                transform = self.transform(angles)
                return np.r_[transform[:3, 3] - point,
                    .2 * Rotation.from_matrix(rotation.T @ transform[:3, :3]).as_rotvec(),
                    .001 * (angles - previous)]
            solution = least_squares(error, np.clip(previous, self.low, self.high),
                                     bounds=(self.low, self.high), max_nfev=100)
            if np.linalg.norm(error(solution.x)[:6]) > .004:
                raise RuntimeError('Straight-line hand path is unreachable')
            path.append(solution.x)
        self.move(path[-1], label, speed=speed, settle=2.5, path=np.array(path))

    def move(self, goal, label, speed=.55, settle=2.0, path=None):
        robot = self.robot
        begin = self.current()
        if path is None:
            path = np.array([begin, goal])
        duration = max(1., float(np.max(abs(np.diff(path, axis=0)))) * (len(path) - 1) * 1.875 / speed)
        start = previous = robot.sim_time
        wall_deadline = time.monotonic() + 100
        print(f'{label}: {duration:.1f}s sim + settling', flush=True)
        while robot.sim_time - start < duration + settle:
            if time.monotonic() > wall_deadline or time.monotonic() - robot.last_state > 2:
                raise RuntimeError('Arm movement lost simulator feedback or timed out')
            elapsed = robot.sim_time - start
            u = min(1., elapsed / duration)
            blend = u ** 3 * (10 - 15 * u + 6 * u * u)
            progress = blend * (len(path) - 1)
            segment = min(int(progress), len(path) - 2)
            target = path[segment] + (progress - segment) * (path[segment + 1] - path[segment])
            dt = min(.05, max(0., robot.sim_time - previous))
            previous = robot.sim_time
            self.bias = np.clip(self.bias + 1.6 * (target - self.current()) * dt, -.35, .35)
            command = np.clip(target + self.bias, self.low, self.high)
            robot.command('arm', {21 + i: float(value) for i, value in enumerate(command)}, speed=.75)
            robot.spin(.04)
        error = float(np.max(abs(goal - self.current())))
        print(json.dumps({'stage': label, 'joint_error_rad': error,
                          'tcp': self.transform(self.current())[:3, 3].tolist()}), flush=True)
        if error > .12:
            raise RuntimeError('Arm did not reach the planned pose; stopping before grasp')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('approach', 'position', 'close', 'grasp', 'lift', 'inspect', 'shake'))
    parser.add_argument('--side', action='store_true')
    args = parser.parse_args()
    rclpy.init()
    robot = Robot()
    try:
        robot.spin(3)
        if not robot.joints or robot.sim_time is None:
            raise RuntimeError('No robot state')
        arm = Manipulator(robot)
        estimate = json.loads(Path('/nssr_sim/logs/sugar-estimate.json').read_text())
        yaw = np.deg2rad(estimate['angle_deg'] + 90)
        rotation = Rotation.from_euler('z', yaw).as_matrix()
        center = np.array([*estimate['center_xy'], -.065])
        grasp = center - rotation @ np.array([0., .040, -.13])
        preferred = [-.46, -.96, .89, -1.58, .54, -.17, 1.23]
        if args.side:
            angle = np.deg2rad(estimate['angle_deg'])
            short_axis = np.array([np.cos(angle), np.sin(angle), 0.])
            long_axis = np.array([-np.sin(angle), np.cos(angle), 0.])
            rotation = np.column_stack(([0., 0., 1.], short_axis, long_axis))
            center[2] = -.09
            grasp = center - rotation @ np.array([0., .040, -.13])
            preferred = [.52, .01, .40, -1.98, .12, -.10, -1.27]
        if args.stage == 'approach':
            robot.hand([1., 1., 1., 1., .90, .45])
            spread = arm.current()
            spread[1] = -1.0
            arm.move(spread, 'spread arm away from torso')
            fold = spread.copy()
            fold[3] = -1.6
            arm.move(fold, 'raise forearm above the table')
            above = grasp + rotation[:, 2] * .13 + [0., 0., .27] if args.side else grasp + [0., 0., .17]
            goal = arm.ik(above, rotation, preferred)
            arm.move(goal, 'approach above sugar box')
            robot.save('sugar-high-approach')
            if args.side:
                arm.cartesian(grasp + rotation[:, 2] * .13, rotation,
                              'lower beside box on a straight path', speed=.5)
            robot.save('sugar-above')
        elif args.stage in ('grasp', 'position'):
            steps = ((.07, 'approach horizontally from the side'), (0., 'slide open fingers around the box')) if args.side else ((.08, 'lower open hand'), (0., 'position fingers around sugar box'))
            for amount, label in steps:
                position = grasp + rotation[:, 2] * amount if args.side else grasp + [0., 0., amount]
                if args.side:
                    arm.cartesian(position, rotation, label, speed=.30)
                else:
                    goal = arm.ik(position, rotation, preferred)
                    arm.move(goal, label, speed=.30, settle=2.5)
                    preferred = goal
            robot.save('sugar-before-close')
            if args.stage == 'position':
                return
            robot.hand([.25, .25, .25, .25, .35, .12])
            robot.spin(5)
            robot.save('sugar-closed')
        elif args.stage == 'close':
            robot.hand([.25, .25, .25, .25, .35, .12])
            robot.spin(5)
            robot.save('sugar-closed')
        elif args.stage == 'lift':
            goal = arm.ik(grasp + [0., 0., .05], rotation, preferred)
            arm.move(goal, 'lift sugar box', speed=.25, settle=3.)
            robot.save('sugar-lifted')
        elif args.stage == 'inspect':
            goal = arm.ik(np.array([.38, -.12, .23]), rotation, preferred)
            arm.move(goal, 'bring hand into both camera views', speed=.30, settle=3.)
            robot.save('sugar-inspect')
        else:
            base = arm.current()
            arm.move(base, 'stabilize the held box', speed=.4, settle=2.)
            start = previous = robot.sim_time
            deadline = time.monotonic() + 30
            print('Four gentle wrist shakes, amplitude 0.08 rad.', flush=True)
            while robot.sim_time - start < 3.0:
                if time.monotonic() > deadline or time.monotonic() - robot.last_state > 2:
                    raise RuntimeError('Shake lost robot feedback')
                elapsed = robot.sim_time - start
                envelope = min(1., elapsed / .35, (3.0 - elapsed) / .35)
                goal = base.copy()
                goal[6] += .08 * envelope * math.sin(2 * math.pi * elapsed / .75)
                dt = min(.05, max(0., robot.sim_time - previous))
                previous = robot.sim_time
                arm.bias = np.clip(arm.bias + 1.6 * (goal - arm.current()) * dt, -.35, .35)
                command = np.clip(goal + arm.bias, arm.low, arm.high)
                robot.command('arm', {21 + i: float(value) for i, value in enumerate(command)}, speed=.75)
                robot.spin(.025)
            arm.move(base, 'hold still', speed=.5)
            robot.save('sugar-shaken')
    finally:
        robot.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
