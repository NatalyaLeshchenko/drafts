import unittest
from itertools import product
import numpy as np
from payload_tracking import outside_hand,template_support

class TrackingTests(unittest.TestCase):
    def test_robot_hand_does_not_count_as_payload(self):
        hull={'palm':np.array(list(product((-.02,.02),repeat=3)))}
        points=np.array([[0,0,0],[.08,0,0]])
        self.assertEqual(outside_hand(points,hull).tolist(),[False,True])

    def test_supported_visible_template_and_missing_object(self):
        h=w=80;k=np.array([[100,0,40],[0,100,40],[0,0,1.]])
        v,u=np.mgrid[:h,:w];depth=np.full((h,w),1000,np.uint16)
        points=np.stack(((u-40)/100,(v-40)/100,np.ones((h,w))),-1)
        template=points[30:50:2,30:50:2].reshape(-1,3)
        args=(template,{},np.eye(4),np.eye(4),k,depth,points,np.ones((h,w),bool),np.ones((h,w),bool))
        self.assertTrue(template_support(*args)['verified'])
        missing=points.copy();missing[:,:,2]=1.2
        self.assertFalse(template_support(template,{},np.eye(4),np.eye(4),k,depth+200,missing,args[-2],args[-1])['verified'])

if __name__=='__main__':unittest.main()
