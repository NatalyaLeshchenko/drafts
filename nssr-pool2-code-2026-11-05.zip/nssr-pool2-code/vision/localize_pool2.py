"""Localize YOLO detections using saved public RGB-D and timestamped ROS TF."""
import bootstrap
import argparse
import json
from pathlib import Path
import cv2
import numpy as np
from rgbd_geometry import camera_transform,backproject,polygon_mask,fit_table,estimate_object,project


def read_image(path,flags=cv2.IMREAD_COLOR):
    image = cv2.imdecode(np.frombuffer(Path(path).read_bytes(),np.uint8),flags)
    if image is None:
        raise ValueError(f'Cannot decode image: {path}')
    return image


def write_image(path,image):
    ok,data = cv2.imencode(Path(path).suffix,image)
    if not ok:
        raise ValueError(f'Cannot encode image: {path}')
    Path(path).write_bytes(data.tobytes())


def main():
    root = bootstrap.ROOT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--predictions',type=Path,default=root/'predictions_unseen/summary.json')
    parser.add_argument('--output',type=Path,default=root/'localization_unseen')
    args = parser.parse_args()
    prediction = json.loads(args.predictions.read_text(encoding='utf-8'))
    args.output.mkdir(parents=True,exist_ok=True)
    summary = {'coordinate_frame':'pelvis','units':'metres','frames':[],
               'limitations':'Sensor consistency checks only; no object-pose ground truth or verified grasp poses.'}
    for frame in prediction['frames']:
        path = Path(frame['source'])
        camera = path.stem.split('_')[0]
        meta = json.loads((path.parent/'metadata.json').read_text(encoding='utf-8'))
        color_info,depth_info = meta['cameras'][f'{camera}_color'],meta['cameras'][f'{camera}_depth']
        if color_info['frame']!=depth_info['frame'] or (color_info['width'],color_info['height'])!=(depth_info['width'],depth_info['height']):
            raise ValueError('Expected depth aligned to the color optical frame and resolution')
        skew = abs(color_info['stamp']-depth_info['stamp'])
        if skew>.10:
            raise ValueError(f'RGB-depth timestamps too far apart: {path}: {skew}')
        transform = camera_transform(meta,camera)
        image = read_image(path)
        depth = read_image(path.with_name(f'{camera}_depth.png'),cv2.IMREAD_UNCHANGED)
        points,valid = backproject(depth,depth_info,transform)
        masks = [polygon_mask(d['polygon_xy_pixels'],depth.shape) for d in frame['detections']]
        output = {'source':str(path),'seed':meta['seed'],'camera':camera,
            'head_yaw_target':meta['head_yaw_target'],'rgb_depth_skew_s':skew,'objects':[]}
        try:
            plane = fit_table(points,valid,image,masks)
            output['table_plane_pelvis'] = plane
        except ValueError as exc:
            output['error'] = str(exc)
            summary['frames'].append(output)
            continue
        overlay = image.copy()
        for detection,mask in zip(frame['detections'],masks):
            item = {k:detection[k] for k in ('class_id','name','category','confidence')}
            try:
                item.update(estimate_object(points,valid,mask,plane,detection['class_id']))
                xyz = item['surface_contact_candidate_pelvis_m']
                pixel = item['surface_contact_pixel']
                # Independent forward projection catches matrix/order/convention mistakes.
                projected = project(xyz,color_info,transform)
                error = float(np.linalg.norm(np.asarray(projected)-pixel))
                item['reprojection_error_px'] = error
                cv2.polylines(overlay,[np.round(detection['polygon_xy_pixels']).astype(np.int32)],True,(190,120,50),1)
                u,v = map(int,pixel)
                cv2.drawMarker(overlay,(u,v),(0,0,255),cv2.MARKER_CROSS,10,1)
                caption = f'{item["class_id"]}: {xyz[0]:.2f},{xyz[1]:.2f},{xyz[2]:.2f}'
                cv2.putText(overlay,caption,(max(0,u-55),max(13,v-12)),cv2.FONT_HERSHEY_SIMPLEX,.34,(0,0,190),1)
            except ValueError as exc:
                item['error'] = str(exc)
            output['objects'].append(item)
        stem = path.parent.name+'_'+camera
        write_image(args.output/f'{stem}.jpg',overlay)
        (args.output/f'{stem}.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
        summary['frames'].append(output)
        print(f'{stem}: {sum("error" not in x for x in output["objects"])} objects, table/pelvis tilt {plane["tilt_from_pelvis_z_deg"]:.1f} deg',flush=True)
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    central = sorted(args.output.glob('*_view_0_head.jpg'))
    if central:
        write_image(args.output/'overview.jpg',np.vstack([read_image(p) for p in central]))


if __name__=='__main__':
    main()
