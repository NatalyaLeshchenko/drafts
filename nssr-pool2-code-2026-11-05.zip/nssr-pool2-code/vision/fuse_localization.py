"""Fuse sensor estimates within a saved stationary scene; audit repeatability."""
import bootstrap
import argparse
import json
from pathlib import Path
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=bootstrap.ROOT/'localization_unseen/summary.json')
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    groups,errors = {},[]
    for frame in data['frames']:
        for obj in frame.get('objects',[]):
            if 'error' in obj:
                errors.append({'source':frame['source'],'name':obj['name'],'error':obj['error']})
                continue
            key = frame['seed'],obj['name']
            groups.setdefault(key,[]).append((frame,obj))
    report = {'frame':'pelvis','units':'metres','objects':[],'rejected_observations':errors,
        'fusion_assumption':'Objects remain stationary across the saved views grouped by seed; not realtime tracking.',
        'absolute_accuracy_verified':False,'robot_motion_performed':False}
    for (seed,name),values in groups.items():
        usable = [(f,o) for f,o in values if not o['warnings'] and o['depth_samples']>=50]
        candidates = usable or values
        # Partial silhouettes do not support a trustworthy body center.
        quality = lambda pair: pair[1]['confidence']*min(1,pair[1]['depth_samples']/250)*pair[1]['largest_depth_component_fraction']*(1.1 if pair[0]['camera']=='head' else 1)
        best_frame,best = max(candidates,key=quality)
        centers = np.array([o['approximate_body_center_pelvis_m'] for _,o in candidates])
        median = np.median(centers,axis=0)
        distances = np.linalg.norm(centers-median,axis=1)
        inliers = distances<.02
        center = np.median(centers[inliers],axis=0) if inliers.any() else median
        spread = float(np.max(np.linalg.norm(centers-center,axis=1)))
        pairwise = float(np.max(np.linalg.norm(centers[:,None,:]-centers[None,:,:],axis=-1)))
        yaws = [o['yaw_deg_mod_180'] for _,o in candidates if o['yaw_deg_mod_180'] is not None]
        yaw_mean,yaw_spread = None,None
        if yaws:
            radians = np.deg2rad(np.array(yaws)*2)
            yaw_mean = float(np.rad2deg(np.arctan2(np.sin(radians).mean(),np.cos(radians).mean()))/2)
            yaw_spread = float(max(abs((v-yaw_mean+90)%180-90) for v in yaws))
        head = np.array([o['approximate_body_center_pelvis_m'] for f,o in usable if f['camera']=='head'])
        head_pairwise = float(np.max(np.linalg.norm(head[:,None,:]-head[None,:,:],axis=-1))) if len(head)>1 else None
        stable = len(usable)>=2 and spread<.02
        orientation_stable=yaw_spread is None or yaw_spread<=10
        item = {'seed':seed,'name':name,'class_id':best['class_id'],'category':best['category'],
            'approximate_body_center_pelvis_m':center.tolist(),
            'surface_contact_candidate_pelvis_m':best['surface_contact_candidate_pelvis_m'],
            'surface_contact_source':best_frame['source'],
            'visible_grasp_surface_pelvis_m':best.get('visible_grasp_surface_pelvis_m',[]),
            'local_grasp_patches':best.get('local_grasp_patches',[]),
            'surface_contact_pixel':best['surface_contact_pixel'],
            'visible_footprint_dimensions_m':best['visible_footprint_dimensions_m'],
            'height_above_observed_table_m':best['height_above_observed_table_m'],
            'yaw_deg_mod_180':yaw_mean,'yaw_max_deviation_deg':yaw_spread,
            'support_normal_pelvis':best['support_normal_pelvis'],
            'upright_container_candidate':best['upright_container_candidate'],
            'total_observations':len(values),'usable_observations':len(usable),
            'head_view_pairwise_spread_m':head_pairwise,'all_view_pairwise_spread_m':pairwise,
            'max_center_deviation_m':spread,'repeatability_check_passed':bool(stable),
            'orientation_repeatability_check_passed':bool(orientation_stable),
            'motion_authorized':False,
            'status':'ready_for_grasp_planning_not_a_verified_grasp' if stable else 'needs_additional_observation'}
        report['objects'].append(item)
    values = [o['head_view_pairwise_spread_m'] for o in report['objects'] if o['head_view_pairwise_spread_m'] is not None]
    report['metrics'] = {'object_instances':len(report['objects']),
        'repeatability_passed':sum(o['repeatability_check_passed'] for o in report['objects']),
        'max_head_pairwise_spread_m':max(values) if values else None,
        'max_all_view_pairwise_spread_m':max((o['all_view_pairwise_spread_m'] for o in report['objects']),default=None)}
    output = args.input.parent/'objects_fused.json'
    output.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report['metrics'],indent=2))
    print(f'Saved: {output}')


if __name__=='__main__':
    main()
