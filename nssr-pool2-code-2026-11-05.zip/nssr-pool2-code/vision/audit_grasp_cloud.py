"""Compare observed object surfaces with the actual TCP, without simulator object poses."""
import bootstrap,json,argparse
from pathlib import Path
import cv2,numpy as np
from ultralytics import YOLO
from rgbd_geometry import backproject,polygon_mask
parser=argparse.ArgumentParser();parser.add_argument('--logs',type=Path);args=parser.parse_args()
root=args.logs or bootstrap.ROOT.parent/'nssr-uwt-polygon/logs'
plan=json.loads((root/'pool2-grasp-plan.json').read_text())['selected']
model=YOLO(json.loads((bootstrap.ROOT/'training_report.json').read_text())['weights'])
result=[]
for stage in ('position','closed','lift','held'):
    prefix='pool2-'+stage
    meta=json.loads((root/(prefix+'.json')).read_text());grip=json.loads((root/(prefix+'-grip.json')).read_text())
    inverse=np.linalg.inv(np.array(grip['tcp']));depths=np.load(root/(prefix+'-depth.npz'))
    for camera,cam in meta['cameras'].items():
        im=cv2.imdecode(np.frombuffer((root/f'{prefix}-{camera}_color.png').read_bytes(),np.uint8),1)
        d=depths[camera+'_depth'];p,valid=backproject(d,{'K':cam['k'],'height':d.shape[0],'width':d.shape[1]},np.array(cam['transform']))
        prediction=model(im,verbose=False,conf=.15,retina_masks=True)[0]
        for i,box in enumerate(prediction.boxes):
            if int(box.cls.item())!=plan['target']['class_id'] or prediction.masks is None:continue
            mask=polygon_mask(prediction.masks.xy[i],d.shape)&valid
            cloud=p[mask]@inverse[:3,:3].T+inverse[:3,3]
            result.append({'stage':stage,'camera':camera,'n':len(cloud),'confidence':float(box.conf.item()),
                           'surface_quantiles_tcp':np.percentile(cloud,[10,50,90],axis=0).tolist()})
print(json.dumps(result,indent=2))
(root/'pool2-grasp-cloud-audit.json').write_text(json.dumps(result,indent=2))
