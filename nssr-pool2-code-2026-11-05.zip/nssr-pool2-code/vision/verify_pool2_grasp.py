"""Verify a container lift using its colored label in public RGB-D, not hand motion alone."""
import bootstrap
import json
from pathlib import Path
import cv2
import numpy as np
from scipy.spatial.transform import Rotation
from ultralytics import YOLO
from rgbd_geometry import backproject,fit_table,polygon_mask,project
from payload_tracking import outside_hand


def main():
    root=bootstrap.ROOT
    logs=root.parent/'nssr-uwt-polygon/logs'
    model=YOLO(json.loads((root/'training_report.json').read_text())['weights'])
    plan=json.loads((logs/'pool2-grasp-plan.json').read_text())['selected']
    appearance={'beta_glucan':(5,90,135,65,35),'marc_anthony':(3,18,50,45,60),'wilton':(4,12,40,60,50),
                'deskstar':(0,0,180,0,160),'razer_mouse':(1,0,180,0,0),'rocksmith_cable':(2,0,180,0,0)}
    if plan['object'] not in appearance:
        raise RuntimeError('No independent label appearance verifier for this object')
    class_id,hue_low,hue_high,saturation_min,value_min=appearance[plan['object']]
    stages=('pool2-before-grasp','pool2-closed','pool2-lift','pool2-held')
    report={'object':plan['object'],'planning_sim_time':plan['planning_sim_time'],
        'method':'YOLO association + colored label depth + wrist/hand feedback','stages':{}}
    for label in stages:
        path=logs/f'{label}.json'
        if not path.exists():
            continue
        meta=json.loads(path.read_text())
        grip=json.loads((logs/f'{label}-grip.json').read_text())
        if grip['plan']['planning_sim_time']!=plan['planning_sim_time']:
            continue
        depth_arrays=np.load(logs/f'{label}-depth.npz')
        observed={}
        for camera,cam in meta['cameras'].items():
            image=cv2.imdecode(np.frombuffer((logs/f'{label}-{camera}_color.png').read_bytes(),np.uint8),cv2.IMREAD_COLOR)
            depth=depth_arrays[f'{camera}_depth']
            info={'K':cam['k'],'D':[0.]*5,'height':depth.shape[0],'width':depth.shape[1]}
            transform=np.array(cam['transform'])
            points,valid=backproject(depth,info,transform)
            result=model(image,device=0,conf=.25,imgsz=640,retina_masks=True,verbose=False)[0]
            matches=[i for i,b in enumerate(result.boxes) if int(b.cls.item())==class_id]
            masks=[polygon_mask(poly,depth.shape) for poly in result.masks.xy] if result.masks is not None else []
            plane=fit_table(points,valid,image,masks)
            # Associate by projected sensor-derived center. No fixed image ROI.
            expected=np.array(plan['target']['approximate_body_center_pelvis_m'])
            if label in ('pool2-lift','pool2-held'):
                expected+=np.array(plan['target']['support_normal_pelvis'])*plan.get('lift_distance_m',.06)
            uv=np.array(project(expected,info,transform))
            hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
            blue=(hsv[...,0]>=hue_low)&(hsv[...,0]<=hue_high)&(hsv[...,1]>saturation_min)&(hsv[...,2]>value_min)
            electronics=plan['target']['category']=='electronics'
            whole_object=electronics or plan.get('grasp_mode')=='top'
            if electronics:
                blue=(hsv[...,1]<65)&((hsv[...,2]>160) if class_id==0 else (hsv[...,2]<90))
            if plan.get('grasp_mode')=='top':blue=np.ones(depth.shape,bool)
            region=np.zeros(depth.shape,np.uint8)
            cv2.circle(region,tuple(np.round(uv).astype(int)),65,1,-1)
            # Appearance is independent of the robot's gray fingers; do not use their depth as lift evidence.
            if matches:
                index=max(matches,key=lambda i:float(result.boxes[i].conf.item()))
                semantic=cv2.dilate(masks[index].astype(np.uint8),np.ones((7,7),np.uint8)).astype(bool)
                selected=blue&valid&region.astype(bool)&semantic
            else:
                selected=blue&valid&region.astype(bool)
                if whole_object: selected[:]=False
            n=np.array(plane['normal']); height_map=points@n+plane['offset']
            selected&=(height_map>.012)&(height_map<.30)
            if grip.get('hand_hulls_tcp'):
                tcp=np.array(grip['tcp'])
                coords=np.column_stack(np.where(selected))
                keep=outside_hand((points[selected]-tcp[:3,3])@tcp[:3,:3],grip['hand_hulls_tcp'])
                removed=coords[~keep]
                if len(removed):selected[removed[:,0],removed[:,1]]=False
            cloud=points[selected]
            # Reject any other blue surface outside the target's observed neighbourhood.
            if len(cloud):
                xy_delta=cloud[:,:2]-expected[:2]
                good=np.linalg.norm(xy_delta,axis=1)<.065
                coords=np.column_stack(np.where(selected))[good]
                cloud=cloud[good]
                selected[:]=False
                if len(coords):
                    selected[coords[:,0],coords[:,1]]=True
            overlay=image.copy(); overlay[selected]=(255,60,255)
            cv2.imwrite(str(logs/f'{label}-{camera}-label-verification.jpg'),overlay)
            observed[camera]={'label_depth_pixels':int(len(cloud)),'detector_found_target':bool(matches)}
            if len(cloud)>=12:
                heights=cloud@n+plane['offset']
                observed[camera].update(median_label_height_m=float(np.median(heights)),
                    median_label_point_pelvis_m=np.median(cloud,axis=0).tolist(),
                    p90_label_height_m=float(np.quantile(heights,.9)))
        report['stages'][label]={'cameras':observed,'hand':grip['hand'],'wrist_force':grip['wrist_force']}
    base=report['stages'].get('pool2-before-grasp' if plan['target']['category']=='electronics' or plan.get('grasp_mode')=='top' else 'pool2-closed')
    lifted=report['stages'].get('pool2-lift')
    held=report['stages'].get('pool2-held')
    comparisons={}
    if base and lifted:
        for camera,b in base['cameras'].items():
            l=lifted['cameras'].get(camera,{})
            h=held['cameras'].get(camera,{}) if held else {}
            if 'median_label_height_m' in b and 'median_label_height_m' in l:
                rise=l['median_label_height_m']-b['median_label_height_m']
                retained=h.get('median_label_height_m',-1)-b['median_label_height_m']
                comparisons[camera]={'label_rise_m':rise,'held_label_rise_m':retained,
                    'lift_verified':rise>.030,'retention_verified':retained>.030}
    report['camera_comparisons']=comparisons
    report['lift_verified']=any(c['lift_verified'] for c in comparisons.values())
    report['retention_verified']=any(c['retention_verified'] for c in comparisons.values())
    if lifted and 'pool2-before-grasp' in report['stages']:
        f0=report['stages']['pool2-before-grasp']['wrist_force']; f1=lifted['wrist_force']
        if all(k in f0 and k in f1 for k in ('x','y','z')):
            report['wrist_force_change_N']=float(np.linalg.norm([f1[k]-f0[k] for k in ('x','y','z')]))
    report['success']=any(c['lift_verified'] and c['retention_verified'] for c in comparisons.values())
    if plan['target']['category']=='electronics' or plan.get('grasp_mode')=='top':
        hand=held.get('hand',{}) if held else {}
        contact=max(hand.get('effort',[0]))>.15
        load=report.get('wrist_force_change_N',0)>.3
        report['contact_and_load_verified']=bool(contact and load)
        report['success']=bool(report['success'] and contact and load)
    (logs/'pool2-grasp-verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
