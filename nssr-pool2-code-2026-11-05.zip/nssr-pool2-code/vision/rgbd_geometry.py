"""Sensor-only RGB-D geometry. Coordinates are metres in the pelvis frame."""
import cv2
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components


def camera_transform(metadata, camera):
    pose = metadata['transforms'][camera]
    if pose['target'] != 'pelvis':
        raise ValueError('Expected transform into pelvis')
    transform = np.eye(4)
    transform[:3,:3] = Rotation.from_quat(pose['quaternion_xyzw']).as_matrix()
    transform[:3,3] = pose['translation']
    return transform


def backproject(depth_mm, camera_info, transform):
    if depth_mm.dtype != np.uint16:
        raise ValueError('Expected 16-bit depth in millimetres')
    height,width = depth_mm.shape
    if (height,width) != (camera_info['height'],camera_info['width']):
        raise ValueError('Camera dimensions do not match depth')
    v,u = np.mgrid[:height,:width]
    intrinsic = np.asarray(camera_info['K'],float).reshape(3,3)
    distorted = np.stack((u,v),-1).astype(np.float64).reshape(-1,1,2)
    undistorted = cv2.undistortPoints(distorted,intrinsic,np.asarray(camera_info.get('D',[0]*5),float)).reshape(height,width,2)
    # Public stream is distance_to_image_plane: optical-axis Z, not radial range.
    rays = np.dstack((undistorted,np.ones((height,width))))
    local = rays * (depth_mm[...,None]/1000.)
    points = local @ transform[:3,:3].T + transform[:3,3]
    valid = (depth_mm>=150) & (depth_mm<=6000)
    return points,valid


def polygon_mask(polygon,shape):
    result = np.zeros(shape,np.uint8)
    polygon = np.asarray(polygon,float)
    if polygon.ndim != 2 or polygon.shape[0]<3 or polygon.shape[1]!=2 or not np.all(np.isfinite(polygon)):
        return result.astype(bool)
    polygon = np.clip(polygon,[0,0],[shape[1]-1,shape[0]-1])
    cv2.fillPoly(result,[np.round(polygon).astype(np.int32)],1)
    return result.astype(bool)


def fit_table(points,valid,image,object_masks):
    hsv = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    candidates = valid & (hsv[...,1]<35) & (hsv[...,2]>100) & (hsv[...,2]<245)
    candidates[:80] = False
    candidates[-25:] = False
    for mask in object_masks:
        candidates &= ~cv2.dilate(mask.astype(np.uint8),np.ones((9,9),np.uint8)).astype(bool)
    samples = points[candidates]
    if len(samples)<300:
        raise ValueError('Insufficient unoccluded table depth')
    rng = np.random.default_rng(27)
    subset = samples[rng.choice(len(samples),min(1800,len(samples)),replace=False)]
    best = None
    for _ in range(160):
        a,b,c = subset[rng.choice(len(subset),3,replace=False)]
        normal = np.cross(b-a,c-a)
        length = np.linalg.norm(normal)
        if length<1e-8:
            continue
        normal /= length
        if normal[2]<0:
            normal = -normal
        if normal[2]<.85:
            continue
        offset = -normal@a
        inliers = np.abs(subset@normal+offset)<.006
        score = int(inliers.sum())
        if best is None or score>best[0]:
            best = score,normal,offset
    if best is None or best[0]<.25*len(subset):
        raise ValueError('No dominant approximately horizontal table plane')
    normal,offset = best[1:]
    for _ in range(3):
        inliers = np.abs(samples@normal+offset)<.008
        selected = samples[inliers]
        center = selected.mean(0)
        _,_,vt = np.linalg.svd(selected-center,full_matrices=False)
        normal = vt[-1]
        if normal[2]<0:
            normal = -normal
        offset = -normal@center
    residual = np.abs(selected@normal+offset)
    return {'normal':normal.tolist(),'offset':float(offset),'inliers':int(len(selected)),
        'median_residual_m':float(np.median(residual)),
        'tilt_from_pelvis_z_deg':float(np.rad2deg(np.arccos(np.clip(normal[2],-1,1))))}


def project(point, camera_info, transform):
    local = transform[:3,:3].T @ (np.asarray(point)-transform[:3,3])
    if local[2]<=0:
        return None
    k = np.asarray(camera_info['K'],float).reshape(3,3)
    pixels,_ = cv2.projectPoints(local.reshape(1,1,3),np.zeros(3),np.zeros(3),k,
        np.asarray(camera_info.get('D',[0]*5),float))
    return pixels[0,0].tolist()


def estimate_object(points,valid,mask,plane,cls):
    normal = np.asarray(plane['normal'])
    height_map = points@normal+plane['offset']
    clean = cv2.erode(mask.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
    selected = clean & valid & (height_map>.009) & (height_map<.5)
    cloud = points[selected]
    if len(cloud)<25:
        raise ValueError('Fewer than 25 foreground depth samples')
    # Reject isolated depth spikes without inventing object dimensions.
    distances,_ = cKDTree(cloud).query(cloud,k=min(8,len(cloud)))
    mean = distances[:,1:].mean(1)
    limit = max(.012,float(np.median(mean)+4*np.median(np.abs(mean-np.median(mean)))))
    keep = mean<limit
    coordinates = np.column_stack(np.where(selected))[keep]
    cloud = cloud[keep]
    if len(cloud)<25:
        raise ValueError('Insufficient connected depth samples after filtering')
    # A segmentation contour can contain a second object at a different depth.
    # Keep a connected surface rather than averaging these two objects together.
    neighbors,indices = cKDTree(cloud).query(cloud,k=min(8,len(cloud)))
    row = np.repeat(np.arange(len(cloud)),indices.shape[1])
    col = indices.ravel()
    close = neighbors.ravel()<.015
    graph = csr_matrix((np.ones(int(close.sum())),(row[close],col[close])),shape=(len(cloud),len(cloud)))
    _,labels = connected_components(graph,directed=False)
    counts = np.bincount(labels)
    component = labels==int(np.argmax(counts))
    component_fraction = float(component.mean())
    cloud,coordinates = cloud[component],coordinates[component]
    if len(cloud)<25:
        raise ValueError('Largest connected surface has fewer than 25 depth samples')
    heights = cloud@normal+plane['offset']
    # Visible-surface footprint. This is not a complete object mesh or true COM.
    height = float(np.quantile(heights,.95))
    footprint_cloud=cloud
    if height<.09:
        body=heights>max(.015,.55*height)
        if int(body.sum())>=50:footprint_cloud=cloud[body]
    footprint_heights=footprint_cloud@normal+plane['offset']
    projected = footprint_cloud-footprint_heights[:,None]*normal
    rectangle = cv2.minAreaRect(projected[:,:2].astype(np.float32))
    xy = np.asarray(rectangle[0],float)
    a,b = rectangle[1]
    yaw = float(rectangle[2] + (90 if a<b else 0))
    yaw = (yaw+90)%180-90
    low,high = sorted((float(a),float(b)))
    table_z = float(-(plane['offset']+normal[0]*xy[0]+normal[1]*xy[1])/normal[2])
    # A visible contact pixel must have depth and lie on the object, never in a coil hole.
    support = np.array([*xy,table_z])
    approximate_center = support+normal*height/2
    desired = support+normal*height*.65
    score = np.linalg.norm(cloud[:,:2]-desired[:2],axis=1) + .25*np.abs(cloud[:,2]-desired[2])
    index = int(np.argmin(score))
    contact = cloud[index]
    pixel = coordinates[index][::-1]
    surface_center = np.median(cloud,axis=0)
    _,_,vt = np.linalg.svd(cloud-cloud.mean(0),full_matrices=False)
    axis = vt[0]
    if axis[2]<0:
        axis = -axis
    standing = cls in (3,4,5) and height>1.25*max(high,.015)
    if standing:
        yaw_value = None
        yaw_reason = 'upright container: rotation around its vertical axis is not reliably observable'
    elif high/max(low,.001)<1.3 or cls==2:
        yaw_value = None
        yaw_reason = 'near-symmetric footprint or coil: no unique planar orientation'
    else:
        yaw_value = yaw
        yaw_reason = 'long axis of visible XY footprint, modulo 180 degrees'
    orientation = None
    if yaw_value is not None:
        angle = np.deg2rad(yaw_value)
        x_axis = np.array([np.cos(angle),np.sin(angle),0.])
        x_axis[2] = -(normal[0]*x_axis[0]+normal[1]*x_axis[1])/normal[2]
        x_axis /= np.linalg.norm(x_axis)
        y_axis = np.cross(normal,x_axis)
        orientation = Rotation.from_matrix(np.column_stack((x_axis,y_axis,normal))).as_quat().tolist()
    border = bool(mask[:2].any() or mask[-2:].any() or mask[:,:2].any() or mask[:,-2:].any())
    warnings = []
    if border:
        warnings.append('truncated_by_image_border')
    if component_fraction<.8:
        warnings.append('mask_contains_multiple_disconnected_depth_surfaces')
    return {'visible_grasp_surface_pelvis_m':cloud[::max(1,int(np.ceil(len(cloud)/1200)))].tolist() if cls==2 else [],
        'local_grasp_patches':__import__('local_grasp_geometry').loop_patches(cloud,support,normal) if cls==2 else [],
        'visible_surface_center_pelvis_m':surface_center.tolist(),
        'approximate_body_center_pelvis_m':approximate_center.tolist(),
        'surface_contact_candidate_pelvis_m':contact.tolist(), 'surface_contact_pixel':pixel.tolist(),
        'visible_footprint_dimensions_m':[low,high],'height_above_observed_table_m':height,
        'yaw_deg_mod_180':yaw_value,'yaw_interpretation':yaw_reason,
        'support_normal_pelvis':normal.tolist(),
        'approximate_orientation_quaternion_xyzw':orientation,
        'orientation_assumption':'object rests on observed table; yaw ambiguous by 180 degrees',
        'visible_principal_axis_pelvis':axis.tolist(),'upright_container_candidate':bool(standing),
        'table_z_at_object_m':table_z,'depth_samples':int(len(cloud)),
        'largest_depth_component_fraction':component_fraction,
        'warnings':warnings,'motion_authorized':False,
        'pose_status':'partial_surface_estimate_not_verified_grasp_pose'}
