"""Verify target identity near the measured carried-payload pose after a stage."""
import bootstrap,argparse,json
import cv2
import numpy as np
from ultralytics import YOLO
from rgbd_geometry import backproject,polygon_mask
from payload_tracking import template_support,outside_hand

parser=argparse.ArgumentParser();parser.add_argument('stage',choices=('raise','transfer','inspection'));args=parser.parse_args()
logs=bootstrap.ROOT.parent/'nssr-uwt-polygon/logs';prefix='pool2-delivery-'+args.stage
grasp=json.loads((logs/'pool2-grasp-plan.json').read_text())['selected']
payload=json.loads((logs/'pool2-held-payload.json').read_text())
state=json.loads((logs/(prefix+'-state.json')).read_text())
if state.get('planning_sim_time')!=grasp['planning_sim_time'] or payload['planning_sim_time']!=grasp['planning_sim_time']:
    raise RuntimeError('Stale carry observation')
tcp=np.array(state['tcp']);expected=tcp[:3,:3]@np.array(payload['center_in_tcp_m'])+tcp[:3,3]
radius=max(.065,float(np.linalg.norm(payload['visible_dimensions_m']))/2+.025)
meta=json.loads((logs/(prefix+'.json')).read_text());depths=np.load(logs/(prefix+'-depth.npz'))
model=YOLO(json.loads((bootstrap.ROOT/'training_report.json').read_text())['weights']);observed={}
for camera,cam in meta['cameras'].items():
    image=cv2.imdecode(np.frombuffer((logs/f'{prefix}-{camera}_color.png').read_bytes(),np.uint8),1)
    depth=depths[camera+'_depth'];points,valid=backproject(depth,{'K':cam['k'],'height':depth.shape[0],'width':depth.shape[1]},np.array(cam['transform']))
    result=model(image,conf=.2,retina_masks=True,verbose=False,device=0)[0]
    hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    color=np.ones(depth.shape,bool)
    if grasp['target']['category']=='electronics':color=(hsv[...,1]<100)&((hsv[...,2]>150) if grasp['target']['class_id']==0 else (hsv[...,2]<110))
    tracking=template_support(payload['points_in_tcp_m'],state.get('hand_hulls_tcp',{}),tcp,np.array(cam['transform']),cam['k'],depth,points,valid,color) if state.get('hand_hulls_tcp') else {'verified':False}
    observed[camera+'_geometry']=tracking
    if result.masks is None:continue
    for i,box in enumerate(result.boxes):
        if int(box.cls.item())!=grasp['target']['class_id']:continue
        mask=polygon_mask(result.masks.xy[i],depth.shape)&valid
        cloud=points[mask]
        if state.get('hand_hulls_tcp'):
            cloud=cloud[outside_hand((cloud-tcp[:3,3])@tcp[:3,:3],state['hand_hulls_tcp'])]
        if len(cloud)<40:continue
        distance=np.linalg.norm(cloud-expected,axis=1)
        fraction=float(np.mean(distance<radius))
        error=float(np.linalg.norm(np.median(cloud,axis=0)-expected))
        observed[camera]={'pixels':len(cloud),'fraction_near_payload':fraction,'median_error_m':error,
                          'verified':fraction>.55 and error<radius}
report={'planning_sim_time':grasp['planning_sim_time'],'object':grasp['object'],'stage':args.stage,'observations':observed,
        'success':any(v['verified'] for v in observed.values())}
(logs/f'pool2-carry-{args.stage}-verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
if not report['success']:raise SystemExit(2)
