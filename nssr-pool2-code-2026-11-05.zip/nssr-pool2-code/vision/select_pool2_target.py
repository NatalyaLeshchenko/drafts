"""Select a supported unsorted object from fresh camera localization."""
import argparse,json
from pathlib import Path
import numpy as np
from sorting_order import order_key

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--allow-experimental',action='store_true')
parser.add_argument('--all-objects',action='store_true')
parser.add_argument('--order',choices=('right-to-left','left-to-right','height'),default='right-to-left')
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
latest=Path((root/'vision/latest_observation.txt').read_text(encoding='utf-8-sig').strip())
data=json.loads((latest/'objects_fused.json').read_text())
task=json.loads((root/'nssr-uwt-polygon/logs/pool2-delivery-task.json').read_text())
tray=json.loads((root/'nssr-uwt-polygon/logs/pool2-tray-target.json').read_text())
trays={tray['tray']:tray}
for path in (root/'nssr-uwt-polygon/logs').glob('pool2-tray_*-target.json'):
    measured=json.loads(path.read_text());trays[measured['tray']]=measured
n=np.array(tray['support_normal_pelvis']);floor=np.array(tray['center_floor_pelvis_m'])
ex=np.array([1.,0,0]);ex-=n*(ex@n);ex/=np.linalg.norm(ex);ey=np.cross(n,ex)
profiles={'marc_anthony':{'side':'auto','palm_roll':'auto','experimental':False},
          'wilton':{'side':'auto','palm_roll':'auto','experimental':True}}
if args.all_objects:
    profiles.update({name:{'side':'auto','palm_roll':'auto','experimental':True} for name in ('deskstar','beta_glucan','razer_mouse','rocksmith_cable')})
considered=[];available=[]
for obj in data['objects']:
    name=obj['name'];p=np.array(obj['approximate_body_center_pelvis_m']);delta=p-floor
    in_tray=False;in_tray_name=None
    for measured in trays.values():
        tn=np.array(measured['support_normal_pelvis']);tx=np.array([1.,0,0]);tx-=tn*(tx@tn);tx/=np.linalg.norm(tx);ty=np.cross(tn,tx)
        d=p-np.array(measured['center_floor_pelvis_m'])
        if abs(d@tx)<.11 and abs(d@ty)<.16 and 0.<d@tn<.45:in_tray=True;in_tray_name=measured['tray']
    profile=profiles.get(name)
    reason='candidate'
    if in_tray:reason='already_in_destination_footprint' if in_tray_name==task['categories'][obj['category']] else 'wrong_destination_recovery_required'
    elif not obj['repeatability_check_passed']:reason='inconsistent_localization'
    elif not profile:reason='no_supported_grasp_profile'
    elif profile['experimental'] and not args.allow_experimental:reason='experimental_profile_disabled'
    record={'object':name,'reason':reason,'position_pelvis_m':p.tolist(),'height_m':obj['height_above_observed_table_m']}
    considered.append(record)
    if reason=='candidate':
        candidate={'object':name,**profile}
        if name=='marc_anthony' and obj['height_above_observed_table_m']<.065:candidate.update(side='auto',palm_roll='auto')
        available.append(candidate)
by_name={obj['name']:obj for obj in data['objects']}
for item in available:
    obj=by_name[item['object']]
    item['height_m']=obj['height_above_observed_table_m']
    item['lateral_position_m']=obj['approximate_body_center_pelvis_m'][1]
available.sort(key=lambda p:order_key(by_name[p['object']],args.order))
table_order=sorted([r for r in considered if r['reason']!='already_in_destination_footprint'],key=lambda r:order_key(by_name[r['object']],args.order))
blocker=table_order[0] if table_order and table_order[0]['reason']!='candidate' else None
out={'blocked_edge':blocker,'table_order':table_order,'order':args.order,'observation':str(latest),'selected':available[0] if available and blocker is None else None,'candidates':available,'considered':considered,
     'limitations':'Tray footprint membership is an estimate, not the official judge. Spatial order in robot frame; infeasible swept approaches must be rejected by planner.'}
(root/'nssr-uwt-polygon/logs/pool2-next-target.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
