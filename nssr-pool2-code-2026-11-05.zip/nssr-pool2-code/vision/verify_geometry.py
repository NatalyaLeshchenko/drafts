"""Independent geometric checks with known synthetic camera/plane/surface coordinates."""
import numpy as np
from rgbd_geometry import backproject,project,fit_table,estimate_object


def main():
    info = {'width':640,'height':360,'K':[343.,0.,320.,0.,343.,180.,0.,0.,1.],'D':[0.]*5}
    transform = np.eye(4)
    transform[:3,:3] = np.diag([1.,-1.,-1.])
    transform[:3,3] = [.2,.1,.7]
    depth = np.full((360,640),900,np.uint16)
    depth[0,0]=0; depth[0,1]=7000
    points,valid = backproject(depth,info,transform)
    np.testing.assert_allclose(points[180,320],[.2,.1,-.2],atol=1e-12)
    np.testing.assert_allclose(project([.2,.1,-.2],info,transform),[320.,180.],atol=1e-10)
    assert not valid[0,0] and not valid[0,1]
    yy,xx = np.mgrid[:360,:640]
    radius = np.hypot(xx-320,yy-220)
    mask = (radius>18)&(radius<30)
    depth[mask]=800
    points,valid = backproject(depth,info,transform)
    image = np.full((360,640,3),170,np.uint8)
    plane = fit_table(points,valid,image,[mask])
    np.testing.assert_allclose(plane['normal'],[0,0,1],atol=1e-8)
    np.testing.assert_allclose(plane['offset'],.2,atol=1e-8)
    # A filled detection polygon contains the ring hole; hole depth is still table.
    filled = radius<30
    obj = estimate_object(points,valid,filled,plane,2)
    u,v = obj['surface_contact_pixel']
    assert depth[v,u]==800, 'Contact candidate must lie on the surface, not inside the hole'
    np.testing.assert_allclose(obj['surface_contact_candidate_pelvis_m'][2],-.1,atol=1e-8)
    np.testing.assert_allclose(obj['height_above_observed_table_m'],.1,atol=1e-8)
    assert obj['yaw_deg_mod_180'] is None
    assert obj['approximate_orientation_quaternion_xyzw'] is None
    print('PASS: metre/mm units, optical-axis depth, rigid transform, invalid depth, table plane, coil-hole exclusion, ambiguous yaw')


if __name__=='__main__':
    main()
