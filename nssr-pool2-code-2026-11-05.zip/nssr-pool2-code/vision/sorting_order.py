"""Spatial order in pelvis coordinates: +Y is robot left, -Y robot right."""
def order_key(obj,order='right-to-left'):
    y=float(obj['approximate_body_center_pelvis_m'][1])
    if order=='right-to-left':return (y,-float(obj['height_above_observed_table_m']))
    if order=='left-to-right':return (-y,-float(obj['height_above_observed_table_m']))
    if order=='height':return (-float(obj['height_above_observed_table_m']),-abs(y))
    raise ValueError('Unknown sorting order')
