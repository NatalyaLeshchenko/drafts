"""RGB-D template support excluding robot hand surfaces; no simulator object state."""
import numpy as np
from scipy.spatial import ConvexHull,cKDTree


def outside_hand(points_tcp,hulls,margin=.006):
    keep=np.ones(len(points_tcp),bool)
    for vertices in hulls.values():
        vertices=np.asarray(vertices);low=vertices.min(0)-margin;high=vertices.max(0)+margin
        near=keep&np.all((points_tcp>=low)&(points_tcp<=high),axis=1)
        if not near.any():continue
        equations=ConvexHull(vertices).equations
        inside=(points_tcp[near]@equations[:,:3].T+equations[:,3]).max(axis=1)<margin
        indices=np.flatnonzero(near);keep[indices[inside]]=False
    return keep


def template_support(template_tcp,hulls,tcp,camera,k,depth,points,valid,appearance):
    template=np.asarray(template_tcp);tcp=np.asarray(tcp);camera=np.asarray(camera);k=np.asarray(k).reshape(3,3)
    template=template[outside_hand(template,hulls)]
    world=template@tcp[:3,:3].T+tcp[:3,3]
    optical=(world-camera[:3,3])@camera[:3,:3]
    uv=optical@k.T;uv=uv[:,:2]/np.maximum(optical[:,2:3],1e-6)
    pixel=np.rint(uv).astype(int);h,w=depth.shape
    on=(optical[:,2]>.05)&(pixel[:,0]>=0)&(pixel[:,0]<w)&(pixel[:,1]>=0)&(pixel[:,1]<h)
    indices=np.flatnonzero(on)
    z=depth[pixel[on,1],pixel[on,0]]/1000.
    # Surfaces in front can occlude the object; missing surfaces behind do not.
    visible=(z>.05)&(z>=optical[on,2]-.015)
    world=world[indices[visible]]
    observed=points[valid&appearance]
    if len(world)<20 or not len(observed):return {'verified':False,'visible_template_points':len(world),'matched_template_points':0}
    center=world.mean(0);observed=observed[np.linalg.norm(observed-center,axis=1)<.30]
    in_tcp=(observed-tcp[:3,3])@tcp[:3,:3]
    observed=observed[outside_hand(in_tcp,hulls)]
    if not len(observed):return {'verified':False,'visible_template_points':len(world),'matched_template_points':0}
    distances,nearest=cKDTree(observed).query(world)
    matched=distances<.012;unique=len(np.unique(nearest[matched]))
    fraction=float(matched.mean())
    return {'verified':bool(matched.sum()>=20 and unique>=12 and fraction>=.45),
            'visible_template_points':len(world),'matched_template_points':int(matched.sum()),
            'unique_observed_points':unique,'matched_fraction':fraction,'hand_surface_excluded':True}
