import unittest
from sorting_order import order_key

class OrderTests(unittest.TestCase):
    def test_right_edge_before_taller_middle(self):
        objects=[dict(name='middle',approximate_body_center_pelvis_m=[.4,0,0],height_above_observed_table_m=.2),
                 dict(name='right',approximate_body_center_pelvis_m=[.4,-.3,0],height_above_observed_table_m=.03),
                 dict(name='left',approximate_body_center_pelvis_m=[.4,.3,0],height_above_observed_table_m=.1)]
        self.assertEqual([o['name'] for o in sorted(objects,key=order_key)],['right','middle','left'])
        self.assertEqual(sorted(objects,key=lambda o:order_key(o,'left-to-right'))[0]['name'],'left')
        self.assertEqual(sorted(objects,key=lambda o:order_key(o,'height'))[0]['name'],'middle')

if __name__=='__main__':unittest.main()
