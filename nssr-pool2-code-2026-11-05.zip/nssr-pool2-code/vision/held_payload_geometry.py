"""Estimate the currently held object's visible bounding centre from RGB-D."""
import bootstrap,json
import cv2
import numpy as np
from ultralytics import YOLO
from rgbd_geometry import backproject,polygon_mask
from payload_tracking import outside_hand

logs=bootstrap.ROOT.parent/'nssr-uwt-polygon/logs'
plan=json.loads((logs/'pool2-grasp-plan.json').read_text())['selected']
grip=json.loads((logs/'pool2-held-grip.json').read_text())
proof=json.loads((logs/'pool2-grasp-verification.json').read_text())
if not proof['success'] or proof['planning_sim_time']!=plan['planning_sim_time'] or grip['plan']['planning_sim_time']!=plan['planning_sim_time']:
    raise RuntimeError('No matching verified held object')
meta=json.loads((logs/'pool2-held.json').read_text());depths=np.load(logs/'pool2-held-depth.npz')
model=YOLO(json.loads((bootstrap.ROOT/'training_report.json').read_text())['weights'])
normal=np.array(plan['target']['support_normal_pelvis'])
x=np.array([1.,0,0]);x-=normal*(x@normal);x/=np.linalg.norm(x);y=np.cross(normal,x)
basis=np.column_stack((x,y,normal));candidates=[]
expected=np.array(plan['target']['approximate_body_center_pelvis_m'])+normal*plan.get('lift_distance_m',.06)
for camera,cam in meta['cameras'].items():
    image=cv2.imdecode(np.frombuffer((logs/f'pool2-held-{camera}_color.png').read_bytes(),np.uint8),1)
    depth=depths[camera+'_depth'];points,valid=backproject(depth,{'K':cam['k'],'height':depth.shape[0],'width':depth.shape[1]},np.array(cam['transform']))
    result=model(image,conf=.2,retina_masks=True,verbose=False,device=0)[0]
    if result.masks is None:continue
    for i,box in enumerate(result.boxes):
        if int(box.cls.item())!=plan['target']['class_id']:continue
        mask=polygon_mask(result.masks.xy[i],depth.shape)&valid
        mask=cv2.erode(mask.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
        hsv=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
        if plan['target']['category']=='electronics':
            mask&=(hsv[...,1]<100)&((hsv[...,2]>150) if plan['target']['class_id']==0 else (hsv[...,2]<110))
        cloud=points[mask]
        if grip.get('hand_hulls_tcp'):
            tcp=np.array(grip['tcp'])
            cloud=cloud[outside_hand((cloud-tcp[:3,3])@tcp[:3,:3],grip['hand_hulls_tcp'])]
        cloud=cloud[np.linalg.norm(cloud-expected,axis=1)<.28]
        if len(cloud)<40:continue
        local=cloud@basis;low,high=np.quantile(local,[.02,.98],axis=0)
        dimensions=high-low
        nominal=max(plan['target']['visible_footprint_dimensions_m'])
        if max(dimensions[:2])>max(.12,nominal*1.7):continue
        center=basis@((low+high)/2)
        candidates.append((len(cloud)*float(box.conf.item()),camera,center,cloud,dimensions))
if not candidates:raise RuntimeError('Held payload geometry is not visible; no delivery plan')
_,camera,center,cloud,dimensions=max(candidates,key=lambda c:c[0])
tcp=np.array(grip['tcp']);inverse=np.linalg.inv(tcp)
cloud=cloud[::max(1,int(np.ceil(len(cloud)/500)))]
relative=(cloud-center)@basis
out={'object':plan['object'],'planning_sim_time':plan['planning_sim_time'],'source_camera':camera,
     'center_pelvis_m':center.tolist(),'center_in_tcp_m':(inverse[:3,:3]@center+inverse[:3,3]).tolist(),
     'points_in_tcp_m':(cloud@inverse[:3,:3].T+inverse[:3,3]).tolist(),
     'visible_dimensions_m':dimensions.tolist(),'down_extent_m':float(-relative[:,2].min()+.01),
     'limitations':'Visible surface bounds, not a complete mesh or mass centre. Includes 10 mm underside allowance.'}
(logs/'pool2-held-payload.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k] for k in ('object','source_camera','center_pelvis_m','visible_dimensions_m','down_extent_m')}))
