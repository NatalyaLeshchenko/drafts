"""Build reviewed RGB-prompt/SAM annotations; never access simulator internals."""
import bootstrap
import argparse
import json
import shutil
from pathlib import Path
import cv2
import numpy as np
from ultralytics import SAM

ROOT = bootstrap.ROOT
COLORS = [(255, 90, 30), (40, 210, 255), (200, 50, 200), (40, 210, 40), (40, 120, 255), (220, 180, 60)]


def above_table(image, depth, intrinsic):
    """Remove table/shadow leakage using a robust plane fitted to public depth."""
    k = np.asarray(intrinsic).reshape(3,3)
    v,u = np.mgrid[:depth.shape[0],:depth.shape[1]]
    xyz = np.stack(((u-k[0,2])/k[0,0],(v-k[1,2])/k[1,1],np.ones_like(u)), -1) * (depth[...,None]/1000.)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    candidates = xyz[(v>115) & (v<325) & (hsv[...,1]<30) & (hsv[...,2]>115) & (hsv[...,2]<240) & (depth>0)]
    if len(candidates)<100:
        raise RuntimeError('Insufficient table depth for annotation cleanup')
    rng = np.random.default_rng(42)
    sample = candidates[rng.choice(len(candidates), min(1600,len(candidates)), replace=False)]
    best = None
    for _ in range(100):
        a,b,c = sample[rng.choice(len(sample),3,replace=False)]
        normal = np.cross(b-a,c-a)
        norm = np.linalg.norm(normal)
        if norm<1e-8:
            continue
        normal /= norm
        offset = -normal@a
        inliers = np.abs(sample@normal+offset)<.005
        score = int(inliers.sum())
        if best is None or score>best[0]:
            best = score,normal,offset
    normal,offset = best[1:]
    points = candidates[np.abs(candidates@normal+offset)<.007]
    center = points.mean(0)
    _,_,vt = np.linalg.svd(points-center,full_matrices=False)
    normal = vt[-1]
    foreground = (np.abs(xyz@normal-normal@center)>.008) & (depth>0)
    return foreground


def homography(source, target):
    sift = cv2.SIFT_create(nfeatures=2500)
    a, da = sift.detectAndCompute(cv2.cvtColor(source, cv2.COLOR_BGR2GRAY), None)
    b, db = sift.detectAndCompute(cv2.cvtColor(target, cv2.COLOR_BGR2GRAY), None)
    matches = cv2.BFMatcher().knnMatch(da, db, k=2)
    good = [m for m, n in matches if m.distance < .7 * n.distance]
    if len(good) < 10:
        raise RuntimeError('Insufficient RGB matches to transfer manual prompts')
    src = np.float32([a[m.queryIdx].pt for m in good])
    dst = np.float32([b[m.trainIdx].pt for m in good])
    h, inliers = cv2.findHomography(src, dst, cv2.RANSAC, 3.)
    if h is None or int(inliers.sum()) < 10:
        raise RuntimeError('Cannot reliably transfer annotation boxes')
    return h, int(inliers.sum())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT.parent / 'nssr-uwt-polygon/datasets/pool2_stage1')
    parser.add_argument('--output', type=Path, default=ROOT / 'dataset')
    args = parser.parse_args()
    prompts = json.loads((ROOT / 'prompts.json').read_text())
    model = SAM(str(ROOT / 'models/sam2.1_t.pt'))
    stats = {'source': str(args.source), 'annotation_method': 'manual RGB boxes + SAM2.1; RGB SIFT transfers between head views',
             'policy': prompts['policy'], 'classes': prompts['classes'], 'images': [], 'warnings': []}
    reviews = {}
    for folder in sorted(args.source.glob('seed_*_view_*')):
        meta = json.loads((folder / 'metadata.json').read_text())
        seed, view, split = str(meta['seed']), int(folder.name.rsplit('_', 1)[1]), meta['split']
        base = args.source / f'seed_{seed}_view_0'
        for camera in ('head', 'torso'):
            path = folder / f'{camera}_color.png'
            image = cv2.imread(str(path))
            depth = cv2.imread(str(folder / f'{camera}_depth.png'), cv2.IMREAD_UNCHANGED)
            foreground = above_table(image, depth, meta['cameras'][f'{camera}_depth']['K'])
            h = np.eye(3)
            inliers = None
            if camera == 'head' and view:
                h, inliers = homography(cv2.imread(str(base / 'head_color.png')), image)
            boxes, ids, points, point_labels = [], [], [], []
            for cls, box in enumerate(prompts[camera][seed]):
                if box is None:
                    continue
                x1, y1, x2, y2 = box
                corners = cv2.perspectiveTransform(np.float32([[[x1,y1],[x2,y1],[x2,y2],[x1,y2]]]), h)[0]
                margin = 0 if cls == 1 else (9 if camera == 'head' else 5)
                low, high = corners.min(0) - margin, corners.max(0) + margin
                low = np.maximum(low, [0,0]); high = np.minimum(high, [639,359])
                if np.any(high - low < 7):
                    continue
                boxes.append([*low, *high]); ids.append(cls)
                if camera == 'head':
                    p = cv2.perspectiveTransform(np.float32([[prompts['head_points'][seed][cls]]]), h)[0,0]
                    p = np.clip(p, [0,0], [639,359])
                    points.append([p.tolist(), low.tolist(), [float(high[0]),float(low[1])], high.tolist(), [float(low[0]),float(high[1])]])
                    point_labels.append([1,0,0,0,0])
            kwargs = {'points': points, 'labels': point_labels} if camera == 'head' else {}
            result = model(image, bboxes=boxes, device=0, conf=0., verbose=False, **kwargs)[0]
            masks = result.masks.data.cpu().numpy() > .5
            if len(masks) != len(ids):
                raise RuntimeError(f'Mask count mismatch: {folder.name} {camera}')
            if camera == 'torso' and seed == '100003':
                index = ids.index(2)
                refined = model(image, bboxes=[boxes[index]], points=[[[630,155]]],
                    labels=[[1]], conf=0., device=0, verbose=False)[0]
                masks[index] = refined.masks.data[0].cpu().numpy() > .5
            stem = f'{folder.name}_{camera}'
            image_dir, label_dir = args.output / 'images' / split, args.output / 'labels' / split
            image_dir.mkdir(parents=True, exist_ok=True); label_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, image_dir / f'{stem}.png')
            overlay, rows, instances = image.copy(), [], []
            for cls, mask, box in zip(ids, masks, boxes):
                # Constrain SAM to the visually specified object area.
                x1,y1,x2,y2 = np.round(box).astype(int)
                region = np.zeros_like(mask); region[y1:y2+1,x1:x2+1] = True
                mask &= region
                mask &= foreground
                mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3,3),np.uint8)) > 0
                contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                if not contours:
                    stats['warnings'].append(f'{stem}: class {cls}: empty mask'); continue
                contour = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(contour)
                if area < 20:
                    stats['warnings'].append(f'{stem}: class {cls}: tiny mask'); continue
                contour = cv2.approxPolyDP(contour, .7, True).reshape(-1,2)
                if len(contour) < 3:
                    continue
                normalized = contour / np.array([640.,360.])
                rows.append(str(cls) + ' ' + ' '.join(f'{v:.6f}' for v in normalized.ravel()))
                filled = np.zeros(mask.shape, np.uint8)
                cv2.fillPoly(filled, [contour], 1)
                color = np.array(COLORS[cls])
                overlay[filled > 0] = (overlay[filled > 0] * .65 + color * .35).astype(np.uint8)
                cv2.polylines(overlay, [contour], True, COLORS[cls], 1)
                x,y,w,hb = cv2.boundingRect(contour)
                cv2.putText(overlay, f'{cls}:{prompts["classes"][cls]}', (x,max(13,y-3)), cv2.FONT_HERSHEY_SIMPLEX,.38,COLORS[cls],1)
                instances.append({'class': cls, 'area': area, 'bbox': [x,y,w,hb]})
            (label_dir / f'{stem}.txt').write_text('\n'.join(rows) + '\n')
            cv2.putText(overlay, stem, (5,18), cv2.FONT_HERSHEY_SIMPLEX,.5,(0,0,255),1)
            review_dir = args.output / 'review'; review_dir.mkdir(exist_ok=True)
            cv2.imwrite(str(review_dir / f'{stem}.jpg'), overlay)
            if camera == 'head' or view == 0:
                reviews.setdefault(seed, {})[f'{camera}_{view}'] = overlay
            stats['images'].append({'stem': stem,'seed': int(seed),'split': split,'camera':camera,
                                    'rgb_match_inliers':inliers,'instances':instances})
            print(f'{stem}: {len(rows)} masks', flush=True)
    for seed, frames in reviews.items():
        page = np.vstack((np.hstack((frames['head_0'],frames['head_1'])),
                          np.hstack((frames['head_2'],frames['torso_0']))))
        cv2.imwrite(str(args.output / 'review' / f'seed_{seed}_page.jpg'), page)
    names = '\n'.join(f'  {i}: {name}' for i,name in enumerate(prompts['classes']))
    (args.output / 'data.yaml').write_text(f'path: {args.output.resolve().as_posix()}\ntrain: images/train\nval: images/validation\nnames:\n{names}\n', encoding='utf-8')
    (args.output / 'annotation_report.json').write_text(json.dumps(stats, indent=2), encoding='utf-8')
    print(f'Done: {len(stats["images"])} images, {len(stats["warnings"])} warnings', flush=True)


if __name__ == '__main__':
    main()
