"""Confirm a released Marc Anthony tube lies inside the RGB-D measured tray."""
import bootstrap
import json
from pathlib import Path
import cv2
import numpy as np
from ultralytics import YOLO
from rgbd_geometry import backproject,polygon_mask
from scipy.spatial import cKDTree

root=bootstrap.ROOT.parent/'nssr-uwt-polygon'/'logs'
tray=json.loads((root/'pool2-tray-target.json').read_text())
grasp=json.loads((root/'pool2-grasp-plan.json').read_text())['selected']
appearance={'marc_anthony':(3,18,50,45,60),'wilton':(4,12,40,60,50),'beta_glucan':(5,90,135,65,35),
            'deskstar':(0,0,180,0,150),'razer_mouse':(1,0,180,0,0),'rocksmith_cable':(2,0,180,0,0)}
class_id,hlo,hhi,smin,vmin=appearance[grasp['object']]
floor=np.array(tray['center_floor_pelvis_m']); normal=np.array(tray['support_normal_pelvis'])
ex=np.array([1.,0,0]);ex-=normal*np.dot(ex,normal);ex/=np.linalg.norm(ex)
ey=np.cross(normal,ex)
model=YOLO(json.loads((bootstrap.ROOT/'training_report.json').read_text())['weights'])
observed={}
baseline_meta=json.loads((root/'pool2-destination.json').read_text())
baseline_depth=np.load(root/'pool2-destination-depth.npz')['head_depth']
baseline_cam=baseline_meta['cameras']['head']
baseline_points,baseline_valid=backproject(baseline_depth,{'K':baseline_cam['k'],'D':[0.]*5,'height':baseline_depth.shape[0],'width':baseline_depth.shape[1]},np.array(baseline_cam['transform']))
bd=baseline_points-floor
baseline_inner=baseline_valid&(abs(bd@ex)<.08)&(abs(bd@ey)<.13)
baseline_foreground=baseline_inner&((bd@normal)>.015)&((bd@normal)<.16)
baseline_empty=int(baseline_foreground.sum())<20 and int(baseline_inner.sum())>100
baseline_visible=int(baseline_inner.sum())>100
baseline_tree=cKDTree(baseline_points[baseline_valid])
grip_verification=json.loads((root/'pool2-grasp-verification.json').read_text())
identity_verified=grip_verification['success'] and grip_verification['object']==grasp['object'] and grip_verification['planning_sim_time']==grasp['planning_sim_time']
for label in ['released','withdraw']:
    prefix='pool2-delivery-'+label
    meta=json.loads((root/f'{prefix}.json').read_text())
    depths=np.load(root/f'{prefix}-depth.npz')
    for camera,cam in meta['cameras'].items():
        im=cv2.imdecode(np.frombuffer((root/f'{prefix}-{camera}_color.png').read_bytes(),np.uint8),1)
        depth=depths[camera+'_depth']
        info={'K':cam['k'],'D':[0.]*5,'height':depth.shape[0],'width':depth.shape[1]}
        points,valid=backproject(depth,info,np.array(cam['transform']))
        result=model(im,device=0,conf=.2,retina_masks=True,verbose=False)[0]
        matches=[i for i,b in enumerate(result.boxes) if int(b.cls.item())==class_id]
        hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
        colored=(hsv[:,:,0]>=hlo)&(hsv[:,:,0]<=hhi)&(hsv[:,:,1]>smin)&(hsv[:,:,2]>vmin)
        delta=points-floor; x=delta@ex;y=delta@ey;z=delta@normal
        inside=(abs(x)<.102)&(abs(y)<.152)&(z>.008)&(z<.23)
        mask=colored&valid&inside
        semantic=False
        if matches and result.masks is not None:
            idx=max(matches,key=lambda i:float(result.boxes[i].conf.item()))
            region=polygon_mask(result.masks.xy[idx],depth.shape)
            candidate=mask&cv2.dilate(region.astype(np.uint8),np.ones((5,5),np.uint8)).astype(bool)
            if candidate.sum()>=12: mask=candidate; semantic=True
        count=int(mask.sum())
        # A placed object may have an unseen orientation. Track the known held
        # identity through a release into a previously empty, depth-measured tray.
        inner=valid&(abs(x)<.08)&(abs(y)<.13)&(z>.015)&(z<.16)
        novel=np.zeros(depth.shape,bool)
        if baseline_visible and identity_verified and inner.any():
            distances,_=baseline_tree.query(points[inner])
            novel[inner]=distances>.012
        new_count=int(novel.sum())
        record={'label_pixels_inside_tray':count,'yolo_associated':semantic,
                'new_depth_foreground_pixels':new_count,'baseline_tray_empty':baseline_empty,'baseline_tray_visible':baseline_visible,
                'verified':(count>=20 and semantic) or (baseline_empty and identity_verified and new_count>=40)}
        if count:
            record.update(median_label_point_pelvis_m=np.median(points[mask],axis=0).tolist(),
                          median_label_height_above_tray_m=float(np.median(z[mask])))
        observed[label+'_'+camera]=record
        im[mask|novel]=[255,0,255]
        (root/f'{prefix}-{camera}-verification.jpg').write_bytes(cv2.imencode('.jpg',im)[1].tobytes())
report={'object':grasp['object'],'planning_sim_time':grasp['planning_sim_time'],'destination':tray['tray'],'method':'class identity, or new RGB-D foreground only in an empty tray linked to the verified held identity',
        'observations':observed,'success':any(v['verified'] for k,v in observed.items() if k.startswith('withdraw_')),
        'official_judge_checked':False}
(root/'pool2-delivery-verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
if not report['success']:raise SystemExit(2)
