"""Run the trained pool-2 model on saved camera frames, producing overlays and JSON."""
import bootstrap
import argparse
import json
from pathlib import Path
import cv2
from ultralytics import YOLO


def main():
    root = bootstrap.ROOT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=root.parent / 'nssr-uwt-polygon/datasets/pool2_stage2_unseen')
    parser.add_argument('--weights', type=Path)
    parser.add_argument('--output', type=Path, default=root / 'predictions_unseen')
    parser.add_argument('--conf', type=float, default=.35)
    parser.add_argument('--keep-duplicates', action='store_true',
        help='Disable the pool-2 sort2 prior of one instance of each named object')
    args = parser.parse_args()
    if args.weights is None:
        report = root / 'training_report.json'
        args.weights = Path(json.loads(report.read_text(encoding='utf-8'))['weights']) if report.exists() else root / 'runs/pool2_yolo11n_seg/weights/best.pt'
    if args.source.is_file():
        files = [args.source]
    else:
        files = sorted(args.source.glob('**/*_color.png'))
        if not files:
            files = sorted(args.source.glob('**/*.png'))
    if not files:
        raise RuntimeError('No camera images found')
    model = YOLO(str(args.weights))
    expected = ['deskstar','razer_mouse','rocksmith_cable','marc_anthony','wilton','beta_glucan']
    if [model.names[i] for i in range(len(model.names))] != expected:
        raise RuntimeError('Weights do not match the six pool-2 classes in the expected order')
    args.output.mkdir(parents=True, exist_ok=True)
    summary = {'weights': str(args.weights), 'confidence_threshold': args.conf,
        'one_per_class': not args.keep_duplicates,
        'scene_assumption': 'sort2 pool 2 contains one instance of each of these six objects', 'frames': []}
    for path in files:
        result = model(str(path), device=0, conf=args.conf, imgsz=640, retina_masks=True, verbose=False)[0]
        stem = path.parent.name + '_' + path.stem
        raw_detections = []
        for index, box in enumerate(result.boxes):
            cls = int(box.cls.item())
            xyxy = box.xyxy[0].cpu().tolist()
            polygon = result.masks.xy[index].tolist() if result.masks is not None else []
            raw_detections.append({'class_id': cls, 'name': model.names[cls],
                'category': 'electronics' if cls < 3 else 'jar',
                'confidence': float(box.conf.item()), 'bbox_xyxy_pixels': xyxy,
                'polygon_xy_pixels': polygon})
        keep, seen = [], set()
        for index in sorted(range(len(raw_detections)), key=lambda i: -raw_detections[i]['confidence']):
            cls = raw_detections[index]['class_id']
            if args.keep_duplicates or cls not in seen:
                keep.append(index); seen.add(cls)
        detections = [raw_detections[i] for i in keep]
        suppressed = [d for i,d in enumerate(raw_detections) if i not in keep]
        cv2.imwrite(str(args.output / f'{stem}.jpg'), result[keep].plot())
        frame = {'source': str(path), 'detections': detections, 'raw_detections':raw_detections,
                 'suppressed_duplicates': suppressed, 'inference_ms': result.speed['inference']}
        (args.output / f'{stem}.json').write_text(json.dumps(frame, indent=2), encoding='utf-8')
        summary['frames'].append(frame)
        print(f'{stem}: ' + ', '.join(f'{d["name"]} {d["confidence"]:.2f}' for d in detections), flush=True)
    (args.output / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    central = [p for p in sorted(args.output.glob('*_view_0_head_color.jpg'))]
    if central:
        tiles = [cv2.imread(str(p)) for p in central]
        import numpy as np
        cv2.imwrite(str(args.output / 'overview.jpg'), np.vstack(tiles))


if __name__ == '__main__':
    main()
