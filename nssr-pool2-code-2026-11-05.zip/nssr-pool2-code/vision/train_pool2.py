"""Train and validate a six-class YOLO11 nano segmentation baseline."""
import bootstrap
import argparse
import json
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--name', default='pool2_yolo11n_seg')
    args = parser.parse_args()
    root = bootstrap.ROOT
    model = YOLO(str(root / 'models/yolo11n-seg.pt'))
    model.train(data=str(root / 'dataset/data.yaml'), epochs=args.epochs, imgsz=640,
        batch=8, device=0, workers=0, project=str(root / 'runs'), name=args.name,
        seed=42, patience=25, amp=False, cache=False, plots=True,
        mosaic=.5, close_mosaic=15, degrees=10, translate=.08, scale=.3,
        flipud=0., fliplr=.5, hsv_h=.01, hsv_s=.25, hsv_v=.25)
    best = model.trainer.best
    trained = YOLO(str(best))
    metrics = trained.val(data=str(root / 'dataset/data.yaml'), device=0, workers=0,
        imgsz=640, project=str(root / 'runs'), name=args.name+'_validation', plots=True)
    report = {'weights': str(best), 'dataset': str(root / 'dataset/data.yaml'),
        'metrics': metrics.results_dict,
        'per_class': {trained.names[i]: {'box_map50':float(metrics.box.ap50[i]),
            'mask_map50':float(metrics.seg.ap50[i])} for i in range(len(metrics.box.ap50))},
        'limitation': 'Initial small dataset: 8 train layouts, 4 validation layouts. SAM-assisted labels are approximate; this is not a guarantee of grasp accuracy.'}
    (root / 'training_report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
