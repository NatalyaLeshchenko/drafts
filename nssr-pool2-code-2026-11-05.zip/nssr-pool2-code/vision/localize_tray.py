"""Locate the blue tray from its visible RGB-D surface, not simulator poses."""
import json
from pathlib import Path
import cv2
import numpy as np

root=Path(__file__).resolve().parents[1]/'nssr-uwt-polygon'/'logs'
meta=json.loads((root/'pool2-destination.json').read_text())
plan=json.loads((root/'pool2-grasp-plan.json').read_text())['selected']
task=json.loads((root/'pool2-delivery-task.json').read_text())
destination=task['categories'][plan['target']['category']]
color=task['trays'][destination]
if color not in ('blue','red'): raise RuntimeError('Unsupported tray color')
im=cv2.imdecode(np.frombuffer((root/'pool2-destination-head_color.png').read_bytes(),np.uint8),1)
depth=np.load(root/'pool2-destination-depth.npz')['head_depth']/1000.
hsv=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
color_mask=((hsv[:,:,0]>85)&(hsv[:,:,0]<115)) if color=='blue' else ((hsv[:,:,0]<12)|(hsv[:,:,0]>170))
mask=(color_mask&(hsv[:,:,1]>8)&(hsv[:,:,1]<160)&(hsv[:,:,2]>220)).astype(np.uint8)
n,labels,stats,_=cv2.connectedComponentsWithStats(mask)
if n<2: raise RuntimeError('No blue tray visible')
mask=labels==(1+np.argmax(stats[1:,cv2.CC_STAT_AREA]))
v,u=np.where(mask&(depth>.15)&(depth<3))
K=np.array(meta['cameras']['head']['k']).reshape(3,3)
T=np.array(meta['cameras']['head']['transform'])
p=np.column_stack(((u-K[0,2])/K[0,0]*depth[v,u],(v-K[1,2])/K[1,1]*depth[v,u],depth[v,u]))@T[:3,:3].T+T[:3,3]
normal=np.array(plan['target']['support_normal_pelvis'])
ex=np.array([1.,0,0]); ex-=normal*np.dot(ex,normal); ex/=np.linalg.norm(ex)
ey=np.cross(normal,ex)
xy=p@np.column_stack((ex,ey))
lo,hi=np.percentile(xy,[.5,99.5],axis=0)
dimensions=hi-lo
if not (.18<dimensions[0]<.26 and .27<dimensions[1]<.36):
    raise RuntimeError(f'Tray is cropped or wrong dimensions: {dimensions}')
center_xy=(lo+hi)/2
# Visible inner bottom is the lowest broad surface; rims stand 7 cm higher.
floor_height=float(np.percentile(p@normal,15))
center=ex*center_xy[0]+ey*center_xy[1]+normal*floor_height
vv,uu=np.mgrid[:depth.shape[0],:depth.shape[1]]
all_points=np.stack(((uu-K[0,2])/K[0,0]*depth,(vv-K[1,2])/K[1,1]*depth,depth),-1)@T[:3,:3].T+T[:3,3]
delta=all_points-center
xx,yy,zz=delta@ex,delta@ey,delta@normal
occupied=(depth>.15)&(abs(xx)<.085)&(abs(yy)<.135)&(zz>.015)&(zz<.22)
cloud=np.column_stack((xx[occupied],yy[occupied]))
slots=[np.array([x,y]) for x in (0.,-.035,.035) for y in (0.,-.085,.085)]
slot=max(slots,key=lambda s:(float(np.min(np.linalg.norm(cloud-s,axis=1))) if len(cloud) else 1.)-.1*np.linalg.norm(s))
placement_offset=ex*slot[0]+ey*slot[1]
out={'tray':destination,'color':color,'center_floor_pelvis_m':center.tolist(),
     'occupied_points_in_plane_m':np.column_stack((xx[occupied],yy[occupied],zz[occupied]))[::max(1,int(np.ceil(int(occupied.sum())/600)))].tolist(),
     'placement_offset_pelvis_m':placement_offset.tolist(),'observed_occupied_pixels':int(occupied.sum()),
     'support_normal_pelvis':normal.tolist(),'visible_dimensions_m':dimensions.tolist(),
     'wall_height_m':.07,'source':'public head RGB-D, blue connected surface', 'pixels':len(p)}
current=root/'pool2-tray-target.json'
if current.exists():
    previous=json.loads(current.read_text())
    (root/('pool2-'+previous['tray']+'-target.json')).write_text(json.dumps(previous,indent=2))
current.write_text(json.dumps(out,indent=2))
(root/('pool2-'+destination+'-target.json')).write_text(json.dumps(out,indent=2))
im[mask]=(.5*im[mask]+.5*np.array([0,255,0])).astype(np.uint8)
(root/'pool2-tray-detection.jpg').write_bytes(cv2.imencode('.jpg',im)[1].tobytes())
print(json.dumps(out,indent=2))

