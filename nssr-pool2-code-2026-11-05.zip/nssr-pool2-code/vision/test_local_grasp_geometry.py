import unittest
import numpy as np
from local_grasp_geometry import loop_patches


class LoopTests(unittest.TestCase):
    def test_patch_on_visible_strand_not_hole(self):
        a=np.linspace(0,2*np.pi,900,endpoint=False)
        cloud=np.vstack([np.column_stack((r*np.cos(a),r*np.sin(a),np.full(len(a),.025)))
                         for r in (.060,.065,.070,.075)])
        patches=loop_patches(cloud,[0,0,0],[0,0,1])
        self.assertGreaterEqual(len(patches),8)
        for patch in patches:
            radius=np.linalg.norm(patch['support_pelvis_m'][:2])
            self.assertGreater(radius,.05)
            self.assertLess(max(patch['visible_footprint_dimensions_m']),.055)
            contact=np.array(patch['surface_contact_pelvis_m'])
            self.assertLess(np.linalg.norm(cloud-contact,axis=1).min(),1e-10)

    def test_sparse_cloud_does_not_invent_patch(self):
        self.assertEqual(loop_patches(np.array([[.05,0,.025]]),[0,0,0],[0,0,1]),[])


if __name__=='__main__':unittest.main()
