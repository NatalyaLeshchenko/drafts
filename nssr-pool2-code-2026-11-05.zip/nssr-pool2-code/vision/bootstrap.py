"""Use project-local vision packages without changing Isaac Sim dependencies."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for stream in (sys.stdout,sys.stderr):
    if hasattr(stream,'reconfigure'):
        stream.reconfigure(encoding='utf-8')
sys.path.insert(0, str(ROOT / 'vendor'))
os.environ.setdefault('YOLO_CONFIG_DIR', str(ROOT / 'config'))
os.environ.setdefault('TORCH_HOME', str(ROOT / 'cache'))
os.environ.setdefault('YOLO_AUTOINSTALL', 'false')
