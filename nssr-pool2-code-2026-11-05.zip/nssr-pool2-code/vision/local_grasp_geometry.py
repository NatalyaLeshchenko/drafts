"""Local grasp patches from visible RGB-D surfaces; no simulation state."""
import numpy as np
import cv2


def loop_patches(cloud, support, normal):
    cloud=np.asarray(cloud);support=np.asarray(support);normal=np.asarray(normal)
    heights=(cloud-support)@normal
    projected=cloud-heights[:,None]*normal
    radial=projected-support
    radius=float(np.quantile(np.linalg.norm(radial,axis=1),.75))
    patches=[]
    for angle in np.linspace(0,2*np.pi,12,endpoint=False):
        direction=np.array([np.cos(angle),np.sin(angle),0.])
        direction-=normal*(direction@normal);direction/=np.linalg.norm(direction)
        desired=support+direction*radius
        nearest=int(np.argmin(np.linalg.norm(projected-desired,axis=1)))
        distance=np.linalg.norm(projected-projected[nearest],axis=1)
        points=cloud[(distance<.024)&(heights>.008)]
        if len(points)<20:continue
        h=(points-support)@normal
        flat=points-h[:,None]*normal
        rect=cv2.minAreaRect(flat[:,:2].astype(np.float32))
        a,b=rect[1]
        yaw=(rect[2]+(90 if a<b else 0)+90)%180-90
        median=np.median(flat,axis=0)
        # An average between separate strands can be empty space. Anchor to an
        # actual depth sample on the visible wire, retaining its measured height.
        contact_index=int(np.argmin(np.linalg.norm(flat-median,axis=1)+.25*abs(h-np.quantile(h,.75))))
        center=flat[contact_index]
        contact=points[contact_index]
        near=np.linalg.norm(flat-center,axis=1)<.006
        local_h=h[near]
        radius_estimate=float(np.clip((np.quantile(local_h,.95)-np.quantile(local_h,.1))/2,.002,.005))
        height=float(np.quantile(h,.95))
        patches.append({'support_pelvis_m':center.tolist(),
            'visible_footprint_dimensions_m':sorted([float(a),float(b)]),
            'height_above_observed_table_m':height,'yaw_deg_mod_180':float(yaw),
            'surface_contact_pelvis_m':contact.tolist(),
            'surface_radius_estimate_m':radius_estimate,
            'samples':len(points)})
    # Near-side surface first; a local patch is a proposal, not a proven contact.
    return sorted(patches,key=lambda p:p['support_pelvis_m'][0])
