param(
    [ValidateSet('Prepare','Train','Predict','Localize','Observe')][string]$Action = 'Predict',
    [string]$Source = '',
    [int]$Epochs = 100
)
$ErrorActionPreference = 'Stop'
$visionPython = Join-Path $env:USERPROFILE 'isaac-win\Scripts\python.exe'
if (!(Test-Path -LiteralPath $visionPython)) { throw 'The existing isaac-win Python environment is required.' }
$env:PYTHONUTF8 = '1'
switch ($Action) {
    'Prepare' { & $visionPython (Join-Path $PSScriptRoot 'prepare_dataset.py') }
    'Train' { & $visionPython (Join-Path $PSScriptRoot 'train_pool2.py') --epochs $Epochs }
    'Predict' {
        if ($Source) { & $visionPython (Join-Path $PSScriptRoot 'predict_pool2.py') --source $Source }
        else { & $visionPython (Join-Path $PSScriptRoot 'predict_pool2.py') }
    }
    'Localize' {
        & $visionPython (Join-Path $PSScriptRoot 'localize_pool2.py')
        if ($LASTEXITCODE -ne 0) { throw 'RGB-D localization failed.' }
        & $visionPython (Join-Path $PSScriptRoot 'fuse_localization.py')
    }
    'Observe' {
        $observationId = 'pool2_observation_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff')
        $containerOutput = '/nssr_sim/datasets/' + $observationId
        $hostOutput = Join-Path (Split-Path $PSScriptRoot) ('nssr-uwt-polygon\datasets\' + $observationId)
        $predictionsOutput = Join-Path $PSScriptRoot ('observations\' + $observationId + '\predictions')
        $localizationOutput = Join-Path $PSScriptRoot ('observations\' + $observationId + '\localization')
        docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml && python3 /windows-support/observe_pool2.py --output $containerOutput"
        if ($LASTEXITCODE -ne 0) { throw 'Observation failed; start the sort2 pool-2 simulator and ROS bridge first.' }
        & $visionPython (Join-Path $PSScriptRoot 'predict_pool2.py') --source $hostOutput --output $predictionsOutput
        if ($LASTEXITCODE -ne 0) { throw 'Detection failed.' }
        $predictionSummary = Join-Path $predictionsOutput 'summary.json'
        & $visionPython (Join-Path $PSScriptRoot 'localize_pool2.py') --predictions $predictionSummary --output $localizationOutput
        if ($LASTEXITCODE -ne 0) { throw 'RGB-D localization failed.' }
        & $visionPython (Join-Path $PSScriptRoot 'fuse_localization.py') --input (Join-Path $localizationOutput 'summary.json')
        if ($LASTEXITCODE -ne 0) { throw 'Multi-view consistency check failed.' }
        $localizationOutput | Set-Content -Encoding UTF8 (Join-Path $PSScriptRoot 'latest_observation.txt')
        Write-Output "Saved observation: $localizationOutput"
    }
}
if ($LASTEXITCODE -ne 0) { throw "Vision action failed: $Action" }
