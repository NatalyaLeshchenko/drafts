"""Package source/configuration only; exclude generated data and installed tools."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'nssr-pool2-code-2026-11-05.zip'
PREFIX = 'nssr-pool2-code'
SKIP = {'.git', '__pycache__', '.pytest_cache', '.venv', 'vendor', 'cache',
        '.cache', 'node_modules', 'datasets', 'dataset', 'logs', 'observations',
        'runs', 'models', 'assets', 'localization_unseen', 'predictions_unseen',
        'build', 'install', '.idea', '.vscode'}
EXTENSIONS = {'.py', '.ps1', '.sh', '.bash', '.bat', '.cmd', '.md', '.txt',
              '.yaml', '.yml', '.toml', '.ini', '.cfg', '.json', '.xml',
              '.msg', '.srv', '.action', '.cpp', '.c', '.hpp', '.h', '.cmake',
              '.launch', '.rviz', '.dockerignore', '.gitignore', '.rst'}

def include(path):
    rel = path.relative_to(ROOT)
    if any(part in SKIP for part in rel.parts):
        return False
    if path.name.startswith('.env') or path.name in {'latest_observation.txt', 'gui-process-id.txt'}:
        return False
    if path.suffix.lower() == '.json' and ('report' in path.stem or path.name == 'grasp-results.json'):
        return path.name == 'training_report.json'
    return path.suffix.lower() in EXTENSIONS or path.name in {'Dockerfile', 'LICENSE', 'Makefile', 'CMakeLists.txt'}

files = []
for directory in ('windows', 'vision', 'nssr-uwt-polygon'):
    # Prune excluded directories before traversal, rather than walking datasets.
    import os
    for base, dirs, names in os.walk(ROOT / directory):
        dirs[:] = [d for d in dirs if d not in SKIP]
        files.extend(p for name in names if include(p := Path(base) / name))
files.extend(ROOT / name for name in ('Dockerfile.install', 'restore-project-paths.ps1', 'package_code.py'))
readme = '''# Код проекта NSSR pool 2 / sort2

Снимок исходников от 2026-11-05.

- windows/: управление роботом через ROS, планирование и проверка хватов,
  перенос в корзины, PowerShell-сценарии запуска и тесты.
- vision/: YOLO + RGB-D, локализация, выбор предметов, проверки удержания.
- nssr-uwt-polygon/: исходники симулятора, ROS-интерфейсы, конфигурация и документация заданий.

Сортировка: windows/pool2-sort-all.ps1 -Order right-to-left.
Порядок задан относительно робота; после укладки выполняется новое наблюдение.
Неподтверждённый хват или недоступный крайний предмет останавливает цикл.

Статус: полная сортировка всех шести предметов ещё не подтверждена.
Подтверждена укладка катушки в красную корзину. Захват коробки требует доработки.
Документы с результатами прошлых экспериментов не являются гарантией полного цикла.

Это архив КОДА. В нём нет Isaac Sim/Isaac Lab, Python-окружений,
Docker-образов, ресурсов сцены и робота (assets), весов моделей, датасетов,
логов и снимков камер. Для запуска нужны отдельно установленное окружение,
ресурсы исходного репозитория и обученные веса YOLO.
Сценарии рассчитаны на существующую Windows + Docker/ROS Humble установку.
Путь к весам указан в vision/training_report.json; после переноса его нужно
обновить (restore-project-paths.ps1), а веса разместить отдельно.
'''
manifest = []
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    archive.writestr(PREFIX + '/README_CODE_RU.md', readme)
    for path in sorted(set(files)):
        data = path.read_bytes()
        relative = path.relative_to(ROOT).as_posix()
        archive.writestr(PREFIX + '/' + relative, data)
        manifest.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    archive.writestr(PREFIX + '/MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for required in ('windows/pool2-sort-all.ps1', 'windows/grasp_pool2.py',
                     'vision/select_pool2_target.py', 'vision/verify_carry.py'):
        assert PREFIX + '/' + required in archive.namelist(), required
digest = hashlib.sha256(OUT.read_bytes()).hexdigest()
OUT.with_suffix('.zip.sha256').write_text(digest + '  ' + OUT.name + '\n', encoding='ascii')
print(json.dumps({'archive': str(OUT), 'source_files': len(manifest),
                  'size_MB': round(OUT.stat().st_size / 1048576, 2), 'crc_verified': True}, ensure_ascii=True))
