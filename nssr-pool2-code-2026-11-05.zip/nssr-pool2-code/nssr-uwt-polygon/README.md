# nssr-uwt-polygon

![Isaac Sim](https://img.shields.io/badge/Isaac%20Sim-5.0-76B900)
![Isaac Lab](https://img.shields.io/badge/Isaac%20Lab-2.2-76B900)
![ROS 2](https://img.shields.io/badge/ROS%202-Humble-22314E)
![Docker](https://img.shields.io/badge/Docker-NVIDIA%20Container%20Toolkit-2496ED)
![License](https://img.shields.io/badge/License-Apache%202.0-blue)

Симуляционная среда хакатона. Хакатон посвящён треку манипуляции: среда содержит цифровой двойник антропоморфного
робота UBTECH Walker TienKung 2.0 Pro на испытательном полигоне: склад, рабочий стол, сортировочные ящики и
вытяжной шкаф. Среда собрана на NVIDIA Isaac Sim 5.0 и Isaac Lab 2.2. Роботом
управляют через ROS 2 Humble теми же топиками и сообщениями, что и на реальном роботе, поэтому код, написанный под
симулятор, переносится на робота без переделки интерфейсов. Ноги робота закреплены, работать нужно верхней
половиной: головой, корпусом, руками и кистями.

https://github.com/user-attachments/assets/57286fac-8e7c-4a9c-b5ea-8db45cdf4f2e

| Сортировка | Пробирки |
|---|---|
| ![Робот у рабочего стола с ящиками](hackathon/docs/img/sort3_overview.png) | ![Рабочий стол и вытяжной шкаф](hackathon/docs/img/tubes_standard_overview.png) |

Документация:

- [Задачи и варианты](hackathon/docs/TASKS.md): что нужно сделать, как выбрать задачу, самопроверка.
- [Интерфейсы робота](hackathon/docs/INTERFACES.md): моторы, топики, кисти, датчики силы, камеры.
- [Проверка решений](hackathon/docs/SCORING.md): баллы, время, формат решения, сроки.

## Задачи

Робот стоит у рабочего стола. Что лежит на столе и что считается выполнением, определяет задача, её выбирают при
запуске: `bash hackathon/tools/task.sh <задача>`. Раскладка объектов при каждом запуске новая.

Трек состоит из трёх подготовительных блоков (обратная кинематика рук; кисти, голова и корпус; детекция по камерам)
и двух финальных задач ниже. Баллы дают только финальные задачи, подготовительные блоки нужны, чтобы их решить.

### Сортировка: sort2 и sort3

На столе 6 или 9 объектов двух или трёх категорий, перед роботом столько же сортировочных ящиков: красный, синий, зелёный. Нужно
разложить объекты так, чтобы в каждом ящике была одна категория. Какая категория в какой ящик, публикуется в
`/sim/task`, где лежат объекты, робот определяет камерами. Набор объектов (пул) у каждой команды свой:
пул = (номер команды - 1) mod 5 + 1. `sort2` и `sort3` решаются на своём пуле. По желанию ещё `sort2` на
пуле 6 с другими объектами: баллы за неё идут сверх основных. Подробно: [TASKS.md](hackathon/docs/TASKS.md), раздел "Варианты".

| `sort3`: 3 категории, 3 ящика | `sort2`: 2 категории, 2 ящика |
|---|---|
| ![Сортировка на три ящика](hackathon/docs/img/sort3_table.png) | ![Сортировка на два ящика](hackathon/docs/img/sort2_table.png) |

### Пробирки: tubes, задача со звёздочкой

Слева от робота вытяжной шкаф с пустыми штативами. Нужно взять пробирку со стола, повернуть корпус влево, поставить
пробирку вертикально в нужный штатив в шкафу и вернуться к столу. Четыре варианта, каждый решённый добавляет баллы.
Задачи решаются последовательно: пробирки засчитываются только вместе с сортировкой.

| `easy`: 4 пробирки 50 мл, в любое гнездо | `standard`: 50 и 15 мл, каждую в штатив своего размера |
|---|---|
| ![Пробирки easy](hackathon/docs/img/tubes_easy_table.png) | ![Пробирки standard](hackathon/docs/img/tubes_standard_table.png) |
| **`color`: по цвету крышки, в красный или синий штатив** | **`lying`: пробирки лежат, поднять и поставить вертикально** |
| ![Пробирки color](hackathon/docs/img/tubes_color_table.png) | ![Пробирки lying](hackathon/docs/img/tubes_lying_table.png) |

| Шкаф, `standard`: штативы 50 и 15 мл | Шкаф, `color`: красный и синий штативы |
|---|---|
| ![Шкаф, вариант standard](hackathon/docs/img/tubes_standard_hood.png) | ![Шкаф, вариант color](hackathon/docs/img/tubes_color_hood.png) |

### Что видит робот

Две RGB-D камеры, на голове и на торсе, 640x360. Глубина на картинках раскрашена: красный ближе, синий дальше.

| | Цвет | Глубина |
|---|---|---|
| Голова | ![Головная камера](hackathon/docs/img/sort3_cam_head.png) | ![Глубина головной камеры](hackathon/docs/img/sort3_cam_head_depth.png) |
| Торс | ![Торсовая камера](hackathon/docs/img/sort3_cam_torso.png) | ![Глубина торсовой камеры](hackathon/docs/img/sort3_cam_torso_depth.png) |
| Торс, пробирки | ![Торсовая камера, штативы](hackathon/docs/img/tubes_standard_cam_torso.png) | ![Глубина, штативы](hackathon/docs/img/tubes_standard_cam_torso_depth.png) |

Подробности задач, правила и самопроверка: [TASKS.md](hackathon/docs/TASKS.md). Баллы и лимиты времени:
[SCORING.md](hackathon/docs/SCORING.md).

## Требования

- Linux с Docker и NVIDIA Container Toolkit. Проверено на Ubuntu 26.04 LTS с драйвером NVIDIA ветки 580.
- Видеокарта NVIDIA RTX (подходят и RTX 30-й серии), от 8 ГБ видеопамяти. Проверено на RTX 5080 Laptop 16 ГБ.
- Оперативная память от 16 ГБ, рекомендуется 24-32 ГБ. Сам симулятор занимает около 7.5 ГБ.
- Около 50 ГБ свободного места на диске: образ занимает около 30 ГБ.
- Интернет для первой сборки образа (скачивается около 8.5 ГБ) и скачивания ассетов (около 0.7 ГБ).
- VPN на время сборки образа: базовый образ NVIDIA Isaac Lab скачивается с nvcr.io, а он недоступен из России.

## Подготовка машины

Если Docker и NVIDIA Container Toolkit уже стоят, этот раздел можно пропустить.

1. Драйвер NVIDIA: `nvidia-smi` должен показывать видеокарту.
2. Docker Engine: https://docs.docker.com/engine/install/ubuntu/
3. Docker без sudo: `sudo usermod -aG docker $USER`, затем перелогиниться.
4. NVIDIA Container Toolkit:
   https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html

Проверка, что контейнеры видят видеокарту:

```bash
docker run --rm --gpus all ubuntu nvidia-smi
```

## Доступ к репозиторию

Репозиторий закрытый: доступ есть у участников зарегистрированных команд и у организаторов. Приглашение в
организацию `nssr-hackathon` приходит на почту, указанную при регистрации. Примите его своим аккаунтом GitHub,
после этого откроются основной репозиторий и репозиторий решения вашей команды.

Работайте только в выданных репозиториях: основном и репозитории своей команды `nssr-sol-team-NNN`. Создавать
свои репозитории в организации и делать форки нельзя, решение сдаётся только в репозиторий команды.

В организации обязательна двухфакторная аутентификация безопасным способом: приложение-аутентификатор,
GitHub Mobile, passkey или ключ безопасности. С двухфакторкой через SMS приглашение принять можно, но доступ к
репозиториям будет закрыт. Если у вас настроены SMS, добавьте безопасный способ и уберите SMS в настройках
аккаунта: Settings, Password and authentication.

Скачивать репозиторий и ассеты нужно через GitHub CLI под этим же аккаунтом. Ставьте GitHub CLI из репозитория
GitHub (https://github.com/cli/cli/blob/trunk/docs/install_linux.md): пакет `gh` из стандартных репозиториев
Ubuntu 22.04 слишком старый.

```bash
gh auth login             # GitHub.com, HTTPS, вход через браузер
gh auth setup-git         # git использует этот же вход
gh auth status            # проверить, что вошли нужным аккаунтом
```

## Установка

```bash
gh repo clone nssr-hackathon/nssr-uwt-polygon nssr-polygon && cd nssr-polygon
bash hackathon/tools/get_assets.sh     # модель робота и ассеты склада, около 0.7 ГБ
bash hackathon/docker/run.sh build    # образ, с VPN: скачивание около 8.5 ГБ и сборка около 10 минут
bash hackathon/docker/run.sh start    # контейнер
bash hackathon/docker/run.sh init     # один раз для нового контейнера
bash hackathon/docker/run.sh check    # проверка окружения
```

Модель робота и ассеты склада Isaac Sim в git не лежат, они приложены архивом `nssr-polygon-assets.tar` к релизу
репозитория. `get_assets.sh` скачивает архив последнего релиза под вашим входом в GitHub CLI и распаковывает его
в `assets/`. Если загрузка оборвалась, запустите скрипт ещё раз, он докачает. Если скрипт пишет `no access`,
проверьте `gh auth status`: вход должен быть тем аккаунтом, который принял приглашение. Архив, скачанный вручную
со страницы релиза, распаковывается так: `bash hackathon/tools/get_assets.sh путь/к/nssr-polygon-assets.tar`.

Сборка образа скачивает базовый образ NVIDIA Isaac Lab с nvcr.io. Из России nvcr.io отвечает `403 Forbidden`,
поэтому на время `run.sh build` включите VPN. После сборки VPN не нужен: симулятор работает без интернета.

`check` должен вывести только строки `[OK]`. Если контейнер был создан до распаковки ассетов, его нужно пересоздать:
`run.sh rm`, `run.sh start`, `run.sh init`.

## Запуск задачи

Все скрипты `hackathon/tools/*.sh` и `hackathon/docker/run.sh` запускаются на хосте из корня репозитория, не
внутри контейнера: они сами обращаются к контейнеру через docker.

```bash
bash hackathon/tools/task.sh list              # задачи, пулы объектов, варианты пробирок
bash hackathon/tools/task.sh sort3 --pool 1    # симулятор с задачей
```

Первый запуск в новом контейнере идёт около 5 минут, Isaac Sim компилирует шейдеры. Окно в это время может
показать "Isaac Sim is not responding": нажмите "Wait". Кэш шейдеров сохраняется в `~/.cache/nssr-sim`, дальше
симулятор стартует примерно за 30 секунд. Остановить симулятор: Ctrl+C в этом терминале.

Во втором терминале, пока симулятор работает:

```bash
bash hackathon/tools/ros.sh ros2 topic list
bash hackathon/tools/ros.sh python3 /nssr_sim/hackathon/tools/check_interfaces.py   # проверка всех интерфейсов
bash hackathon/tools/objects.sh randomize                                           # новая раскладка объектов
bash hackathon/tools/task.sh check                                                  # самопроверка задачи
```

`check_interfaces.py` по очереди двигает каждым мотором и пальцем, поэтому запускайте его, пока ваш код роботом
не управляет. В конце должно быть `RESULT: ALL OK`.

## Свой код

`hackathon/ros2/hello_world` это шаблон пакета ROS 2: читает суставы, головную камеру и задачу, поворачивает
голову и сжимает кисть. С него удобно начинать.

```bash
bash hackathon/tools/ros.sh "cd /nssr_sim/hackathon/ros2 && colcon build --packages-select hello_world && \
  source install/setup.bash && ros2 run hello_world hello"
```

Свои узлы можно запускать в контейнере симулятора через `hackathon/tools/ros.sh` (репозиторий смонтирован в
`/nssr_sim`) или в любом окружении с ROS 2 Humble на этой же машине. Для этого нужны:

- `ROS_DOMAIN_ID=146`;
- `FASTRTPS_DEFAULT_PROFILES_FILE=<репозиторий>/hackathon/docker/fastdds_hack.xml`, в нём общая память для кадров
  камер;
- пакет сообщений робота `teleoperation/msgs/ros-humble-bodyctrl-msgs_0.0.1-1_amd64.deb`;
- `use_sim_time:=true` для всех узлов.

Решение сдаётся в репозиторий команды в формате из [SCORING.md](hackathon/docs/SCORING.md). Проверить, что оно
ставится и запускается так же, как на итоговой проверке (при запущенном симуляторе):
`bash hackathon/tools/solution.sh ~/nssr-sol-team-NNN`.

Облака точек обеих камер и дерево TF можно посмотреть в RViz2: `bash hackathon/tools/viz_rviz.sh`. Скрипт один раз
собирает отдельный образ с RViz2.

## Управление контейнером

```bash
bash hackathon/docker/run.sh stop     # остановить
bash hackathon/docker/run.sh start    # запустить снова
bash hackathon/docker/run.sh bash     # оболочка внутри контейнера с ROS 2
bash hackathon/docker/run.sh rm       # удалить контейнер (образ, кэш и репозиторий остаются)
```

Переменные окружения для `run.sh`: `SIM_CONTAINER`, `SIM_IMAGE`, `SIM_CACHE_DIR`, `ISAAC_ASSETS` (папка с ассетами
Isaac Sim, по умолчанию `assets/isaac`).

## Если что-то не так

- `run.sh build` падает с `403 Forbidden` на `nvcr.io/nvidia/isaac-lab`: nvcr.io недоступен из вашей сети,
  соберите образ с VPN.
- `check` пишет `no robot model` или склад пустой: не распакованы ассеты, см. раздел "Установка".
- `docker: could not select device driver "" with capabilities: [[gpu]]`: не установлен или не настроен NVIDIA
  Container Toolkit.
- Окно Isaac не открывается, ошибка про `DISPLAY`: запускайте из графической сессии; `run.sh start` сам выполняет
  `xhost +local:`.
- `Warp CUDA error: Failed to get driver entry point 'cuDeviceGetUuid'` при старте: это предупреждение, на работу
  не влияет.
- Симулятор медленный: раздел "Если тормозит" в [TASKS.md](hackathon/docs/TASKS.md).

## Вопросы

- Установка и запуск симулятора, ошибки, документация: в чате хакатона или в Issues этого репозитория. Их видят все
  команды, поэтому код своего решения сюда не выкладывайте.
- Вопросы по своему решению: в Issues репозитория своей команды `nssr-sol-team-NNN`, с упоминанием разработчика
  симулятора `@nssnikolas`. Такой вопрос видят только ваша команда и организаторы.

## Лицензия

Код распространяется по лицензии Apache 2.0, см. [LICENSE](LICENSE). Авторство исходных компонентов указано в
заголовках файлов. Модели объектов распространяются по CC BY 4.0, источники перечислены в
[hackathon/assets/objects/ATTRIBUTION.md](hackathon/assets/objects/ATTRIBUTION.md). Ассеты склада из архива релиза
взяты из Isaac Sim и используются на условиях лицензии NVIDIA.
