#!/bin/bash
# Downloads the asset archive of the latest release (robot model, warehouse) and unpacks it into the repository.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
set -e
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
NAME=nssr-polygon-assets.tar
ROBOT_USD="$ROOT/assets/robots/tiangong_pro/tiangong_pro_v2.usd"
PART="$ROOT/$NAME.part"

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then
  cat <<TXT
Robot model and warehouse assets (host, from the repository root):
  bash hackathon/tools/get_assets.sh             download $NAME of the latest release and unpack it
  bash hackathon/tools/get_assets.sh FILE.tar    unpack an archive downloaded by hand
Needs the GitHub CLI logged in with an account that has access to the repository: gh auth login
An interrupted download continues when the command is run again.
Env: TAG=v1.0 (a specific release instead of the latest), ASSETS_REPO=owner/name (if there is no git remote)
TXT
  exit 0
fi

if [ -n "${1:-}" ]; then
  [ -f "$1" ] || { echo "[get_assets] no such file: $1"; exit 1; }
  ARCHIVE="$1"
else
  command -v gh >/dev/null || {
    echo "[get_assets] GitHub CLI is not installed: https://github.com/cli/cli/blob/trunk/docs/install_linux.md"; exit 1; }
  gh auth status >/dev/null 2>&1 || { echo "[get_assets] log in to GitHub first: gh auth login"; exit 1; }
  REPO=${ASSETS_REPO:-$(cd "$ROOT" && gh repo view --json nameWithOwner -q .nameWithOwner 2>/dev/null || true)}
  [ -n "$REPO" ] || { echo "[get_assets] repository unknown (no git remote): ASSETS_REPO=owner/name bash $0"; exit 1; }
  REL=latest; [ -n "${TAG:-}" ] && REL="tags/$TAG"
  ASSET=$(gh api "repos/$REPO/releases/$REL" -q ".assets[] | select(.name==\"$NAME\") | .url" 2>/dev/null || true)
  if [ -z "$ASSET" ]; then
    echo "[get_assets] no access to the release of $REPO or no $NAME in it."
    echo "  Check that the account in 'gh auth status' accepted the invitation to the organization"
    echo "  and is in a team of the hackathon; then run the command again."
    exit 1
  fi
  echo "[get_assets] $REPO, release $REL"
  TOKEN=$(gh auth token 2>/dev/null || true)
  if [ -n "$TOKEN" ] && curl -fL --retry 10 --retry-delay 3 -C - -o "$PART" \
       -H "Authorization: Bearer $TOKEN" -H "Accept: application/octet-stream" "$ASSET"; then
    :
  else
    echo "[get_assets] downloading with gh release download (no resume)"
    rm -f "$PART"; TMP=$(mktemp -d "$ROOT/.assets_dl.XXXX")
    if [ "$REL" = latest ]; then gh release download -R "$REPO" -p "$NAME" -D "$TMP"
    else gh release download "$TAG" -R "$REPO" -p "$NAME" -D "$TMP"; fi
    mv "$TMP/$NAME" "$PART"; rmdir "$TMP"
  fi
  ARCHIVE="$PART"
fi

echo "[get_assets] unpacking into $ROOT"
tar xf "$ARCHIVE" -C "$ROOT"
[ "$ARCHIVE" = "$PART" ] && rm -f "$PART"

size=$(stat -c %s "$ROBOT_USD" 2>/dev/null || echo 0)
if [ "$size" -lt 1000000 ] || [ ! -d "$ROOT/assets/isaac/Assets/Isaac" ]; then
  echo "[get_assets] the archive is incomplete: no robot model or assets/isaac"; exit 1
fi
echo "[get_assets] OK: robot model $((size / 1000000)) MB, Isaac assets in assets/isaac"
echo "[get_assets] a container created before this needs: bash hackathon/docker/run.sh rm && bash hackathon/docker/run.sh start && bash hackathon/docker/run.sh init"
