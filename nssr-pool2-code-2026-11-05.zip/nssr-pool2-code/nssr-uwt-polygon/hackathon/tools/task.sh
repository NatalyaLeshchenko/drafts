#!/bin/bash
# Starts the simulator with a task, an object pool and a variant.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
cd "$(dirname "$0")/../.." || exit 1
SIM=${SIM_CONTAINER:-nssr-sim}

py() {
  if python3 -c "import yaml" 2>/dev/null; then python3 hackathon/tools/task_info.py "$@"
  else docker exec "$SIM" bash -c "cd /nssr_sim && python3 hackathon/tools/task_info.py $*"; fi
}

usage() {
  cat <<'TXT'
Start the simulator with a task (host, from the repository root):
  bash hackathon/tools/task.sh list                        tasks, object pools, tube variants
  bash hackathon/tools/task.sh sort3 --pool 2              sorting: 3 categories of pool 2, 3 trays
  bash hackathon/tools/task.sh sort2 --pool 4 --seed 7     sorting: 2 categories, 2 trays, layout seed 7
  bash hackathon/tools/task.sh tubes --variant color       test tubes into the fume hood: easy|standard|color|lying
  bash hackathon/tools/task.sh info                        (simulator running) what goes where
  bash hackathon/tools/task.sh check                       (simulator running) self-check: how much is done
Options: --pool N  --variant V  --seed S  --media (2K, quality)  --headless  --cams head  -- <run_sim.sh args>
TXT
}

case "$1" in
  ""|-h|--help) usage; exit 0 ;;
  list) py list; exit $? ;;
  info) exec bash hackathon/tools/objects.sh task ;;
  check) exec bash hackathon/tools/objects.sh check ;;
esac

TASK=$1; shift
POOL=""; VAR=""; ARGS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --pool) POOL=$2; shift 2 ;;
    --variant) VAR=$2; shift 2 ;;
    --seed) export HACK_SEED=$2; shift 2 ;;
    --media) export HACK_MEDIA=1; shift ;;
    --headless) export HACK_HEADLESS=1; shift ;;
    --cams) export HACK_CAMS=$2; shift 2 ;;
    --) shift; ARGS+=("$@"); break ;;
    *) ARGS+=("$1"); shift ;;
  esac
done
V=(validate "$TASK"); [ -n "$POOL" ] && V+=(--pool "$POOL"); [ -n "$VAR" ] && V+=(--variant "$VAR")
py "${V[@]}" || exit 1
export HACK_TASK=$TASK
[ -n "$POOL" ] && export HACK_POOL=$POOL
[ -n "$VAR" ] && export HACK_TUBES=$VAR
unset HACK_OBJECTS
exec bash hackathon/tools/run_sim.sh "${ARGS[@]}"
