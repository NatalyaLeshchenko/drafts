#!/bin/bash
# Installs and starts a team solution as the final check does: a fresh container from the simulator image, a copy of
# the solution repo in /solution, ROS 2 to the running simulator.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
set -e
SRC=${1:-}
if [ -z "$SRC" ] || [ ! -f "$SRC/run.sh" ]; then
  echo "usage: bash hackathon/tools/solution.sh PATH_TO_SOLUTION_REPO   (the folder must contain run.sh)"
  exit 1
fi
SRC=$(cd "$SRC" && pwd)
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
IMAGE=${SIM_IMAGE:-nssr-sim:latest}
NAME=${SOLUTION_CONTAINER:-nssr-solution}
docker rm -f "$NAME" >/dev/null 2>&1 || true
docker run --rm -it --name "$NAME" --gpus all --network host --ipc host \
  -v "$SRC:/mnt/solution:ro" \
  -v "$ROOT/hackathon/docker/fastdds_hack.xml:/etc/nssr/fastdds.xml:ro" \
  -e ROS_DOMAIN_ID=146 -e FASTRTPS_DEFAULT_PROFILES_FILE=/etc/nssr/fastdds.xml \
  --entrypoint bash "$IMAGE" -c '
set -e
mkdir -p /solution && cp -a /mnt/solution/. /solution/ && cd /solution && rm -rf build install log
if [ -s apt.txt ]; then
  echo "[solution] apt.txt"; apt-get update -qq && xargs -a apt.txt apt-get install -y --no-install-recommends
fi
if [ -s requirements.txt ]; then
  echo "[solution] requirements.txt"; /usr/bin/python3 -m pip install -r requirements.txt
fi
if [ -f setup.sh ]; then
  echo "[solution] setup.sh"; bash setup.sh
fi
source /opt/ros/humble/setup.bash
echo "[solution] colcon build"; colcon build
source install/setup.bash
echo "[solution] run.sh"; exec bash run.sh'
