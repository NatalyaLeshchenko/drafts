#!/bin/bash
# RViz2 with the point clouds of both cameras in a separate ROS 2 container.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
IMG=nssr-viz:humble
if ! docker image inspect $IMG >/dev/null 2>&1; then
  echo "[viz] building $IMG (once, needs internet)..."
  docker build -t $IMG - <<'DF' || exit 1
FROM osrf/ros:humble-desktop
RUN apt-get update && apt-get install -y --no-install-recommends ros-humble-depth-image-proc \
 && rm -rf /var/lib/apt/lists/*
DF
fi
xhost +local: >/dev/null 2>&1
docker run --rm -it --name nssr-viz --network host --ipc host -v /dev/shm:/dev/shm \
  -e DISPLAY="$DISPLAY" -v /tmp/.X11-unix:/tmp/.X11-unix \
  -e ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-146}" -e RMW_IMPLEMENTATION=rmw_fastrtps_cpp \
  -e FASTRTPS_DEFAULT_PROFILES_FILE=/hack/docker/fastdds_hack.xml \
  -e LIBGL_ALWAYS_SOFTWARE="${LIBGL_ALWAYS_SOFTWARE:-1}" \
  -v "$ROOT/hackathon:/hack:ro" $IMG bash -c '
source /opt/ros/humble/setup.bash
for c in cam_head cam_torso; do
  ros2 run depth_image_proc point_cloud_xyzrgb_node --ros-args -r __node:=cloud_$c \
    -r rgb/image_rect_color:=/$c/color/image_raw -r rgb/camera_info:=/$c/color/camera_info \
    -r depth_registered/image_rect:=/$c/depth/image_raw -r points:=/$c/points \
    -p use_sim_time:=true &
done
rviz2 -d /hack/tools/hack.rviz --ros-args -p use_sim_time:=true
kill %1 %2 2>/dev/null'
