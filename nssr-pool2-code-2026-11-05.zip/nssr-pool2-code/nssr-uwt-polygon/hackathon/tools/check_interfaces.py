#!/usr/bin/env python3
# Checks every robot interface of the simulator: topics and rates, services, each motor and finger moving.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import sys, time
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from rosgraph_msgs.msg import Clock
from sensor_msgs.msg import JointState, Image, CameraInfo
from std_msgs.msg import String
from tf2_msgs.msg import TFMessage
from geometry_msgs.msg import WrenchStamped
from bodyctrl_msgs.msg import CmdSetMotorPosition, SetMotorPosition, MotorStatusMsg, CmdSetMotorSpeed, SetMotorSpeed

TOPICS = [
    ("/clock", Clock, 20), ("/joint_states", JointState, 20), ("/tf", TFMessage, 10),
    ("/arm/status", MotorStatusMsg, 20), ("/head/status", MotorStatusMsg, 20), ("/waist/status", MotorStatusMsg, 20),
    ("/inspire_hand/state/left_hand", JointState, 20), ("/inspire_hand/state/right_hand", JointState, 20),
    ("/cam_head/color/image_raw", Image, 5), ("/cam_head/depth/image_raw", Image, 5),
    ("/cam_head/color/camera_info", CameraInfo, 5), ("/cam_head/depth/camera_info", CameraInfo, 5),
    ("/cam_torso/color/image_raw", Image, 5), ("/cam_torso/depth/image_raw", Image, 5),
    ("/cam_torso/color/camera_info", CameraInfo, 5),
    ("/arm_6dof_left", WrenchStamped, 20), ("/arm_6dof_right", WrenchStamped, 20),
    ("/sim/objects/names", String, 0), ("/sim/task", String, 0),
]
SERVICES = [f"/inspire_hand/{k}/{s}_hand" for k in ("set_angle_flexible", "set_speed", "set_force", "set_clear_error")
            for s in ("left", "right")]
COMMANDS = ["/arm/cmd_pos", "/arm/cmd_ctrl", "/head/cmd_pos", "/head/cmd_ctrl", "/waist/cmd_pos", "/waist/cmd_ctrl",
            "/arm/cmd_vel", "/head/cmd_vel", "/waist/cmd_vel",
            "/inspire_hand/ctrl/left_hand", "/inspire_hand/ctrl/right_hand",
            "/sim/objects/set", "/sim/objects/randomize", "/sim/task/check"]
NOT_IN_SIM = ["/hric/robot/float_base_rpyz_cmd (torso pitch/roll/height: real robot only, sim torso = yaw 31)",
              "/leg/* (legs are fixed in the sim)"]
MOTORS = {1: ("head_roll_joint", "head", 0.2), 2: ("head_pitch_joint", "head", 0.2), 3: ("head_yaw_joint", "head", 0.3),
          31: ("body_yaw_joint", "waist", 0.25),
          11: ("shoulder_pitch_l_joint", "arm", 0.2), 12: ("shoulder_roll_l_joint", "arm", 0.2),
          13: ("shoulder_yaw_l_joint", "arm", 0.3), 14: ("elbow_pitch_l_joint", "arm", -0.3),
          15: ("elbow_yaw_l_joint", "arm", 0.3), 16: ("wrist_pitch_l_joint", "arm", 0.2), 17: ("wrist_roll_l_joint", "arm", 0.3),
          21: ("shoulder_pitch_r_joint", "arm", 0.2), 22: ("shoulder_roll_r_joint", "arm", -0.2),
          23: ("shoulder_yaw_r_joint", "arm", -0.3), 24: ("elbow_pitch_r_joint", "arm", -0.3),
          25: ("elbow_yaw_r_joint", "arm", -0.3), 26: ("wrist_pitch_r_joint", "arm", 0.2), 27: ("wrist_roll_r_joint", "arm", -0.3)}
FINGERS = {1: "little_1_joint", 2: "ring_1_joint", 3: "middle_1_joint", 4: "index_1_joint", 5: "thumb_2_joint", 6: "thumb_1_joint"}
GROUP_IDS = {g: [m for m, v in MOTORS.items() if v[1] == g] for g in ("head", "waist", "arm")}


class Checker(Node):
    def __init__(self):
        super().__init__("hack_check_interfaces")
        self.count, self.t, self.js, self.last = {}, None, {}, {}
        latched = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL, reliability=ReliabilityPolicy.RELIABLE)
        for name, typ, rate in TOPICS:
            self.count[name] = 0
            qos = latched if rate == 0 else 10
            self.create_subscription(typ, name, lambda m, n=name: self._hit(n, m), qos)
        self.pub = {g: self.create_publisher(CmdSetMotorPosition, f"/{g}/cmd_pos", 10) for g in GROUP_IDS}
        self.hand = {s: self.create_publisher(JointState, f"/inspire_hand/ctrl/{s}_hand", 10) for s in ("left", "right")}
        self.vel = {g: self.create_publisher(CmdSetMotorSpeed, f"/{g}/cmd_vel", 10) for g in GROUP_IDS}

    def _hit(self, name, m):
        self.count[name] += 1
        self.last[name] = m
        if name == "/clock":
            self.t = m.clock.sec + m.clock.nanosec * 1e-9
        elif name == "/joint_states":
            self.js = dict(zip(m.name, m.position))

    def spin_for(self, wall_s):
        t0 = time.time()
        while time.time() - t0 < wall_s:
            rclpy.spin_once(self, timeout_sec=0.02)

    def wait_sim(self, sim_s, keep=None):
        t0, w0 = self.t, time.time()
        while (self.t is None or t0 is None or self.t - t0 < sim_s) and time.time() - w0 < 10 + 4 * sim_s:
            if keep:
                keep()
            rclpy.spin_once(self, timeout_sec=0.02)

    def send(self, targets, spd=None):
        for g, ids in GROUP_IDS.items():
            m = CmdSetMotorPosition()
            m.cmds = [SetMotorPosition(name=i, pos=float(targets[i]), spd=float((spd or {}).get(i, 0.0)), cur=5.0)
                      for i in ids]
            self.pub[g].publish(m)

    def send_vel(self, group, mid, v):
        m = CmdSetMotorSpeed()
        m.cmds = [SetMotorSpeed(name=mid, spd=float(v), cur=5.0)]
        self.vel[group].publish(m)

    def send_hand(self, side, pos):
        js = JointState(); js.name = [str(i) for i in range(1, 7)]; js.position = [float(p) for p in pos]
        self.hand[side].publish(js)


def main():
    rclpy.init()
    n = Checker()
    print("== 1. topics (6 s) ==", flush=True)
    n.spin_for(1.0)
    for name, _, rate in TOPICS:
        if rate:
            n.count[name] = 0
    t_sim0 = n.t
    n.spin_for(6.0)
    dt_sim = (n.t - t_sim0) if (n.t and t_sim0) else None
    ok_all = True
    for name, typ, rate in TOPICS:
        c = n.count[name]
        pubs = n.count_publishers(name)
        hz = c / 6.0
        good = (c > 0) if rate == 0 else hz >= rate * 0.5
        if name.startswith("/cam_torso") and pubs == 0:
            print(f"  n/a  {name:42s} (torso camera off: HACK_CAMS)"); continue
        ok_all &= good
        print(f"  {'OK  ' if good else 'FAIL'} {name:42s} {'latched' if rate == 0 else f'{hz:6.1f} Hz (wall)'}  publishers {pubs}")
    if dt_sim is not None:
        print(f"  sim speed: {dt_sim / 6.0:.2f} x real time")
    print("== 2. command topics: the sim listens ==")
    for name in COMMANDS:
        s = n.count_subscribers(name)
        ok_all &= s > 0
        print(f"  {'OK  ' if s > 0 else 'FAIL'} {name:42s} subscribers {s}")
    names = {nm for nm, _ in n.get_service_names_and_types()}
    for name in SERVICES:
        good = name in names
        ok_all &= good
        print(f"  {'OK  ' if good else 'FAIL'} {name:42s} service")
    for name in NOT_IN_SIM:
        print(f"  n/a  {name}")
    hs = n.last.get("/inspire_hand/state/right_hand")
    if hs is not None:
        good = len(hs.position) == 6 and len(hs.velocity) == 6 and len(hs.effort) == 6
        ok_all &= good
        print(f"  {'OK  ' if good else 'FAIL'} hand state has position/velocity/effort x6")
    for side in ("left", "right"):
        w = n.last.get(f"/arm_6dof_{side}")
        if w is not None:
            f = (w.wrench.force.x ** 2 + w.wrench.force.y ** 2 + w.wrench.force.z ** 2) ** 0.5
            print(f"  info /arm_6dof_{side}: |F| = {f:.2f} N, frame {w.header.frame_id} (empty hand: should be ~0)")
    if "--no-motion" in sys.argv:
        print("== motion test skipped ==")
        return
    print("== 3. motion: each motor +delta and back (sim time 1.0 s each way) ==", flush=True)
    if not n.js:
        print("  FAIL no /joint_states"); return
    home = {i: float(n.js.get(j, 0.0)) for i, (j, _, _) in MOTORS.items()}
    for i, (j, g, d) in MOTORS.items():
        tgt = dict(home); tgt[i] = home[i] + d
        n.wait_sim(1.0, keep=lambda: n.send(tgt))
        moved = n.js.get(j, 0.0) - home[i]
        good = abs(moved - d) < 0.35 * abs(d)
        ok_all &= good
        print(f"  {'OK  ' if good else 'FAIL'} {i:2d} {j:26s} cmd {d:+.2f}  got {moved:+.3f} rad", flush=True)
        n.wait_sim(1.0, keep=lambda: n.send(home))
    print("== 3b. SDK semantics: spd, cmd_vel, hand set_speed ==", flush=True)
    yaw0 = float(n.js.get("head_yaw_joint", 0.0))
    tgt = dict(home); tgt[3] = yaw0 + 0.5
    n.wait_sim(1.0, keep=lambda: n.send(tgt, {3: 0.25}))
    moved = n.js.get("head_yaw_joint", 0.0) - yaw0
    good = 0.15 < moved < 0.35
    ok_all &= good
    print(f"  {'OK  ' if good else 'FAIL'} cmd_pos +0.50 at spd 0.25 rad/s: after 1.0 s {moved:+.3f} (expect ~+0.25)", flush=True)
    n.wait_sim(1.0, keep=lambda: n.send(home))
    yaw0 = float(n.js.get("head_yaw_joint", 0.0))
    n.wait_sim(1.0, keep=lambda: n.send_vel("head", 3, -0.3))
    moved = n.js.get("head_yaw_joint", 0.0) - yaw0
    good = -0.40 < moved < -0.20
    ok_all &= good
    print(f"  {'OK  ' if good else 'FAIL'} cmd_vel -0.30 rad/s for 1.0 s: {moved:+.3f} (expect ~-0.30)", flush=True)
    n.wait_sim(1.0, keep=lambda: n.send(home))
    try:
        from bodyctrl_msgs.srv import SetSpeed
        cli = n.create_client(SetSpeed, "/inspire_hand/set_speed/right_hand")
        if cli.wait_for_service(timeout_sec=3.0):
            def speed(v):
                rq = SetSpeed.Request()
                for k in range(6):
                    setattr(rq, f"speed{k}_ratio", v)
                fut = cli.call_async(rq)
                rclpy.spin_until_future_complete(n, fut, timeout_sec=3.0)
            speed(0.25)
            pos = [1.0] * 6; pos[3] = 0.0
            n.wait_sim(0.8, keep=lambda: n.send_hand("right", pos))
            p = n.last.get("/inspire_hand/state/right_hand")
            v = p.position[3] if p is not None else -1
            good = 0.6 < v < 0.9
            ok_all &= good
            print(f"  {'OK  ' if good else 'FAIL'} set_speed 0.25, index 1 -> 0: after 0.8 s at {v:.2f} (expect ~0.75)")
            speed(1.0)
            n.wait_sim(1.5, keep=lambda: n.send_hand("right", [1.0] * 6))
        else:
            ok_all = False
            print("  FAIL /inspire_hand/set_speed/right_hand: no service")
    except Exception as e:
        ok_all = False
        print(f"  FAIL set_speed test: {e}")
    print("== 4. fingers: each finger to 0.3 (0 = closed, 1 = open) and back ==", flush=True)
    for side in ("left", "right"):
        for k, f in FINGERS.items():
            joint = f"{side}_{f}"
            a = n.js.get(joint, 0.0)
            pos = [1.0] * 6; pos[k - 1] = 0.3
            n.wait_sim(0.8, keep=lambda: n.send_hand(side, pos))
            moved = abs(n.js.get(joint, 0.0) - a)
            good = moved > 0.15
            ok_all &= good
            print(f"  {'OK  ' if good else 'FAIL'} {side:5s} {k} {f:16s} moved {moved:.3f} rad", flush=True)
            n.wait_sim(0.6, keep=lambda: n.send_hand(side, [1.0] * 6))
    print("== RESULT:", "ALL OK" if ok_all else "SOME CHECKS FAILED (see FAIL lines)", "==")
    n.destroy_node()
    rclpy.try_shutdown()


if __name__ == "__main__":
    main()
