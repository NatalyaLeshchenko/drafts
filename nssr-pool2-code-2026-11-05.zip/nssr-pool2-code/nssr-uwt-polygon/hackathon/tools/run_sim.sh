#!/bin/bash
# Starts the simulator in its container and writes the log to logs/.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
  cat <<'TXT'
Start the simulator (host, from the repository root). Easier: hackathon/tools/task.sh
Environment variables:
  HACK_TASK=sort2|sort3|tubes  HACK_POOL=N  HACK_TUBES=easy|standard|color|lying
  HACK_SEED=S              fixed layout (default: a new random layout on every start)
  HACK_HEADLESS=1          no Isaac window (cameras still work), for weaker GPUs
  HACK_RES=2560x1440       render resolution
  HACK_MEDIA=1             quality preset for screenshots and video (slower)
  HACK_CAMS=head           only the head camera (faster); default head,torso
  HACK_TORSO_DEPTH=0       torso camera without depth
  HACK_VIEWPORT_SCALE=0.5  Isaac window rendered at half resolution (faster)
  HACK_RENDER_INTERVAL=3   physics steps per camera frame
  HACK_RENDER_MODE=performance|balanced|quality
TXT
  exit 0
fi
SIM=${SIM_CONTAINER:-nssr-sim}
TS=$(date +%Y%m%d_%H%M%S)
ROBOT_USD="$(cd "$(dirname "$0")/../.." && pwd)/assets/robots/tiangong_pro/tiangong_pro_v2.usd"
if [ "$(stat -c %s "$ROBOT_USD" 2>/dev/null || echo 0)" -lt 1000000 ]; then
  echo "[run_sim] no robot model: bash hackathon/tools/get_assets.sh"; exit 1
fi
if [ "${HACK_MEDIA:-0}" = "1" ]; then
  export HACK_RES=${HACK_RES:-2560x1440} HACK_RENDER_MODE=${HACK_RENDER_MODE:-quality} HACK_RENDER_INTERVAL=${HACK_RENDER_INTERVAL:-2}
fi
[ -n "${HACK_SEED:-}" ] || export HACK_SEED=$RANDOM
echo "[run_sim] layout seed $HACK_SEED (same layout again: --seed $HACK_SEED)"
export HACK_RES=${HACK_RES:-2560x1440}
if [ "${HACK_CUTOUT:-1}" = "1" ]; then
  export HACK_KIT_ARGS="$HACK_KIT_ARGS --/rtx/raytracing/fractionalCutoutOpacity=true --/rtx/pathtracing/fractionalCutoutOpacity=true"
fi
export HACK_KIT_ARGS="$HACK_KIT_ARGS --/rtx/translucency/maxRefractionBounces=${HACK_REFRACTION_BOUNCES:-4}"
[ "${HACK_KIT_RATE_LIMIT:-0}" = "1" ] || export HACK_KIT_ARGS="$HACK_KIT_ARGS --/app/runLoops/main/rateLimitEnabled=false"
export HACK_RENDER_INTERVAL=${HACK_RENDER_INTERVAL:-3}
if [ -n "$HACK_RES" ]; then
  export HACK_KIT_ARGS="$HACK_KIT_ARGS --/app/renderer/resolution/width=${HACK_RES%x*} --/app/renderer/resolution/height=${HACK_RES#*x}"
fi
ENVS=(-e FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml)
for v in $(env | grep -o '^HACK_[A-Z0-9_]*'); do ENVS+=(-e "$v=${!v}"); done
EXTRA="--perf_stats --step_hz ${HACK_STEP_HZ:-$((100 / ${HACK_DECIMATION:-1}))}"
[ "${HACK_HEADLESS:-0}" = "1" ] && EXTRA="$EXTRA --headless"
EXTRA="$EXTRA --device ${HACK_DEVICE:-cpu}"
[ -n "$HACK_RENDER_MODE" ] && EXTRA="$EXTRA --rendering_mode $HACK_RENDER_MODE"
HDR="[run_sim] $(env | grep '^HACK_' | sort | tr '\n' ' ' | tr -d "'") args: $EXTRA $*"
echo "$HDR -> logs/sim_$TS.log"
STOP="pkill -INT -f '[s]im_runner.py'; sleep 8; pkill -f '[r]os2_zmq_bridge'; pkill -f '[c]amera_bridge.py'; \
pkill -f '[r]obot_state_publisher'; pkill -f '[s]im_node.py'; pkill -9 -f '[s]im_runner.py'"
docker exec "$SIM" bash -c "pkill -f '[h]ack_sim_timer'; if pgrep -f '[s]im_runner.py|[r]os2_zmq_bridge|[c]amera_bridge.py|[s]im_node.py' >/dev/null; \
  then echo '[run_sim] stopping the previous sim / bridges first'; $STOP; fi; true"
if [ -n "$HACK_DURATION" ]; then IT=(); RUN="bash -c \"sleep $HACK_DURATION; $STOP\" hack_sim_timer >/dev/null 2>&1 & bash scripts/start_sim.sh"
else IT=(-it); RUN="bash scripts/start_sim.sh"; fi
docker exec "${IT[@]}" "${ENVS[@]}" "$SIM" bash -c "mkdir -p /nssr_sim/logs && cd /nssr_sim && echo '$HDR' > /nssr_sim/logs/sim_$TS.log && \
  $RUN $EXTRA $* 2>&1 | tee -a /nssr_sim/logs/sim_$TS.log"
