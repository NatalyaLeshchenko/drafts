#!/bin/bash
# Objects on the table from the host: names, task, self-check, random layouts and placing objects.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
SIM=${SIM_CONTAINER:-nssr-sim}
PRE="source /opt/ros/humble/setup.bash; export ROS_DOMAIN_ID=${ROS_DOMAIN_ID:-146}; export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml"
pub() {
  docker exec -e T="$1" -e K="$2" -e D="$3" "$SIM" bash -c "$PRE; python3 - <<'PY'
import os, sys, time, rclpy
from std_msgs.msg import String, Int32
t, k, d = os.environ['T'], os.environ['K'], os.environ['D']
rclpy.init(); n = rclpy.create_node('hack_objects_cli')
M = String if k == 'str' else Int32
p = n.create_publisher(M, t, 10)
t0 = time.time()
while p.get_subscription_count() == 0 and time.time() - t0 < 5.0:
    rclpy.spin_once(n, timeout_sec=0.1)
if p.get_subscription_count() == 0:
    print(f'no subscriber on {t}: is the sim running (hack_sim_node in the log)?'); sys.exit(1)
p.publish(M(data=d if k == 'str' else int(d))); time.sleep(0.3)
print(f'sent {t}: {d}')
PY"
}
latched() {
  docker exec -e T="$1" "$SIM" bash -c "$PRE; python3 - <<'PY'
import json, os, sys, time, rclpy
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from std_msgs.msg import String
rclpy.init(); n = rclpy.create_node('hack_latched_cli'); got = []
q = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL, reliability=ReliabilityPolicy.RELIABLE)
n.create_subscription(String, os.environ['T'], lambda m: got.append(m.data), q)
t0 = time.time()
while not got and time.time() - t0 < 6:
    rclpy.spin_once(n, timeout_sec=0.1)
if not got:
    print('nothing on ' + os.environ['T'] + ' in 6 s: is the sim running?'); sys.exit(1)
print(json.dumps(json.loads(got[-1]), ensure_ascii=False, indent=1))
PY"
}
check() {
  docker exec "$SIM" bash -c "$PRE; python3 - <<'PY'
import json, sys, time, rclpy
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from std_msgs.msg import String, Int32
rclpy.init(); n = rclpy.create_node('hack_check_cli')
got = []
q = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL, reliability=ReliabilityPolicy.RELIABLE)
n.create_subscription(String, '/sim/task/result', lambda m: got.append(json.loads(m.data)), q)
p = n.create_publisher(Int32, '/sim/task/check', 10)
t0 = time.time()
while (p.get_subscription_count() == 0 or n.count_publishers('/sim/task/result') == 0) and time.time() - t0 < 5:
    rclpy.spin_once(n, timeout_sec=0.1)
if p.get_subscription_count() == 0:
    print('no subscriber on /sim/task/check: is the sim running (hack_sim_node in the log)?'); sys.exit(1)
t0 = time.time()
while time.time() - t0 < 0.5:
    rclpy.spin_once(n, timeout_sec=0.05)
old = got[-1].get('sim_step', -1) if got else -1
p.publish(Int32(data=1))
t0 = time.time()
while time.time() - t0 < 8 and not (got and got[-1].get('sim_step', -1) > old):
    rclpy.spin_once(n, timeout_sec=0.1)
if not (got and got[-1].get('sim_step', -1) > old):
    print('no answer from the sim in 8 s: look for \"[hack] task check\" in the sim log'); sys.exit(1)
r = got[-1]
objs = r.pop('objects', {})
print(json.dumps(r, ensure_ascii=False))
for k, v in objs.items():
    print(f\"  {'OK ' if v.get('ok') else '-- '} {k}: {v}\")
PY"
}
case "$1" in
  names)     latched /sim/objects/names ;;
  task)      latched /sim/task ;;
  check)     check ;;
  randomize) pub /sim/objects/randomize int "${2:-$RANDOM}" ;;
  shuffle)   while true; do pub /sim/objects/randomize int "$RANDOM" || break; sleep "${2:-6}"; done ;;
  set)       python3 -c 'import json,sys; json.loads(sys.argv[1])' "$2" 2>/dev/null || { echo "bad JSON: $2"; exit 1; }
             pub /sim/objects/set str "$2" ;;
  *) cat <<'TXT'
Objects on the table (host, simulator running):
  bash hackathon/tools/objects.sh names                 loaded objects and their categories
  bash hackathon/tools/objects.sh task                  task description: category -> tray (or tubes -> racks)
  bash hackathon/tools/objects.sh check                 self-check: how many are in the right place
  bash hackathon/tools/objects.sh randomize [SEED]      new random layout
  bash hackathon/tools/objects.sh shuffle [PERIOD_S]    new random layout every PERIOD_S seconds, Ctrl+C to stop
  bash hackathon/tools/objects.sh set '{"<name>": [x, y, yaw]}'   place an object: x, y from the pelvis (m), yaw (rad)
TXT
  ;;
esac
