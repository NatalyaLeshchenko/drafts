#!/bin/bash
# Runs a ROS 2 command inside the simulator container.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
SIM=${SIM_CONTAINER:-nssr-sim}
if [ $# -eq 0 ]; then
  echo "Run a ROS 2 command in the simulator container: bash hackathon/tools/ros.sh ros2 topic list"; exit 0
fi
docker exec -it "$SIM" bash -c "source /opt/ros/humble/setup.bash; export ROS_DOMAIN_ID=${ROS_DOMAIN_ID:-146}; \
export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml; $*"
