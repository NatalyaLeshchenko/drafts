#!/usr/bin/env python3
# Lists the tasks, object pools and tube variants and validates a choice.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import argparse, os, sys
import yaml

CFG = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config"))


def load(name):
    with open(os.path.join(CFG, name)) as f:
        return yaml.safe_load(f)


def ru_names(objects_cfg):
    out = {}
    for c in objects_cfg["categories"].values():
        for o in c["objects"]:
            out[o["name"]] = o.get("ru", "")
    return out


def cmd_list():
    T, P, L, O = load("tasks.yaml"), load("pools.yaml")["pools"], load("lab.yaml"), load("objects.yaml")
    ru = ru_names(O)
    print("ЗАДАЧИ  (bash hackathon/tools/task.sh <задача> ...)")
    for k, t in T["tasks"].items():
        mark = "  (по умолчанию)" if k == T["default"] else ""
        print(f"  {k:7s} {t.get('ru', '')}{mark}")
    print("\nПУЛЫ ОБЪЕКТОВ ДЛЯ СОРТИРОВКИ  (--pool N; sort2 берёт первые две категории, sort3 все три)")
    for k, p in P.items():
        cats = list(p)
        note = "" if len(cats) >= 3 else "   [только sort2]"
        print(f"  пул {k}: {' / '.join(cats)}{note}")
        for c in cats:
            items = ", ".join(ru.get(n) or n for n in p[c])
            print(f"      {c:12s} {items}")
    print("\nВАРИАНТЫ ПРОБИРОК  (task.sh tubes --variant V)")
    for k, v in L["variants"].items():
        mark = "  (по умолчанию)" if k == T["tasks"]["tubes"].get("default_variant") else ""
        print(f"  {k:9s} {v.get('ru', '')}{mark}")
    print("\nСИД  (--seed S): раскладка объектов, занятые гнёзда штативов, цвета крышек. Без --seed при каждом запуске новая\n"
          "случайная раскладка, её сид печатается при старте. Тот же сид даёт ту же сцену.")


def cmd_validate(a):
    T = load("tasks.yaml")
    if a.task not in T["tasks"]:
        sys.exit(f"нет задачи '{a.task}'. Есть: {', '.join(T['tasks'])}")
    t = T["tasks"][a.task]
    if t["mode"] == "sort":
        P = load("pools.yaml")["pools"]
        key = str(a.pool or T.get("pools_default", 1))
        if key not in P:
            sys.exit(f"нет пула '{key}'. Есть: {', '.join(P)}")
        if len(P[key]) < t["categories"]:
            sys.exit(f"в пуле {key} {len(P[key])} категории, а {a.task} нужно {t['categories']}: возьмите sort2 или другой пул")
        print(f"{a.task}: пул {key}, категории {', '.join(list(P[key])[:t['categories']])}")
    else:
        L = load("lab.yaml")
        v = a.variant or t.get("default_variant", "standard")
        if v not in L["variants"]:
            sys.exit(f"нет варианта '{v}'. Есть: {', '.join(L['variants'])}")
        print(f"{a.task}: вариант {v}: {L['variants'][v].get('ru', '')}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["list", "validate"])
    ap.add_argument("task", nargs="?")
    ap.add_argument("--pool"); ap.add_argument("--variant")
    a = ap.parse_args()
    cmd_list() if a.cmd == "list" else cmd_validate(a)


if __name__ == "__main__":
    main()
