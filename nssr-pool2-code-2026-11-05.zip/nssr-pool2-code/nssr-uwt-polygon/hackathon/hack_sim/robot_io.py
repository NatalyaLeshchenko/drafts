# Robot extras computed in the simulator: finger effort, finger force limits and the wrist force/torque.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import math
import os
import xml.etree.ElementTree as ET

FINGERS = ("little", "ring", "middle", "index")
G = 9.81


def _qmat(q):
    w, x, y, z = q
    return [[1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)]]


def _mv(m, v):
    return [m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
            m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
            m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2]]


def _mtv(m, v):
    return [m[0][0] * v[0] + m[1][0] * v[1] + m[2][0] * v[2],
            m[0][1] * v[0] + m[1][1] * v[1] + m[2][1] * v[2],
            m[0][2] * v[0] + m[1][2] * v[1] + m[2][2] * v[2]]


def _cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def _norm(v):
    return math.sqrt(sum(x * x for x in v))


URDF_REL = "assets/robots/tiangong_pro/tiangong_pro_with_hands.urdf"


def _find_urdf():
    if os.environ.get("HACK_URDF"):
        return os.environ["HACK_URDF"]
    d = os.path.dirname(os.path.abspath(__file__))
    for _ in range(8):
        if os.path.isfile(os.path.join(d, URDF_REL)):
            return os.path.join(d, URDF_REL)
        d = os.path.dirname(d)
    raise FileNotFoundError(URDF_REL)


def _rpy(r, p, y):
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    return [[cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
            [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
            [-sp, cp * sr, cp * cr]]


def _mm(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def _hand_model(urdf, root):
    rt = ET.parse(urdf).getroot()
    links = {l.get("name"): l for l in rt.findall("link")}
    kids = {}
    for j in rt.findall("joint"):
        o = j.find("origin")
        xyz = [float(v) for v in (o.get("xyz", "0 0 0") if o is not None else "0 0 0").split()]
        rpy = [float(v) for v in (o.get("rpy", "0 0 0") if o is not None else "0 0 0").split()]
        kids.setdefault(j.find("parent").get("link"), []).append((j.find("child").get("link"), xyz, _rpy(*rpy)))
    m_tot, mc = 0.0, [0.0, 0.0, 0.0]
    todo = [(root, [0.0, 0.0, 0.0], [[1, 0, 0], [0, 1, 0], [0, 0, 1]])]
    while todo:
        name, p, R = todo.pop()
        inert = links[name].find("inertial") if name in links else None
        if inert is not None and inert.find("mass") is not None:
            m = float(inert.find("mass").get("value"))
            o = inert.find("origin")
            c = [float(v) for v in (o.get("xyz", "0 0 0") if o is not None else "0 0 0").split()]
            cw = _mv(R, c)
            m_tot += m
            mc = [mc[k] + m * (p[k] + cw[k]) for k in range(3)]
        for child, xyz, Rj in kids.get(name, []):
            d = _mv(R, xyz)
            todo.append((child, [p[k] + d[k] for k in range(3)], _mm(R, Rj)))
    return m_tot, [x / m_tot for x in mc] if m_tot > 0 else [0.0, 0.0, 0.0]


def _subtree(urdf, root):
    kids = {}
    for j in ET.parse(urdf).getroot().findall("joint"):
        kids.setdefault(j.find("parent").get("link"), []).append(j.find("child").get("link"))
    out, todo = [], [root]
    while todo:
        n = todo.pop()
        out.append(n)
        todo += kids.get(n, [])
    return out


class RobotIO:
    def __init__(self, env):
        self.r = env.scene["robot"]
        r = self.r
        jn = list(r.joint_names)
        self.lim0 = r.root_physx_view.get_dof_max_forces()[0].clone().cpu()
        self.groups, self.main = {}, {}
        for side in ("left", "right"):
            g = [[i for i, n in enumerate(jn) if n.startswith(f"{side}_{f}_")] for f in FINGERS]
            g.append([i for i, n in enumerate(jn) if n.startswith(f"{side}_thumb_") and not n.startswith(f"{side}_thumb_1")])
            g.append([i for i, n in enumerate(jn) if n.startswith(f"{side}_thumb_1")])
            main = [f"{side}_{f}_1_joint" for f in FINGERS] + [f"{side}_thumb_2_joint", f"{side}_thumb_1_joint"]
            self.groups[side] = g
            self.main[side] = [jn.index(n) if n in jn else None for n in main]
        self.force = {"left": [1.0] * 6, "right": [1.0] * 6}
        self.ft, self.ft_sign, self.steps, self.calibrated = None, None, 0, set()
        if os.environ.get("HACK_FT", "1") == "1":
            try:
                self._init_ft()
            except Exception as e:
                print(f"[hack] wrist F/T off: {e}", flush=True)
                self.ft = None

    def set_force(self, d):
        import torch
        for side, ratios in (d or {}).items():
            if side not in self.groups or not isinstance(ratios, (list, tuple)) or len(ratios) != 6:
                continue
            ids, lims = [], []
            for k, ratio in enumerate(ratios):
                ratio = min(1.0, max(0.02, float(ratio)))
                self.force[side][k] = ratio
                for i in self.groups[side][k]:
                    ids.append(i)
                    lims.append(float(self.lim0[i]) * ratio)
            if ids:
                t = torch.tensor([lims], dtype=torch.float32, device=self.r.device)
                self.r.write_joint_effort_limit_to_sim(t, joint_ids=ids)
            print(f"[hack] {side} hand force limits: {[round(x, 2) for x in self.force[side]]}", flush=True)

    def finger_effort(self):
        tau = self.r.data.applied_torque[0].cpu().tolist()
        out = {}
        for side in ("left", "right"):
            v = []
            for k, i in enumerate(self.main[side]):
                if i is None:
                    v.append(0.0)
                    continue
                lim = float(self.lim0[i]) * self.force[side][k]
                v.append(round(min(1.0, abs(tau[i]) / lim), 3) if lim > 1e-9 else 0.0)
            out[side] = v
        return out

    def _init_ft(self):
        r = self.r
        bodies = list(r.body_names)
        self.ft, self.m = {}, {}
        for side, s in (("left", "l"), ("right", "r")):
            b, p = bodies.index(f"wrist_roll_{s}_link"), bodies.index(f"wrist_pitch_{s}_link")
            m, c = _hand_model(_find_urdf(), f"wrist_roll_{s}_link")
            self.ft[side] = (b, p, c)
            self.m[side] = m
        self._raw()
        print(f"[hack] wrist F/T on: hand mass from URDF {self.m}, COM in wrist_roll frame "
              f"{[round(x, 3) for x in self.ft['right'][2]]}", flush=True)

    def _raw(self):
        d = self.r.data
        w = getattr(d, "body_incoming_joint_wrench_b", None)
        if w is None:
            w = self.r.root_physx_view.get_link_incoming_joint_force()
        return w[0].cpu().tolist()

    def _gravity(self, side, Rc):
        c = _mv(Rc, self.ft[side][2])
        fg = [0.0, 0.0, -self.m[side] * G]
        return fg, _cross(c, fg)

    def wrist_ft(self):
        if self.ft is None:
            return None
        d = self.r.data
        quat = d.body_quat_w[0].cpu().tolist()
        raw = self._raw()
        self.steps += 1
        out = {}
        for side, (b, p, _) in self.ft.items():
            Rp, Rc = _qmat(quat[p]), _qmat(quat[b])
            fr, tr = _mv(Rp, raw[b][:3]), _mv(Rp, raw[b][3:6])
            if self.ft_sign is None or side not in self.calibrated:
                if self.steps < 40:
                    out[side] = [0.0] * 6
                    continue
                if self.ft_sign is None:
                    self.ft_sign = 1.0 if fr[2] > 0 else -1.0
                m = self.ft_sign * fr[2] / G
                m_urdf = self.m[side]
                if 0.3 * m_urdf < m < 3.0 * m_urdf:
                    self.m[side] = m
                fg, tg = self._gravity(side, Rc)
                ef = _norm([self.ft_sign * fr[k] + fg[k] for k in range(3)])
                et = _norm([self.ft_sign * tr[k] + tg[k] for k in range(3)])
                print(f"[hack] wrist F/T {side} calibrated: sign {self.ft_sign:+.0f}, hand mass {m:.3f} kg measured "
                      f"(URDF {m_urdf:.3f}, using {self.m[side]:.3f}), residual {ef:.2f} N / {et:.3f} Nm", flush=True)
                self.calibrated.add(side)
            fg, tg = self._gravity(side, Rc)
            sg = self.ft_sign
            keep_g = os.environ.get("HACK_FT_GRAVITY", "0") == "1"
            fe = [-(sg * fr[k] + (0.0 if keep_g else fg[k])) for k in range(3)]
            te = [-(sg * tr[k] + (0.0 if keep_g else tg[k])) for k in range(3)]
            out[side] = [round(x, 3) for x in _mtv(Rc, fe) + _mtv(Rc, te)]
        return out
