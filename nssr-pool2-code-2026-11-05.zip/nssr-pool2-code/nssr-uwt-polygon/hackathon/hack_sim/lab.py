# Test-tube task: builds the fume hood, racks and tubes, samples layouts and checks placed tubes.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import math, os, random
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
HACK = os.path.abspath(os.path.join(HERE, ".."))
GEN = os.path.join(os.environ.get("HACK_GEN_DIR", "/tmp/hack_gen"), "lab")
LAB = {}


def load_cfg():
    with open(os.path.join(HACK, "config", "lab.yaml")) as f:
        return yaml.safe_load(f)


def _stage(path, root):
    from . import props
    return props._stage(path, root)


def _mat(st, path, color, rough=0.5, metal=0.0, opacity=None, emissive=None, glass=False):
    from pxr import UsdShade, Sdf, Gf
    m = UsdShade.Material.Define(st, path)
    sh = UsdShade.Shader.Define(st, path + "/Shader")
    if glass:
        sh.SetSourceAsset(Sdf.AssetPath("OmniGlass.mdl"), "mdl")
        sh.SetSourceAssetSubIdentifier("OmniGlass", "mdl")
        sh.CreateInput("glass_color", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color))
        sh.CreateInput("frosting_roughness", Sdf.ValueTypeNames.Float).Set(rough)
        sh.CreateInput("glass_ior", Sdf.ValueTypeNames.Float).Set(1.49)
    else:
        sh.SetSourceAsset(Sdf.AssetPath("OmniPBR.mdl"), "mdl")
        sh.SetSourceAssetSubIdentifier("OmniPBR", "mdl")
        sh.CreateInput("diffuse_color_constant", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color))
        sh.CreateInput("reflection_roughness_constant", Sdf.ValueTypeNames.Float).Set(rough)
        sh.CreateInput("metallic_constant", Sdf.ValueTypeNames.Float).Set(metal)
        if opacity is not None:
            sh.CreateInput("enable_opacity", Sdf.ValueTypeNames.Bool).Set(True)
            sh.CreateInput("opacity_constant", Sdf.ValueTypeNames.Float).Set(opacity)
        if emissive is not None:
            sh.CreateInput("enable_emission", Sdf.ValueTypeNames.Bool).Set(True)
            sh.CreateInput("emissive_color", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*emissive))
            sh.CreateInput("emissive_intensity", Sdf.ValueTypeNames.Float).Set(2000.0)
    m.CreateSurfaceOutput("mdl").ConnectToSource(sh.ConnectableAPI(), "out")
    return m


def _bind(prim, mat):
    from pxr import UsdShade
    UsdShade.MaterialBindingAPI.Apply(prim).Bind(mat)


def _box(st, path, c0, c1, mat, collide=True):
    from . import props
    from pxr import UsdPhysics
    ctr = [(a + b) / 2 for a, b in zip(c0, c1)]
    size = [abs(b - a) for a, b in zip(c0, c1)]
    m = props._mesh_box(st, path, ctr, size, mat)
    if not collide:
        m.GetPrim().RemoveAPI(UsdPhysics.CollisionAPI)
        m.GetPrim().RemoveAPI(UsdPhysics.MeshCollisionAPI)
    return m


def _lathe(st, path, prof, mat, n=32, collide=False):
    from pxr import UsdGeom, UsdPhysics, Vt, Gf, Sdf
    P, N, C, I = [], [], [], []
    ring = []
    for k, (r, z) in enumerate(prof):
        z0 = prof[max(k - 1, 0)]; z1 = prof[min(k + 1, len(prof) - 1)]
        dr, dz = z1[0] - z0[0], z1[1] - z0[1]
        L = math.hypot(dr, dz) or 1.0
        nr, nz = dz / L, -dr / L
        ring.append(len(P))
        for i in range(n):
            a = 2 * math.pi * i / n
            P.append(Gf.Vec3f(r * math.cos(a), r * math.sin(a), z)); N.append(Gf.Vec3f(nr * math.cos(a), nr * math.sin(a), nz))
    for k in range(len(prof) - 1):
        for i in range(n):
            j = (i + 1) % n
            C.append(4); I += [ring[k] + i, ring[k] + j, ring[k + 1] + j, ring[k + 1] + i]
    for (r, z), s in ((prof[0], -1), (prof[-1], 1)):
        if r <= 1e-6:
            continue
        c = len(P); P.append(Gf.Vec3f(0, 0, z)); N.append(Gf.Vec3f(0, 0, s))
        b = len(P)
        for i in range(n):
            a = 2 * math.pi * i / n
            P.append(Gf.Vec3f(r * math.cos(a), r * math.sin(a), z)); N.append(Gf.Vec3f(0, 0, s))
        for i in range(n):
            j = (i + 1) % n
            C.append(3); I += [c, b + i, b + j] if s > 0 else [c, b + j, b + i]
    m = UsdGeom.Mesh.Define(st, path)
    m.CreatePointsAttr(Vt.Vec3fArray(P)); m.CreateFaceVertexCountsAttr(C); m.CreateFaceVertexIndicesAttr(I)
    m.CreateNormalsAttr(Vt.Vec3fArray(N)); m.SetNormalsInterpolation(UsdGeom.Tokens.vertex)
    m.CreateSubdivisionSchemeAttr("none")
    _bind(m.GetPrim(), mat)
    if collide:
        UsdPhysics.CollisionAPI.Apply(m.GetPrim())
        UsdPhysics.MeshCollisionAPI.Apply(m.GetPrim()).CreateApproximationAttr("convexHull")
    return m


def _band(st, path, r, z0, z1, a0, a1, mat, n=20):
    from pxr import UsdGeom, Vt, Gf
    P, N, I = [], [], []
    for i in range(n + 1):
        a = math.radians(a0 + (a1 - a0) * i / n)
        c, s_ = math.cos(a), math.sin(a)
        P += [Gf.Vec3f(r * c, r * s_, z0), Gf.Vec3f(r * c, r * s_, z1)]; N += [Gf.Vec3f(c, s_, 0)] * 2
    for i in range(n):
        k = 2 * i
        I += [k, k + 2, k + 3, k + 1]
    m = UsdGeom.Mesh.Define(st, path)
    m.CreatePointsAttr(Vt.Vec3fArray(P)); m.CreateFaceVertexCountsAttr([4] * n); m.CreateFaceVertexIndicesAttr(I)
    m.CreateNormalsAttr(Vt.Vec3fArray(N)); m.SetNormalsInterpolation(UsdGeom.Tokens.vertex)
    m.CreateSubdivisionSchemeAttr("none")
    _bind(m.GetPrim(), mat)
    return m


def tube_usd(name, spec, cap, liquid, fill):
    from pxr import UsdPhysics
    path = os.path.join(GEN, f"{name}.usd")
    st, root = _stage(path, "/Tube")
    r, L, cone, tip, rc, hc = spec["d"] / 2, spec["length"], spec["cone"], spec["tip_d"] / 2, spec["cap_d"] / 2, spec["cap_h"]
    body_top = L - hc + 0.004
    frost = 0.05 if os.environ.get("HACK_GLASS", "0") == "1" else 0.35
    clear = _mat(st, "/Tube/Looks/PP", (0.86, 0.90, 0.94), frost, glass=True)
    white = _mat(st, "/Tube/Looks/Print", (0.90, 0.90, 0.88), 0.65)
    capm = _mat(st, "/Tube/Looks/Cap", tuple(cap), 0.45)
    liq = _mat(st, "/Tube/Looks/Liquid", tuple(liquid), 0.15)
    _lathe(st, "/Tube/Body", [(tip, 0.0), (tip + 0.3 * (r - tip), cone * 0.35), (r, cone), (r, body_top)], clear,
           collide=True)
    ridges = [(rc * 0.97, L - hc), (rc, L - hc + 0.001), (rc, L - 0.0015), (rc * 0.96, L)]
    _lathe(st, "/Tube/Cap", ridges, capm, collide=True)
    hz = body_top - cone
    _band(st, "/Tube/WritingArea", r + 0.0004, cone + 0.30 * hz, cone + 0.62 * hz, -70, 70, white)
    for k in range(7):
        zk = cone + (0.12 + 0.11 * k) * hz
        _band(st, f"/Tube/Mark{k}", r + 0.0004, zk, zk + 0.0007, 140, 220 if k % 2 == 0 else 190, white, n=6)
    _band(st, "/Tube/Thread", r + 0.0003, body_top - 0.013, L - hc + 0.0005, 0, 360, white, n=28)
    zl = cone + fill * (body_top - cone - 0.01)
    ri = r * 0.9
    _lathe(st, "/Tube/Liquid", [(tip * 0.6, 0.0015), (ri, cone * 1.02), (ri, zl)], liq, n=24)
    UsdPhysics.RigidBodyAPI.Apply(root.GetPrim())
    UsdPhysics.MassAPI.Apply(root.GetPrim()).CreateMassAttr(float(spec["mass"]))
    st.GetRootLayer().Save()
    return path, ([-rc, -rc, 0.0], [rc, rc, L])


def rack_usd(name, rk, color):
    path = os.path.join(GEN, f"{name}.usd")
    st, root = _stage(path, "/Rack")
    mat = _mat(st, "/Rack/Looks/PP", tuple(color), 0.55)
    rows, cols, p, h, tz, th, mg = rk["rows"], rk["cols"], rk["pitch"], rk["hole"], rk["top_z"], rk["plate"], rk["margin"]
    Lx, Wy = cols * p + 2 * mg, rows * p + 2 * mg
    xs = [(i - (cols - 1) / 2) * p for i in range(cols)]
    ys = [(j - (rows - 1) / 2) * p for j in range(rows)]
    _box(st, "/Rack/Base", (-Lx / 2, -Wy / 2, 0), (Lx / 2, Wy / 2, th), mat)
    _box(st, "/Rack/EndL", (-Lx / 2, -Wy / 2, th), (-Lx / 2 + th, Wy / 2, tz), mat)
    _box(st, "/Rack/EndR", (Lx / 2 - th, -Wy / 2, th), (Lx / 2, Wy / 2, tz), mat)
    z0, z1 = tz, tz + th
    yb = [-Wy / 2] + [v for y in ys for v in (y - h / 2, y + h / 2)] + [Wy / 2]
    n = 0
    for k in range(0, len(yb), 2):
        if yb[k + 1] - yb[k] > 1e-4:
            _box(st, f"/Rack/Top_{n:02d}", (-Lx / 2, yb[k], z0), (Lx / 2, yb[k + 1], z1), mat); n += 1
    xb = [-Lx / 2] + [v for x in xs for v in (x - h / 2, x + h / 2)] + [Lx / 2]
    for y in ys:
        for k in range(0, len(xb), 2):
            if xb[k + 1] - xb[k] > 1e-4:
                _box(st, f"/Rack/Top_{n:02d}", (xb[k], y - h / 2, z0), (xb[k + 1], y + h / 2, z1), mat); n += 1
    st.GetRootLayer().Save()
    return path, [(x, y) for y in ys for x in xs], th, (Lx, Wy)


def hood_usd(hc):
    from pxr import UsdGeom, UsdLux, Gf
    path = os.path.join(GEN, "fume_hood.usd")
    st, root = _stage(path, "/Hood")
    body = _mat(st, "/Hood/Looks/Body", (0.80, 0.81, 0.79), 0.45)
    liner = _mat(st, "/Hood/Looks/Liner", (0.88, 0.89, 0.88), 0.6)
    top = _mat(st, "/Hood/Looks/Epoxy", (0.02, 0.02, 0.022), 0.35)
    frame = _mat(st, "/Hood/Looks/Frame", (0.20, 0.21, 0.22), 0.35, metal=0.6)
    steel = _mat(st, "/Hood/Looks/Steel", (0.55, 0.56, 0.57), 0.3, metal=1.0)
    door = _mat(st, "/Hood/Looks/Door", (0.70, 0.72, 0.72), 0.5)
    glass = _mat(st, "/Hood/Looks/Glass", (0.92, 0.96, 0.95), 0.02, glass=True) if os.environ.get("HACK_GLASS", "0") == "1" \
        else _mat(st, "/Hood/Looks/Glass", (0.75, 0.85, 0.85), 0.05, opacity=0.15)
    dark = _mat(st, "/Hood/Looks/Dark", (0.03, 0.03, 0.035), 0.4)
    led = _mat(st, "/Hood/Looks/Led", (0.1, 0.9, 0.2), 0.3, emissive=(0.1, 1.0, 0.25))
    (x0, x1), (y0, y1) = hc["x"], hc["y"]
    wz, H, so = hc["work_z"], hc["height"], hc["sash_open"]
    t, post, fd = 0.05, 0.08, 0.05
    B = lambda n, a, b, m, col=True: _box(st, f"/Hood/{n}", a, b, m, col)
    B("Cabinet", (x0 + 0.01, y0 + 0.03, 0.08), (x1 - 0.01, y1, wz - 0.04), body)
    B("Plinth", (x0 + 0.03, y0 + 0.06, 0.0), (x1 - 0.03, y1 - 0.02, 0.08), dark)
    xm = (x0 + x1) / 2
    for k, (a, b) in enumerate(((x0 + 0.03, xm - 0.005), (xm + 0.005, x1 - 0.03))):
        B(f"Door{k}", (a, y0 + 0.02, 0.11), (b, y0 + 0.03, wz - 0.07), door, False)
        hx = b - 0.06 if k == 0 else a + 0.04
        B(f"Handle{k}", (hx, y0 + 0.0, wz - 0.25), (hx + 0.02, y0 + 0.02, wz - 0.09), steel, False)
    B("Worktop", (x0, y0, wz - 0.04), (x1, y1, wz), top)
    B("Airfoil", (x0 + post, y0 + 0.005, wz), (x1 - post, y0 + 0.035, wz + 0.022), steel)
    B("SideL", (x0, y0, wz), (x0 + t, y1, H), body)
    B("SideR", (x1 - t, y0, wz), (x1, y1, H), body)
    B("Back", (x0 + t, y1 - t, wz), (x1 - t, y1, H), liner)
    for k, z in enumerate((wz + 0.08, wz + 0.75, H - 0.25)):
        B(f"Slot{k}", (x0 + 0.12, y1 - t - 0.004, z), (x1 - 0.12, y1 - t, z + 0.025), dark, False)
    B("Roof", (x0, y0, H - 0.06), (x1, y1, H), body)
    B("PostL", (x0, y0, wz), (x0 + post, y0 + fd, H - 0.06), body)
    B("PostR", (x1 - post, y0, wz), (x1, y0 + fd, H - 0.06), body)
    zs0 = wz + so
    zf = min(H - 0.35, zs0 + 0.75)
    B("Fascia", (x0 + post, y0, zf), (x1 - post, y0 + fd - 0.01, H - 0.06), body)
    gx0, gx1 = x0 + post + 0.005, x1 - post - 0.005
    sy0, sy1 = y0 + fd, y0 + fd + 0.012
    if os.environ.get("HACK_SASH", "1") == "1":
        B("SashGlass", (gx0 + 0.02, sy0 + 0.003, zs0 + 0.04), (gx1 - 0.02, sy1 - 0.003, zf + 0.08), glass)
    B("SashBottom", (gx0, sy0 - 0.01, zs0), (gx1, sy1 + 0.005, zs0 + 0.045), frame)
    B("SashSideL", (gx0, sy0, zs0), (gx0 + 0.02, sy1, zf + 0.08), frame)
    B("SashSideR", (gx1 - 0.02, sy0, zs0), (gx1, sy1, zf + 0.08), frame)
    B("Panel", (x1 - post + 0.008, y0 - 0.012, wz + 0.42), (x1 - 0.008, y0, wz + 0.60), dark, False)
    B("Led", (x1 - post + 0.025, y0 - 0.016, wz + 0.53), (x1 - post + 0.04, y0 - 0.012, wz + 0.545), led, False)
    B("Display", (x1 - post + 0.015, y0 - 0.014, wz + 0.45), (x1 - 0.015, y0 - 0.012, wz + 0.51),
      _mat(st, "/Hood/Looks/Lcd", (0.05, 0.12, 0.10), 0.2, emissive=(0.15, 0.45, 0.35)), False)
    if hc.get("duct", True):
        c = UsdGeom.Cylinder.Define(st, "/Hood/Duct")
        c.CreateRadiusAttr(0.13); c.CreateHeightAttr(6.3 - H); c.CreateAxisAttr("Z")
        c.AddTranslateOp().Set(Gf.Vec3d((x0 + x1) / 2, (y0 + y1) / 2 + 0.1, H + (6.3 - H) / 2))
        _bind(c.GetPrim(), steel)
        k = UsdGeom.Cylinder.Define(st, "/Hood/DuctCollar")
        k.CreateRadiusAttr(0.16); k.CreateHeightAttr(0.12); k.CreateAxisAttr("Z")
        k.AddTranslateOp().Set(Gf.Vec3d((x0 + x1) / 2, (y0 + y1) / 2 + 0.1, H + 0.06))
        _bind(k.GetPrim(), steel)
    hc["light"] = float(os.environ.get("HACK_HOOD_LIGHT", hc.get("light", 0)))
    if hc["light"]:
        L = UsdLux.RectLight.Define(st, "/Hood/Light")
        L.CreateWidthAttr(x1 - x0 - 0.25); L.CreateHeightAttr(0.12); L.CreateIntensityAttr(float(hc["light"]))
        L.CreateColorAttr(Gf.Vec3f(1.0, 0.97, 0.92))
        L.AddTranslateOp().Set(Gf.Vec3d((x0 + x1) / 2, (y0 + y1) / 2 + 0.1, H - 0.08))
    st.GetRootLayer().Save()
    return path


def _yawq(a):
    return (math.cos(a / 2), 0.0, 0.0, math.sin(a / 2))


def sample(seed):
    rng = random.Random(int(seed))
    v = LAB["variant"]; out = {}
    by_type = {}
    for n, t in LAB["tubes"].items():
        by_type.setdefault(t["rack_src"], []).append(n)
    for rname, names in by_type.items():
        if rname is None:
            continue
        rk = LAB["racks"][rname]
        slots = rng.sample(range(len(rk["slots"])), len(names))
        for n, s in zip(names, slots):
            x, y = rk["slots"][s]
            out[n] = {"x": x, "y": y, "z": rk["base"] + 0.0015, "yaw": rng.uniform(-math.pi, math.pi)}
    lying = [n for n, t in LAB["tubes"].items() if t["rack_src"] is None]
    if lying:
        ar = v.get("lying_area", {"x": [0.36, 0.62], "y": [-0.45, 0.45]})
        placed = []
        for n in lying:
            t = LAB["tubes"][n]; Lh = t["length"] / 2 + 0.02
            for _ in range(500):
                x, y, yaw = rng.uniform(*ar["x"]), rng.uniform(*ar["y"]), rng.uniform(-math.pi, math.pi)
                if all(math.hypot(x - u, y - w) > Lh + q for u, w, q in placed):
                    break
            placed.append((x, y, Lh))
            cy_, sy_ = math.cos(math.pi / 4), math.sin(math.pi / 4)
            cz_, sz_ = math.cos(yaw / 2), math.sin(yaw / 2)
            q = (cz_ * cy_, -sz_ * sy_, cz_ * sy_, sz_ * cy_)
            cx, cy = x - math.cos(yaw) * t["length"] / 2, y - math.sin(yaw) * t["length"] / 2
            out[n] = {"x": cx, "y": cy, "z": t["cap_r"] + 0.002, "quat": q, "abs_z": True}
    return out


def apply(env_cfg, info):
    import isaaclab.sim as sim_utils
    from isaaclab.assets import AssetBaseCfg, RigidObjectCfg
    from . import objects
    os.makedirs(GEN, exist_ok=True)
    cfg = load_cfg()
    vname = os.environ.get("HACK_TUBES", "standard")
    if vname not in cfg["variants"]:
        raise KeyError(f"[hack] HACK_TUBES={vname}: one of {list(cfg['variants'])}")
    v = cfg["variants"][vname]
    seed = int(os.environ.get("HACK_SEED", "0"))
    rng = random.Random(seed + 1000)
    px, py, _ = info["pelvis"]; fz = info["floor_z"]; top = info["table_top_z"]
    LAB.clear(); LAB.update(variant=v, name=vname, rule=v["rule"], racks={}, tubes={})
    sc = env_cfg.scene
    hc = dict(cfg["hood"])
    dy = float(os.environ.get("HACK_HOOD_DY", "0"))
    hc["y"] = [hc["y"][0] + dy, hc["y"][1] + dy]
    sc.hack_hood = AssetBaseCfg(prim_path="{ENV_REGEX_NS}/HackHood", spawn=sim_utils.UsdFileCfg(usd_path=hood_usd(hc)),
                                init_state=AssetBaseCfg.InitialStateCfg(pos=(px, py, fz)))
    colors = cfg["rack_colors"]
    for where, lst, zbase in (("table", v["table"], top), ("hood", v["hood"], fz + hc["work_z"])):
        for i, r in enumerate(lst):
            if "rack" not in r:
                continue
            rk = dict(cfg["racks"][r["rack"]], **{k: r[k] for k in ("rows", "cols") if k in r})
            name = f"{where}_{r['rack']}_{i}"
            usd, slots, base, (Lx, Wy) = rack_usd(f"rack_{name}", rk, colors[r.get("color", "white")])
            x, y = r["at"]
            y += dy if where == "hood" else 0.0
            along = r.get("along", "y" if where == "table" else "x")
            if along == "y":
                slots = [(-sy, sx) for sx, sy in slots]
                Lx, Wy = Wy, Lx
            rot = (math.cos(math.pi / 4), 0.0, 0.0, math.sin(math.pi / 4)) if along == "y" else (1.0, 0.0, 0.0, 0.0)
            setattr(sc, f"hack_rack_{name}", AssetBaseCfg(
                prim_path=f"{{ENV_REGEX_NS}}/HackRack_{name}", spawn=sim_utils.UsdFileCfg(usd_path=usd),
                init_state=AssetBaseCfg.InitialStateCfg(pos=(px + x, py + y, zbase), rot=rot)))
            LAB["racks"][name] = {"where": where, "type": r["rack"], "tube": rk["tube"], "color": r.get("color", "white"),
                                  "slots": [(x + sx, y + sy) for sx, sy in slots], "base": base, "size": (Lx, Wy),
                                  "z": zbase - fz, "slot_world": [(px + x + sx, py + y + sy, zbase + base) for sx, sy in slots]}
    n = 0
    for i, r in enumerate(v["table"]):
        if "rack" in r:
            rk = cfg["racks"][r["rack"]]; ttype = rk["tube"]; cnt = r["tubes"]; src = f"table_{r['rack']}_{i}"
        else:
            ttype = r["lying"]; cnt = r["n"]; src = None
        caps = r.get("caps") or list(cfg["cap_colors"])
        for k in range(cnt):
            spec = cfg["tubes"][ttype]
            cap = caps[k % len(caps)] if r.get("caps") else rng.choice(caps)
            liquid = rng.choice(cfg["liquid_colors"]); fill = rng.uniform(0.3, 0.75)
            name = f"tube_{ttype[6:]}_{n}"
            usd, (lo, hi) = tube_usd(name, spec, cfg["cap_colors"][cap], liquid, fill)
            objects.STATE[name] = {"key": f"hack_tube_{n}", "category": f"{ttype}/{cap}", "mass": spec["mass"],
                                   "usd": usd, "bbox": [lo, hi], "radius": spec["cap_d"] / 2 + 0.003, "src_bodies": 1}
            LAB["tubes"][name] = {"type": ttype, "cap": cap, "rack_src": src, "length": spec["length"],
                                  "cap_r": spec["cap_d"] / 2}
            n += 1
    layout = sample(seed)
    spawn = objects.load_cfg()["spawn"]
    objects.STATE["_layout"], objects.STATE["_info"], objects.STATE["_spawn"] = layout, info, spawn
    objects.STATE["_sampler"] = sample
    rp = sim_utils.RigidBodyPropertiesCfg(solver_position_iteration_count=24, solver_velocity_iteration_count=2,
                                          max_depenetration_velocity=0.5)
    for name in LAB["tubes"]:
        pos, rot = objects.to_world(name, layout[name], info, spawn, 0)
        setattr(sc, objects.STATE[name]["key"], RigidObjectCfg(
            prim_path=f"{{ENV_REGEX_NS}}/Tube_{name}",
            spawn=sim_utils.UsdFileCfg(usd_path=objects.STATE[name]["usd"], rigid_props=rp),
            init_state=RigidObjectCfg.InitialStateCfg(pos=pos, rot=rot)))
    desc = describe()
    print(f"[hack] lab: variant {vname} ({v['rule']}), {len(LAB['tubes'])} tubes, racks: "
          + ", ".join(f"{k}({r['tube']}, {r['color']})" for k, r in LAB["racks"].items()) + f", seed {seed}", flush=True)
    return desc


def describe():
    v = LAB["variant"]
    return {"task": "tubes", "variant": LAB["name"], "rule": LAB["rule"], "ru": v.get("ru", ""),
            "tubes": {n: {"type": t["type"], "cap": t["cap"]} for n, t in LAB["tubes"].items()},
            "racks": {k: {"where": r["where"], "tube": r["tube"], "color": r["color"], "slots": len(r["slots"])}
                      for k, r in LAB["racks"].items()}}


def _rot_z(q):
    w, x, y, z = q
    return (2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y))


def evaluate(pose):
    rule = LAB["rule"]
    out = {"placed_ok": 0, "placed_wrong_rack": 0, "not_placed": 0, "tubes": {}}
    for n, t in LAB["tubes"].items():
        (px, py, pz), q = pose(n)
        ax = _rot_z(q)
        tilt = math.degrees(math.acos(max(-1.0, min(1.0, ax[2]))))
        where = None
        for rname, r in LAB["racks"].items():
            if r["where"] != "hood":
                continue
            hole = load_cfg()["racks"][r["type"]]["hole"] if "type" in r else 0.03
            for (sx, sy, sz) in r["slot_world"]:
                if math.hypot(px - sx, py - sy) < hole / 2 and abs(pz - sz) < 0.03:
                    where = rname
        ok = False
        if where and tilt < 20.0:
            r = LAB["racks"][where]
            ok = rule == "any_slot" or (rule == "by_type" and r["tube"] == t["type"]) or \
                (rule == "by_cap_color" and r["color"] == t["cap"])
            out["placed_ok" if ok else "placed_wrong_rack"] += 1
        else:
            out["not_placed"] += 1
        out["tubes"][n] = {"rack": where, "upright": tilt < 20.0, "ok": ok}
    out["total"] = len(LAB["tubes"])
    return out
