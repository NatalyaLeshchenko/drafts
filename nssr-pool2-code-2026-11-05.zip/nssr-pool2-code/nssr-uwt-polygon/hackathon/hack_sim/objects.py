# Objects of the task: loading, random layouts, moving them on request and the self-check.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import json, math, os, random
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
HACK = os.path.abspath(os.path.join(HERE, ".."))
OBJ_DIR = os.path.join(HACK, "assets", "objects")
GEN = os.path.join(os.environ.get("HACK_GEN_DIR", "/tmp/hack_gen"), "objects")
STATE = {}


def load_cfg():
    with open(os.path.join(HACK, "config", "objects.yaml")) as f:
        return yaml.safe_load(f)


def pool(cfg):
    out = {}
    for cat, c in cfg["categories"].items():
        for o in c["objects"]:
            out[o["name"]] = dict(o, category=cat)
    for o in cfg.get("reserve", []):
        out.setdefault(o["name"], dict(o, category="reserve"))
    return out


def pool_selection(task=None):
    if task is None:
        from . import scene
        task = scene.task_cfg()
    with open(os.path.join(HACK, "config", "pools.yaml")) as f:
        pools = yaml.safe_load(f)["pools"]
    key = str(os.environ.get("HACK_POOL") or task.get("pools_default", 1))
    if key not in pools:
        raise KeyError(f"[hack] HACK_POOL={key}: pools are {list(pools)} (config/pools.yaml)")
    cats = list(pools[key])
    k = int(task.get("categories", len(cats)))
    if k > len(cats):
        raise ValueError(f"[hack] pool {key} has {len(cats)} categories, task {task['name']} needs {k}")
    return {c: pools[key][c] for c in cats[:k]}, key


def selection(cfg, spec=None):
    spec = spec or os.environ.get("HACK_OBJECTS")
    if not spec:
        return pool_selection()[0]
    P = pool(cfg)
    if spec in cfg.get("sets", {}):
        return cfg["sets"][spec]
    if os.path.isfile(spec):
        with open(spec) as f:
            d = yaml.safe_load(f)
        return d.get("objects", d)
    sel = {}
    for n in [s.strip() for s in spec.split(",") if s.strip()]:
        if n not in P:
            raise KeyError(f"[hack] HACK_OBJECTS: unknown object '{n}' (see hackathon/config/objects.yaml)")
        sel.setdefault(P[n]["category"], []).append(n)
    return sel


def wrapper_usd(name, mass):
    from pxr import Usd, UsdGeom, UsdPhysics, Gf
    src = os.path.join(OBJ_DIR, name, f"{name}.usd")
    if not os.path.isfile(src):
        raise FileNotFoundError(f"[hack] object USD missing: {src} (run tools/collect_objects.sh)")
    s_st = Usd.Stage.Open(src)
    s_root = s_st.GetDefaultPrim() or next(iter(s_st.GetPseudoRoot().GetChildren()))
    mpu, up = UsdGeom.GetStageMetersPerUnit(s_st), UsdGeom.GetStageUpAxis(s_st)
    rbs = [p for p in Usd.PrimRange(s_root) if p.HasAPI(UsdPhysics.RigidBodyAPI)]

    os.makedirs(GEN, exist_ok=True)
    path = os.path.join(GEN, f"{name}.usd")
    if os.path.exists(path):
        os.remove(path)
    st = Usd.Stage.CreateNew(path)
    UsdGeom.SetStageUpAxis(st, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(st, 1.0)
    UsdPhysics.SetStageKilogramsPerUnit(st, 1.0)
    root = UsdGeom.Xform.Define(st, "/Object")
    st.SetDefaultPrim(root.GetPrim())
    fix = abs(mpu - 1.0) > 1e-6 or up != UsdGeom.Tokens.z
    holder = UsdGeom.Xform.Define(st, "/Object/geom") if fix else root
    holder.GetPrim().GetReferences().AddReference(src, s_root.GetPath())
    if fix:
        if up == UsdGeom.Tokens.y:
            holder.AddRotateXOp().Set(90.0)
        if abs(mpu - 1.0) > 1e-6:
            holder.AddScaleOp().Set(Gf.Vec3f(mpu, mpu, mpu))
    base = holder.GetPath()
    if len(rbs) == 1:
        rel = rbs[0].GetPath().MakeRelativePath(s_root.GetPath())
        body = st.GetPrimAtPath(base.AppendPath(rel)) if str(rel) != "." else holder.GetPrim()
    else:
        for p in rbs:
            q = st.GetPrimAtPath(base.AppendPath(p.GetPath().MakeRelativePath(s_root.GetPath())))
            if q:
                UsdPhysics.RigidBodyAPI(q).CreateRigidBodyEnabledAttr(False)
        body = root.GetPrim()
        UsdPhysics.RigidBodyAPI.Apply(body)
    m = UsdPhysics.MassAPI.Apply(body)
    m.CreateMassAttr(float(mass))
    st.GetRootLayer().Save()
    bb = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render]) \
        .ComputeWorldBound(root.GetPrim()).ComputeAlignedRange()
    return path, list(bb.GetMin()), list(bb.GetMax()), len(rbs)


def _trays_rects(info, gap):
    px, py, _ = info["pelvis"]
    sx, sy = info["tray_size"][0] / 2 + gap, info["tray_size"][1] / 2 + gap
    return [(x - px - sx, x - px + sx, y - py - sy, y - py + sy) for (x, y, _) in info["trays"].values()]


def _obb(x, y, yaw, hx, hy):
    c, s = math.cos(yaw), math.sin(yaw)
    return [(x + c * u - s * v, y + s * u + c * v) for u, v in ((-hx, -hy), (hx, -hy), (hx, hy), (-hx, hy))]


def _overlap(a, b):
    for poly in (a, b):
        for i in range(len(poly)):
            (x0, y0), (x1, y1) = poly[i], poly[(i + 1) % len(poly)]
            nx, ny = y0 - y1, x1 - x0
            pa = [nx * x + ny * y for x, y in a]; pb = [nx * x + ny * y for x, y in b]
            if max(pa) < min(pb) or max(pb) < min(pa):
                return False
    return True


def sample_layout(names, seed, info, spawn):
    best = None
    for attempt in range(80):
        lay = _sample_once(names, random.Random(int(seed) * 1009 + attempt), info, spawn)
        miss = sum(1 for v in lay.values() if v == "park")
        if best is None or miss < best[0]:
            best = (miss, lay)
        if miss == 0:
            break
    for n, v in best[1].items():
        if v == "park":
            print(f"[hack] layout: no free spot for {n}, parked", flush=True)
    return best[1]


def _sample_once(names, rng, info, spawn):
    t = info["table"]
    tx0, tx1 = t["front_gap"] + spawn["edge_margin"], t["front_gap"] + t["depth"] - spawn["edge_margin"]
    ty = t["width"] / 2 - spawn["edge_margin"]
    ax, ay = spawn["area_x"], spawn["area_y"]
    x0, x1, y0, y1 = max(ax[0], tx0), min(ax[1], tx1), max(ay[0], -ty), min(ay[1], ty)
    g = spawn["gap"]
    trays = [[(a, c), (b, c), (b, d), (a, d)] for a, b, c, d in _trays_rects(info, g)]
    placed, out = [], {}
    rand_yaw = spawn.get("random_yaw", True)

    def size(n):
        bb = STATE[n].get("bbox")
        if bb:
            return (bb[1][0] - bb[0][0]) / 2 + g / 2, (bb[1][1] - bb[0][1]) / 2 + g / 2, \
                (bb[0][0] + bb[1][0]) / 2, (bb[0][1] + bb[1][1]) / 2
        r = STATE[n]["radius"]
        return r, r, 0.0, 0.0
    for n in sorted(names, key=lambda k: -size(k)[0] * size(k)[1]):
        hx, hy, cx, cy = size(n)
        for _ in range(600):
            yaw = rng.uniform(-math.pi, math.pi) if rand_yaw else 0.0
            if rng.random() < 0.5 and rand_yaw:
                yaw = (math.pi / 2 if hx > hy else 0.0) + rng.uniform(-0.3, 0.3)
            x, y = rng.uniform(x0, x1), rng.uniform(y0, y1)
            c, s_ = math.cos(yaw), math.sin(yaw)
            fx, fy = x + c * cx - s_ * cy, y + s_ * cx + c * cy
            poly = _obb(fx, fy, yaw, hx, hy)
            if any(not (x0 <= px_ <= x1 and y0 <= py_ <= y1) for px_, py_ in poly):
                continue
            if any(_overlap(poly, q) for q in trays) or any(_overlap(poly, q) for q in placed):
                continue
            break
        else:
            out[n] = "park"
            continue
        placed.append(poly)
        out[n] = (x, y, yaw)
    return {n: out[n] for n in names}


def to_world(name, spec, info, spawn, park_idx):
    px, py, _ = info["pelvis"]
    lo = STATE[name]["bbox"][0]
    if spec == "park" or spec is None:
        p = spawn["parking"]
        i = park_idx
        x = px + p["x0"] + p["dx"] * (i // p["per_row"])
        y = py + p["y0"] + p["dy"] * (i % p["per_row"])
        return (x, y, info["floor_z"] - lo[2] + 0.01), (1.0, 0.0, 0.0, 0.0)
    if isinstance(spec, dict) and "quat" in spec:
        return (px + spec["x"], py + spec["y"], info["table_top_z"] + float(spec["z"])), tuple(spec["quat"])
    if isinstance(spec, dict):
        x, y, z, yaw = spec["x"], spec["y"], spec.get("z", 0.0), spec.get("yaw", 0.0)
    else:
        x, y = spec[0], spec[1]
        yaw = spec[2] if len(spec) > 2 else 0.0
        z = spec[3] if len(spec) > 3 else 0.0
    zw = info["table_top_z"] - lo[2] + spawn["drop"] + float(z)
    if isinstance(spec, dict) and spec.get("center"):
        hi = STATE[name]["bbox"][1]
        cx, cy = (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2
        c, s_ = math.cos(yaw), math.sin(yaw)
        x, y = x - (c * cx - s_ * cy), y - (s_ * cx + c * cy)
    return (px + x, py + y, zw), (math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2))


def _read_layout_file(path):
    with open(path) as f:
        return json.load(f) if path.endswith(".json") else yaml.safe_load(f)


def apply(env_cfg, info):
    import isaaclab.sim as sim_utils
    from isaaclab.assets import RigidObjectCfg
    cfg = load_cfg()
    P = pool(cfg)
    sel = selection(cfg)
    names = [n for c in sel.values() for n in c]
    spawn = cfg["spawn"]
    for n in names:
        path, lo, hi, nrb = wrapper_usd(n, P[n]["mass"])
        dx, dy, dz = (hi[i] - lo[i] for i in range(3))
        exp = P[n].get("dims_cm")
        if exp and max(abs(a * 100 - b) / b for a, b in zip((dx, dy, dz), exp)) > 0.25:
            print(f"[hack] WARN {n}: wrapper bbox {dx*100:.1f}x{dy*100:.1f}x{dz*100:.1f} cm vs scan {exp}", flush=True)
        STATE[n] = {"key": f"hack_obj_{len(STATE)}", "category": P[n]["category"], "mass": P[n]["mass"],
                    "usd": path, "bbox": [lo, hi], "radius": 0.5 * max(dx, dy) + 0.005, "src_bodies": nrb}
    layout = sample_layout(names, int(os.environ.get("HACK_SEED", "0")), info, spawn)
    if os.environ.get("HACK_LAYOUT"):
        layout.update(_read_layout_file(os.environ["HACK_LAYOUT"]))
    STATE["_layout"], STATE["_info"], STATE["_spawn"] = layout, info, spawn
    rp = sim_utils.RigidBodyPropertiesCfg(solver_position_iteration_count=16, solver_velocity_iteration_count=1,
                                          max_depenetration_velocity=1.0)
    park = 0
    for n in names:
        if layout[n] == "park":
            park += 1
        pos, rot = to_world(n, layout[n], info, spawn, park - 1)
        safe = "".join(ch if ch.isalnum() else "_" for ch in n)
        setattr(env_cfg.scene, STATE[n]["key"], RigidObjectCfg(
            prim_path=f"{{ENV_REGEX_NS}}/Obj_{safe}",
            spawn=sim_utils.UsdFileCfg(usd_path=STATE[n]["usd"], rigid_props=rp),
            init_state=RigidObjectCfg.InitialStateCfg(pos=pos, rot=rot)))
    src = os.environ.get("HACK_OBJECTS") or f"pool {pool_selection()[1]}"
    print(f"[hack] objects ({src}, seed {os.environ.get('HACK_SEED', '0')}): "
          + ", ".join(f"{c}: {len(v)}" for c, v in sel.items()), flush=True)
    from . import scene
    task = info.get("task") or scene.task_cfg()
    trays = list(info.get("trays", {}))
    STATE["_task"] = {"task": task["name"], "ru": task.get("ru", ""), "objects_from": src,
                      "categories": {c: (trays[i] if i < len(trays) else None) for i, c in enumerate(sel)},
                      "trays": {t: info.get("tray_colors", {}).get(t, t) for t in trays},
                      "objects": {n: P[n]["category"] for n in names}}


class _Profiler:

    def __init__(self, env):
        import time
        self.t, self.n, self.every, self.clock = {}, 0, int(os.environ.get("HACK_PROFILE_EVERY", "200")), time.perf_counter
        targets = [("physics sim.step", env.sim, "step"), ("render sim.render", env.sim, "render"),
                   ("scene.update (sensors, cameras)", env.scene, "update"),
                   ("scene.write_data_to_sim", env.scene, "write_data_to_sim")]
        for mgr in ("action_manager", "observation_manager", "reward_manager", "termination_manager", "event_manager"):
            m = getattr(env, mgr, None)
            if m is not None:
                targets += [(f"{mgr}.{f}", m, f) for f in ("process_action", "apply_action", "compute") if hasattr(m, f)]
        for cam in ("cam_head", "cam_torso"):
            if cam in env.scene.keys() and hasattr(env.scene[cam], "_update_buffers_impl"):
                targets.append((f"{cam} buffers (data read-back)", env.scene[cam], "_update_buffers_impl"))
        for label, obj, attr in targets:
            self._wrap(label, obj, attr)
        print(f"[hack] profiler on: {len(targets)} stages, report every {self.every} env steps", flush=True)

    def _wrap(self, label, obj, attr):
        f = getattr(obj, attr)
        clock, t = self.clock, self.t

        def timed(*a, **k):
            t0 = clock()
            try:
                return f(*a, **k)
            finally:
                t[label] = t.get(label, 0.0) + clock() - t0
        setattr(obj, attr, timed)

    def tick(self):
        self.n += 1
        if self.n % self.every == 0:
            rows = sorted(self.t.items(), key=lambda kv: -kv[1])
            print("[hack] profile, ms per env step: " + " | ".join(f"{k} {1000 * v / self.every:.1f}" for k, v in rows),
                  flush=True)
            self.t.clear()


def _viewport_tuning(env):
    ctx = getattr(env.sim, "_viewport_context", None)
    if ctx is None:
        return
    sc = os.environ.get("HACK_VIEWPORT_SCALE")
    if sc:
        try:
            ctx.resolution_scale = float(sc)
            print(f"[hack] viewport resolution scale {float(sc)}", flush=True)
        except Exception as e:
            print(f"[hack] viewport scale failed: {e}", flush=True)
    every = int(os.environ.get("HACK_VIEWPORT_EVERY", "1"))
    if every <= 1:
        return
    render, k = env.sim.render, [0]

    def render_every(*a, **kw):
        k[0] += 1
        try:
            ctx.updates_enabled = k[0] % every == 0
        except Exception:
            pass
        return render(*a, **kw)
    env.sim.render = render_every
    print(f"[hack] viewport redrawn on every {every}-th render call", flush=True)


def _fix_tiled_depth():
    if os.environ.get("HACK_DEPTH_FIX", "1") != "1":
        return
    try:
        import inspect
        import numpy as np
        import warp as wp
        from isaaclab.sensors.camera import tiled_camera as tc
        if "dtype=wp.uint8" not in inspect.getsource(tc.TiledCamera._update_buffers_impl):
            print("[hack] depth fix: not needed, TiledCamera keeps the numpy dtype", flush=True)
            return

        class _ArrayMeta(type):
            def __instancecheck__(cls, obj):
                return isinstance(obj, wp.array)

            def __call__(cls, data=None, *a, **kw):
                if isinstance(data, np.ndarray) and data.dtype != np.uint8 and kw.get("dtype") is wp.uint8:
                    kw.pop("dtype")
                return wp.array(data, *a, **kw)

        class _Array(metaclass=_ArrayMeta):
            pass

        class _Warp:
            array = _Array

            def __getattr__(self, k):
                return getattr(wp, k)

        tc.wp = _Warp()
        print("[hack] depth fix: TiledCamera numpy buffers keep their dtype (float depth with the sim on the CPU)",
              flush=True)
    except Exception as e:
        print(f"[hack] depth fix failed: {e}", flush=True)


class Runtime:

    def __init__(self, env):
        self.env = env
        self._prof = None
        if os.environ.get("HACK_PROFILE", "0") == "1":
            try:
                self._prof = _Profiler(env)
            except Exception as e:
                print(f"[hack] profiler failed: {e}", flush=True)
        _fix_tiled_depth()
        try:
            _viewport_tuning(env)
        except Exception as e:
            print(f"[hack] viewport tuning failed: {e}", flush=True)
        self.io = None
        try:
            from .robot_io import RobotIO
            self.io = RobotIO(env)
        except Exception as e:
            print(f"[hack] robot io off: {e}", flush=True)
        self.names = [n for n in STATE if not n.startswith("_")]
        self.layout = dict(STATE.get("_layout", {}))
        self._pending = False
        self._checked = False
        self._status = {"hack_objects": {n: STATE[n]["category"] for n in self.names}}
        if STATE.get("_task"):
            self._status["hack_task"] = STATE["_task"]
        self._plugin = None
        plug = os.environ.get("HACK_PLUGIN")
        if plug:
            try:
                import importlib.util
                spec = importlib.util.spec_from_file_location("hack_plugin", plug)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                self._plugin = mod.tick
                print(f"[hack] plugin {plug}", flush=True)
            except Exception as e:
                print(f"[hack] plugin {plug} failed: {e}", flush=True)

    def _obj(self, n):
        return self.env.scene[STATE[n]["key"]]

    def _write(self, n, spec, park_idx=0):
        import torch
        pos, q = to_world(n, spec, STATE["_info"], STATE["_spawn"], park_idx)
        o = self._obj(n)
        dev = o.device
        org = self.env.scene.env_origins[0]
        pose = torch.tensor([[pos[0], pos[1], pos[2], *q]], device=dev, dtype=torch.float32)
        pose[:, :3] += org
        o.write_root_pose_to_sim(pose)
        o.write_root_velocity_to_sim(torch.zeros((1, 6), device=dev))

    def apply_layout(self, layout):
        park = 0
        for n, spec in layout.items():
            if n not in STATE or n.startswith("_"):
                print(f"[hack] objects/set: unknown '{n}', loaded: {self.names}", flush=True)
                continue
            self._write(n, spec, park)
            park += spec == "park"
            self.layout[n] = spec

    def check(self):
        self._checked = True
        try:
            import omni.usd
            from pxr import Usd, UsdGeom
            stage = omni.usd.get_context().get_stage()
            bc = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])
            for n in self.names:
                o = self._obj(n)
                m = float(o.root_physx_view.get_masses().reshape(-1)[0])
                path = o.cfg.prim_path.replace("{ENV_REGEX_NS}", "/World/envs/env_0").replace(".*", "0")
                r = bc.ComputeWorldBound(stage.GetPrimAtPath(path)).ComputeAlignedRange()
                d = r.GetMax() - r.GetMin()
                exp = STATE[n]["bbox"][1][2] - STATE[n]["bbox"][0][2]
                flag = "" if abs(d[2] - exp) < 0.25 * exp + 1e-3 and abs(m - STATE[n]["mass"]) < 0.02 else "  <-- CHECK"
                print(f"[hack] obj {n[:40]:40s} mass {m:.3f} kg (cfg {STATE[n]['mass']:.2f}), height {d[2]*100:.1f} cm "
                      f"(file {exp*100:.1f}){flag}", flush=True)
            self._check_decor(stage, bc)
        except Exception as e:
            print(f"[hack] object check skipped: {e}", flush=True)

    def _check_decor(self, stage, bc):
        from . import scene as _sc
        from pxr import Gf
        ok = fixed = 0
        for d in _sc.INFO.get("decor", []):
            prim = stage.GetPrimAtPath(d["path"])
            if not prim:
                continue
            r = bc.ComputeWorldBound(prim).ComputeAlignedRange()
            h = r.GetMax()[2] - r.GetMin()[2]
            if h <= 0 or 0.5 < h / d["h"] < 2.0:
                ok += 1; continue
            k = d["h"] / h
            sa, ta = prim.GetAttribute("xformOp:scale"), prim.GetAttribute("xformOp:translate")
            if not sa or not ta:
                continue
            sa.Set(sa.Get() * k)
            bc.Clear()
            r = bc.ComputeWorldBound(prim).ComputeAlignedRange()
            t = ta.Get()
            ta.Set(type(t)(t[0], t[1], t[2] + d["z0"] - r.GetMin()[2]))
            fixed += 1
        if ok or fixed:
            print(f"[hack] decor check: {ok} ok, {fixed} rescaled (unit mismatch)", flush=True)

    def _pose(self, n):
        o = self._obj(n)
        org = self.env.scene.env_origins[0].tolist()
        p = o.data.root_pos_w[0].tolist(); q = o.data.root_quat_w[0].tolist()
        return (p[0] - org[0], p[1] - org[1], p[2] - org[2]), tuple(q)

    def evaluate(self):
        task = STATE.get("_task") or {}
        if task.get("task") == "tubes":
            from . import lab
            res = lab.evaluate(self._pose)
        else:
            info = STATE["_info"]
            hx, hy = info["tray_size"][0] / 2, info["tray_size"][1] / 2
            res = {"in_right_tray": 0, "in_wrong_tray": 0, "not_in_tray": 0, "objects": {}}
            for n in self.names:
                (x, y, z), _ = self._pose(n)
                tray = next((t for t, (tx, ty, tz) in info["trays"].items()
                             if abs(x - tx) < hx and abs(y - ty) < hy and z < tz + 0.15), None)
                want = task.get("categories", {}).get(STATE[n]["category"])
                key = "not_in_tray" if tray is None else ("in_right_tray" if tray == want else "in_wrong_tray")
                res[key] += 1
                res["objects"][n] = {"tray": tray, "ok": key == "in_right_tray"}
            res["total"] = len(self.names)
        res["task"] = task.get("task")
        res["sim_step"] = int(self.env.common_step_counter)
        self._status["hack_task_result"] = res
        print(f"[hack] task check: " + ", ".join(f"{k} {v}" for k, v in res.items() if not isinstance(v, dict)), flush=True)
        return res

    def handle(self, action, reset_requested):
        if self._prof is not None:
            self._prof.tick()
        if self._plugin is not None:
            try:
                self._plugin(self)
            except Exception as e:
                print(f"[hack] plugin off: {e}", flush=True)
                self._plugin = None
        if os.environ.get("HACK_JUDGE", "0") == "1":
            for k in ("hack_objects_set", "hack_objects_randomize", "hack_task_check"):
                if action.pop(k, None) is not None:
                    print(f"[hack] locked: {k} ignored", flush=True)
        if not self._checked and self.env.common_step_counter > 5:
            self.check()
        if reset_requested:
            self._pending = True
        elif self._pending:
            self._pending = False
            self.apply_layout(self.layout)
        if "hack_objects_set" in action:
            d = action.pop("hack_objects_set")
            self.apply_layout(d if isinstance(d, dict) else {})
        if self.io is not None:
            try:
                if "hack_hand_force" in action:
                    self.io.set_force(action.pop("hack_hand_force"))
                self._status["hack_finger_effort"] = self.io.finger_effort()
                ft = self.io.wrist_ft()
                if ft is not None:
                    self._status["hack_ft"] = ft
            except Exception as e:
                print(f"[hack] robot io failed, off: {e}", flush=True)
                self.io = None
        if "hack_task_check" in action:
            action.pop("hack_task_check")
            try:
                self.evaluate()
            except Exception as e:
                print(f"[hack] task check failed: {e}", flush=True)
        if "hack_objects_randomize" in action:
            seed = int(action.pop("hack_objects_randomize"))
            sampler = STATE.get("_sampler")
            self.layout = sampler(seed) if sampler else sample_layout(self.names, seed, STATE["_info"], STATE["_spawn"])
            self.apply_layout(self.layout)
            print(f"[hack] objects randomized, seed {seed}", flush=True)

    def status(self):
        return self._status
