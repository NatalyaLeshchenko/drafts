# nssr-polygon scene: the warehouse, the work table, the trays and the task setup inside Isaac Lab.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import math, os
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
HACK = os.path.abspath(os.path.join(HERE, ".."))
ROOT = os.path.abspath(os.path.join(HACK, ".."))
INFO = {}


def _load():
    with open(os.path.join(HACK, "config", "scene.yaml")) as f:
        return yaml.safe_load(f)


def _qrot(q, v):
    w, x, y, z = q
    vx, vy, vz = v
    tx, ty, tz = 2 * (y * vz - z * vy), 2 * (z * vx - x * vz), 2 * (x * vy - y * vx)
    return (vx + w * tx + (y * tz - z * ty), vy + w * ty + (z * tx - x * tz), vz + w * tz + (x * ty - y * tx))


def pelvis_world(robot_cfg):
    from pxr import Usd, UsdGeom
    st = Usd.Stage.Open(robot_cfg.spawn.usd_path)
    root = st.GetDefaultPrim()
    off = (0.0, 0.0, 0.0)
    for p in Usd.PrimRange(root):
        if p.GetName() == "pelvis":
            m = UsdGeom.Xformable(p).ComputeLocalToWorldTransform(0)
            mr = UsdGeom.Xformable(root).ComputeLocalToWorldTransform(0).GetInverse()
            t = (m * mr).ExtractTranslation()
            mpu = UsdGeom.GetStageMetersPerUnit(st)
            off = (t[0] * mpu, t[1] * mpu, t[2] * mpu)
            break
    pos, rot = robot_cfg.init_state.pos, robot_cfg.init_state.rot
    d = _qrot(rot, off)
    return (pos[0] + d[0], pos[1] + d[1], pos[2] + d[2]), off


def _asset_root():
    r = os.environ.get("HACK_ASSET_ROOT")
    if r:
        return r.rstrip("/"), True
    import glob
    c = sorted(glob.glob("/isaac-assets/Assets/Isaac/*"))
    if c:
        return c[-1], True
    try:
        from isaaclab.utils.assets import NUCLEUS_ASSET_ROOT_DIR
        return NUCLEUS_ASSET_ROOT_DIR.rstrip("/"), False
    except Exception:
        return None, False


def _metrics_assembler_on():
    try:
        import omni.kit.app
        return omni.kit.app.get_app().get_extension_manager().is_extension_enabled("omni.usd.metrics.assembler")
    except Exception:
        return False


def decor(sc, px, py, floor_z):
    import isaaclab.sim as sim_utils
    from isaaclab.assets import AssetBaseCfg
    path = os.path.join(HACK, "config", "decor_resolved.yaml")
    if not os.path.exists(path):
        print("[hack] decor: no config/decor_resolved.yaml (run tools/isaac_assets.py resolve), hall stays bare", flush=True)
        return
    items = (yaml.safe_load(open(path)) or {}).get("items", [])
    items = items[:int(os.environ.get("HACK_DECOR_MAX", "999"))]
    root, local = _asset_root()
    if not root:
        print("[hack] decor: no asset root, skipped", flush=True); return
    assembler = _metrics_assembler_on()
    INFO["decor"], miss, nlights = [], [], 0
    try:
        lamp_cfg = yaml.safe_load(open(os.path.join(HACK, "config", "decor.yaml"))).get("lamp_light", {}) or {}
    except Exception:
        lamp_cfg = {}
    for it in items:
        usd = f"{root}/{it['rel']}"
        if local and not os.path.exists(usd):
            miss.append(it["rel"]); continue
        s = 1.0 if (assembler or abs(it["mpu"] - 1.0) < 1e-6) else float(it["mpu"])
        h = math.radians(it["yaw"]) / 2
        q = (math.cos(h), 0.0, 0.0, math.sin(h))
        if it.get("up") == "Y":
            c = math.cos(math.pi / 4)
            q = _qmul(q, (c, c, 0.0, 0.0))
        name = "".join(ch if ch.isalnum() else "_" for ch in it["name"])
        x, y, z = it["pos"]
        setattr(sc, f"hack_decor_{name}", AssetBaseCfg(
            prim_path=f"{{ENV_REGEX_NS}}/Decor_{name}",
            spawn=sim_utils.UsdFileCfg(usd_path=usd, scale=(s, s, s),
                                       rigid_props=sim_utils.RigidBodyPropertiesCfg(rigid_body_enabled=False)
                                       if it.get("rigid") else None),
            init_state=AssetBaseCfg.InitialStateCfg(pos=(px + x, py + y, floor_z + z), rot=q)))
        INFO["decor"].append({"path": f"/World/envs/env_0/Decor_{name}", "h": it["size"][2],
                              "z0": floor_z + it.get("top", it["size"][2]) - it["size"][2]})
        if "light" in it:
            L = lamp_cfg
            cx, cy = it["centre"]
            setattr(sc, f"hack_light_{name}", AssetBaseCfg(
                prim_path=f"{{ENV_REGEX_NS}}/Lamp_{name}",
                spawn=sim_utils.DiskLightCfg(radius=L.get("radius", 0.3), intensity=float(
                    os.environ.get("HACK_LAMP_INTENSITY", L.get("intensity", 25000))), color=tuple(L.get("color", (1, 1, 1)))),
                init_state=AssetBaseCfg.InitialStateCfg(pos=(px + cx, py + cy, floor_z + it["light"]))))
            nlights += 1
    print(f"[hack] decor: {len(INFO['decor'])} Isaac props, {nlights} lamp lights, from {'local pack ' + root if local else root}"
          f"{', MISSING ' + str(len(miss)) if miss else ''}, units {'by metrics assembler' if assembler else 'scaled here'}",
          flush=True)


def table_visual(t):
    v = t.get("visual")
    if not v or os.environ.get("HACK_TABLE_VISUAL", "1") != "1" or os.environ.get("HACK_DECOR", "1") != "1":
        return None
    root, local = _asset_root()
    if not root or (local and not os.path.exists(f"{root}/{v['usd']}")):
        print(f"[hack] table visual {v['usd']} not found under {root}, plain table", flush=True)
        return None
    yaw = math.radians(v.get("yaw", 90.0))
    x = t["front_gap"] + v["near_edge"]
    h, top, shelf = t["height"], v["top"], v.get("shelf")
    if shelf and h < top:
        sz, z = 1.0, h - top
        if shelf + z < 0.0:
            sz = (h + 0.02) / (top - shelf); z = -(shelf * sz + 0.02)
    else:
        sz, z = h / top, 0.0
    return {"rel": v["usd"], "pos": [x, 0.0, z], "quat": [math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2)],
            "scale": [1.0, 1.0, sz], "hide": list(v.get("hide", [])), "instanceable": False}


def task_cfg():
    with open(os.path.join(HACK, "config", "tasks.yaml")) as f:
        T = yaml.safe_load(f)
    name = os.environ.get("HACK_TASK") or T["default"]
    if name not in T["tasks"]:
        raise KeyError(f"[hack] HACK_TASK={name}: one of {list(T['tasks'])}")
    return dict(T["tasks"][name], name=name, pools_default=T.get("pools_default", 1))


def back_bins(cfg, enabled=True):
    import random
    from . import props
    b = cfg.get("back_bins")
    if not b or not enabled or os.environ.get("HACK_BINS", "1") != "1":
        return []
    seed = os.environ.get("HACK_BINS_SEED", b.get("seed"))
    rng = random.Random(int(seed) if seed not in (None, "") else None)
    names = b.get("objects")
    if not names:
        ocfg = yaml.safe_load(open(os.path.join(HACK, "config", "objects.yaml")))
        names = [o["name"] for o in ocfg.get("reserve", [])]
    objs = []
    for n in names:
        r = props.static_object_usd(os.path.join(HACK, "assets", "objects", n, f"{n}.usd"), n)
        if r:
            objs.append((n,) + r)
    bx, by, bz = b["box"]
    box = props.open_box_usd("open_box", (bx, by, bz))
    ptop = b.get("pallet_top", 0.211)
    items, placed = [], 0
    for (px_, py_) in b["pallets"]:
        items.append({"rel": b["pallet"], "pos": [px_, py_, 0.0], "quat": [1, 0, 0, 0], "scale": [1, 1, 1]})
        for dx in (-(bx / 2 + 0.02), bx / 2 + 0.02):
            cx, cy, cz = px_ + dx, py_, ptop
            yaw0 = rng.uniform(-2, 2)
            items.append({"usd": box, "pos": [cx, cy, cz], "quat": _yawq(yaw0), "scale": [1, 1, 1],
                          "instanceable": False})
            pick = rng.sample(objs, min(len(objs), b.get("per_box", 3))) if objs else []
            cur = -by / 2 + 0.03
            for n, path, lo, hi in pick:
                w, d = hi[0] - lo[0], hi[1] - lo[1]
                turn = 90.0 if w > d else 0.0
                fx, fy = (d, w) if turn else (w, d)
                if fx > bx - 0.05 or cur + fy > by / 2 - 0.03:
                    continue
                ox = rng.uniform(-(bx - 0.05 - fx) / 2, (bx - 0.05 - fx) / 2)
                oy = cur + fy / 2; cur += fy + rng.uniform(0.01, 0.05)
                yaw = turn + rng.choice([0.0, 180.0]) + rng.uniform(-6, 6)
                ccx, ccy = (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2
                c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
                items.append({"usd": path, "pos": [cx + ox - (c * ccx - s * ccy), cy + oy - (s * ccx + c * ccy),
                                                   cz + 0.007 - lo[2]],
                              "quat": _yawq(yaw), "scale": [1, 1, 1], "instanceable": False})
                placed += 1
    print(f"[hack] back bins: {len(b['pallets'])} pallets, {2 * len(b['pallets'])} open boxes, {placed} static objects "
          f"from {len(objs)} ({'seed ' + str(seed) if seed not in (None, '') else 'random'})", flush=True)
    return items


def _yawq(deg):
    a = math.radians(deg) / 2
    return [math.cos(a), 0.0, 0.0, math.sin(a)]


def warehouse(sc, px, py, floor_z, extra=()):
    import isaaclab.sim as sim_utils
    from isaaclab.assets import AssetBaseCfg
    from pxr import Sdf, Gf
    path = os.path.join(HACK, "config", "decor_warehouse.yaml")
    d = yaml.safe_load(open(path)) if os.path.exists(path) else {}
    if not d and not extra:
        return
    root, local = _asset_root()
    if not root:
        print("[hack] warehouse: no asset root, skipped", flush=True); return
    gen = os.path.join(os.environ.get("HACK_GEN_DIR", "/tmp/hack_gen"), "warehouse.usd")
    os.makedirs(os.path.dirname(gen), exist_ok=True)
    lay = Sdf.Layer.CreateAnonymous(".usda")
    lay.defaultPrim = "Warehouse"
    lay.pseudoRoot.SetInfo("metersPerUnit", 1.0); lay.pseudoRoot.SetInfo("upAxis", "Z")
    top = Sdf.PrimSpec(lay, "Warehouse", Sdf.SpecifierDef, "Xform")
    T, F = Sdf.ValueTypeNames, Sdf.VariabilityUniform

    def xform(spec, pos, quat, scale):
        Sdf.AttributeSpec(spec, "xformOp:translate", T.Double3).default = Gf.Vec3d(*pos)
        Sdf.AttributeSpec(spec, "xformOp:orient", T.Quatd).default = Gf.Quatd(quat[0], Gf.Vec3d(*quat[1:]))
        Sdf.AttributeSpec(spec, "xformOp:scale", T.Double3).default = Gf.Vec3d(*scale)
        Sdf.AttributeSpec(spec, "xformOpOrder", T.TokenArray, F).default = \
            ["xformOp:translate", "xformOp:orient", "xformOp:scale"]

    ok = {}; n = miss = 0
    for it in list(d.get("items", [])) + list(extra):
        rel = it.get("usd") or it["rel"]
        if rel not in ok:
            ok[rel] = os.path.exists(rel) if "usd" in it else ((not local) or os.path.exists(f"{root}/{rel}"))
        if not ok[rel]:
            miss += 1; continue
        sp = Sdf.PrimSpec(top, f"I_{n:04d}", Sdf.SpecifierDef, "Xform"); n += 1
        xform(sp, it["pos"], it["quat"], it["scale"])
        sp.referenceList.Prepend(Sdf.Reference(rel if "usd" in it else f"{root}/{rel}"))
        sp.SetInfo("instanceable", bool(it.get("instanceable", True)))
        for child in it.get("hide", []):
            Sdf.PrimSpec(sp, child, Sdf.SpecifierOver).SetInfo("active", False)
    gain = float(os.environ.get("HACK_LAMP_GAIN", "1.0"))
    for i, L in enumerate(d.get("lights", [])):
        sp = Sdf.PrimSpec(top, f"Light_{i:02d}", Sdf.SpecifierDef, "Xform")
        xform(sp, L["pos"], L["quat"], L["scale"])
        r = Sdf.PrimSpec(sp, "Rect", Sdf.SpecifierDef, "RectLight")
        Sdf.AttributeSpec(r, "inputs:width", T.Float).default = float(L["width"])
        Sdf.AttributeSpec(r, "inputs:height", T.Float).default = float(L["height"])
        Sdf.AttributeSpec(r, "inputs:intensity", T.Float).default = float(L["intensity"] * gain)
        Sdf.AttributeSpec(r, "inputs:exposure", T.Float).default = float(L.get("exposure", 0.0))
    lay.Export(gen)
    sc.hack_warehouse = AssetBaseCfg(prim_path="{ENV_REGEX_NS}/Warehouse", spawn=sim_utils.UsdFileCfg(usd_path=gen),
                                     init_state=AssetBaseCfg.InitialStateCfg(pos=(px, py, floor_z)))
    print(f"[hack] warehouse: {n} instanced props, {len(d.get('lights', []))} lamp lights from "
          f"{'local pack ' + root if local else root}{', MISSING ' + str(miss) if miss else ''}", flush=True)


def _qmul(a, b):
    w1, x1, y1, z1 = a; w2, x2, y2, z2 = b
    return (w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2, w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2,
            w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2, w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2)


def apply(env_cfg):
    mode = os.environ.get("HACK_SCENE", "polygon")
    dec = int(os.environ.get("HACK_DECIMATION", "1"))
    if dec != 1:
        env_cfg.decimation = dec
        print(f"[hack] decimation {dec}: control {1.0 / (env_cfg.sim.dt * dec):.0f} Hz, physics {1.0 / env_cfg.sim.dt:.0f} Hz",
              flush=True)
    cams = os.environ.get("HACK_CAMS")
    if cams is not None:
        keep = {c.strip() for c in cams.split(",") if c.strip()}
        for c in ("head", "torso"):
            if c not in keep and getattr(env_cfg.scene, "cam_" + c, None) is not None:
                setattr(env_cfg.scene, "cam_" + c, None)
                print(f"[hack] camera cam_{c} disabled (HACK_CAMS={cams})", flush=True)
    if os.environ.get("HACK_SELF_COLLISION", "0") == "1":
        ap = getattr(env_cfg.scene.robot.spawn, "articulation_props", None)
        if ap is not None:
            ap.enabled_self_collisions = True
            print("[hack] robot self-collisions ON", flush=True)
    if getattr(env_cfg, "_hack_applied", False):
        return
    env_cfg._hack_applied = True
    if mode != "polygon":
        print(f"[hack] scene: {mode} (original parlor)", flush=True)
        return
    import isaaclab.sim as sim_utils
    from isaaclab.assets import AssetBaseCfg, RigidObjectCfg
    from . import props

    cfg = _load()
    (px, py, pz), off = pelvis_world(env_cfg.scene.robot)
    floor_z = pz - cfg["standing_pelvis_height"] + float(os.environ.get("HACK_FLOOR_DZ", cfg.get("floor_dz", 0.0)))
    t = dict(cfg["table"])
    if os.environ.get("HACK_TABLE_H"):
        t["height"] = float(os.environ["HACK_TABLE_H"])
    top_z = floor_z + t["height"]
    INFO.update(pelvis=(px, py, pz), pelvis_offset=off, floor_z=floor_z, table_top_z=top_z,
                table_x=(px + t["front_gap"], px + t["front_gap"] + t["depth"]),
                table_y=(py - t["width"] / 2, py + t["width"] / 2))
    print(f"[hack] polygon: pelvis world ({px:.3f},{py:.3f},{pz:.3f}) [offset in USD {tuple(round(v,3) for v in off)}], "
          f"floor z {floor_z:.3f}, table top z {top_z:.3f} ({t['height']:.2f} m above floor, "
          f"{top_z - pz:+.3f} m vs pelvis)", flush=True)

    sc = env_cfg.scene
    env_usd = os.path.join(ROOT, cfg["env_usd"])
    if not os.path.exists(env_usd):
        env_usd = env_usd.replace("env.usd", "env_base.usd")
    sc.scene = AssetBaseCfg(prim_path="{ENV_REGEX_NS}/Scene", spawn=sim_utils.UsdFileCfg(usd_path=env_usd),
                            init_state=AssetBaseCfg.InitialStateCfg(pos=(px, py, floor_z)))
    print(f"[hack] environment: {os.path.relpath(env_usd, ROOT)}", flush=True)
    sc.light = AssetBaseCfg(prim_path="{ENV_REGEX_NS}/Light",
                            spawn=sim_utils.DomeLightCfg(color=(0.9, 0.9, 0.9), intensity=150.0))

    for name, area in cfg["floor_collider"].items():
        (x0, x1), (y0, y1) = area["x"], area["y"]
        setattr(sc, f"hack_floor_{name}", AssetBaseCfg(
            prim_path=f"{{ENV_REGEX_NS}}/HackFloor_{name}",
            spawn=sim_utils.CuboidCfg(size=(x1 - x0, y1 - y0, 0.1), visible=False,
                                      collision_props=sim_utils.CollisionPropertiesCfg()),
            init_state=AssetBaseCfg.InitialStateCfg(pos=(px + (x0 + x1) / 2, py + (y0 + y1) / 2, floor_z - 0.05))))

    vis = table_visual(t)
    t["collider_only"] = vis is not None
    sc.hack_table = AssetBaseCfg(prim_path="{ENV_REGEX_NS}/HackTable",
                                 spawn=sim_utils.UsdFileCfg(usd_path=props.table_usd(t)),
                                 init_state=AssetBaseCfg.InitialStateCfg(pos=(px + t["front_gap"], py, floor_z)))

    task = task_cfg()
    INFO["task"] = task
    tr = cfg["trays"]
    INFO["trays"], INFO["tray_colors"] = {}, {}
    for s in tr["slots"]:
        if s["name"] not in task.get("trays", []):
            continue
        x, y = s["xy"]
        pos = (px + x, py + y, top_z + 0.001)
        setattr(sc, f"hack_{s['name']}", RigidObjectCfg(
            prim_path=f"{{ENV_REGEX_NS}}/Hack_{s['name']}",
            spawn=sim_utils.UsdFileCfg(usd_path=props.tray_usd(s["name"], tr["size"], tr["wall"], s["color"])),
            init_state=RigidObjectCfg.InitialStateCfg(pos=pos)))
        INFO["trays"][s["name"]] = pos
        INFO["tray_colors"][s["name"]] = s.get("label", s["name"])
    print(f"[hack] task {task['name']}: {task.get('ru', '')}", flush=True)
    print(f"[hack] table {t['width']}x{t['depth']} m at x+{t['front_gap']} m, top {t['height']:.3f} m"
          f"{', visual ' + vis['rel'].split('/')[-1] if vis else ''}; trays: {list(INFO['trays'])}", flush=True)

    INFO["table"] = t
    INFO["tray_size"] = tr["size"]
    if os.environ.get("HACK_DECOR", "1") == "1":
        warehouse(sc, px, py, floor_z, ([vis] if vis else []) + back_bins(cfg, task.get("back_bins", False)))
        decor(sc, px, py, floor_z)
    from . import objects
    if task["mode"] == "lab":
        from . import lab
        objects.STATE["_task"] = lab.apply(env_cfg, INFO)
    elif os.environ.get("HACK_OBJECTS", "") != "none":
        objects.apply(env_cfg, INFO)
