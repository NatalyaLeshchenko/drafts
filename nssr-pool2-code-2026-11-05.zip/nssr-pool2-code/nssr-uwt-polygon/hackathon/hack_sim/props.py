# Generated scene props: table colliders, open boxes and static copies of dataset objects.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
import os
from pxr import Usd, UsdGeom, UsdShade, UsdPhysics, Sdf, Gf

HERE = os.path.dirname(os.path.abspath(__file__))
GEN = os.environ.get("HACK_GEN_DIR", "/tmp/hack_gen")


def _stage(path, root):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        os.remove(path)
    st = Usd.Stage.CreateNew(path)
    UsdGeom.SetStageUpAxis(st, UsdGeom.Tokens.z)
    UsdGeom.SetStageMetersPerUnit(st, 1.0)
    UsdPhysics.SetStageKilogramsPerUnit(st, 1.0)
    r = UsdGeom.Xform.Define(st, root)
    st.SetDefaultPrim(r.GetPrim())
    return st, r


TEX = os.path.abspath(os.path.join(HERE, "..", "assets", "scenes", "nssr-polygon", "textures"))


def _hd_maps(key, size=1.0):
    hd = os.path.join(TEX, "hd", key)
    if os.path.exists(os.path.join(hd, "albedo.jpg")):
        try:
            import json
            size = float(json.load(open(os.path.join(TEX, "hd", "manifest.json")))[key]["size_m"])
        except Exception:
            pass
        return os.path.join(hd, "albedo.jpg"), os.path.join(hd, "normal.jpg"), os.path.join(hd, "rough.jpg"), size
    if os.path.exists(os.path.join(TEX, f"{key}_albedo.jpg")):
        return os.path.join(TEX, f"{key}_albedo.jpg"), os.path.join(TEX, f"{key}_normal.png"), None, 1.0
    return None


def _wood_maps():
    return _hd_maps("wood", 1.83)


def _material(st, path, color, rough=0.7, maps=None):
    m = UsdShade.Material.Define(st, path)
    sh = UsdShade.Shader.Define(st, path + "/Shader")
    sh.SetSourceAsset(Sdf.AssetPath("OmniPBR.mdl"), "mdl")
    sh.SetSourceAssetSubIdentifier("OmniPBR", "mdl")
    sh.CreateInput("diffuse_color_constant", Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(*color))
    sh.CreateInput("reflection_roughness_constant", Sdf.ValueTypeNames.Float).Set(rough)
    if maps:
        alb, nrm, rgh, size = maps
        sh.CreateInput("diffuse_texture", Sdf.ValueTypeNames.Asset).Set(Sdf.AssetPath(alb))
        i = sh.CreateInput("normalmap_texture", Sdf.ValueTypeNames.Asset); i.Set(Sdf.AssetPath(nrm)); i.GetAttr().SetColorSpace("raw")
        if rgh:
            i = sh.CreateInput("reflectionroughness_texture", Sdf.ValueTypeNames.Asset); i.Set(Sdf.AssetPath(rgh))
            i.GetAttr().SetColorSpace("raw")
            sh.CreateInput("reflection_roughness_texture_influence", Sdf.ValueTypeNames.Float).Set(1.0)
        sh.CreateInput("texture_scale", Sdf.ValueTypeNames.Float2).Set(Gf.Vec2f(1.0 / size, 1.0 / size))
    m.CreateSurfaceOutput("mdl").ConnectToSource(sh.ConnectableAPI(), "out")
    pm = UsdPhysics.MaterialAPI.Apply(m.GetPrim())
    pm.CreateStaticFrictionAttr(0.8); pm.CreateDynamicFrictionAttr(0.7); pm.CreateRestitutionAttr(0.0)
    return m


def _box(st, path, center, size, mat, collide=True):
    c = UsdGeom.Cube.Define(st, path)
    c.CreateSizeAttr(1.0)
    c.AddTranslateOp().Set(Gf.Vec3d(*center))
    c.AddScaleOp().Set(Gf.Vec3f(*size))
    b = UsdShade.MaterialBindingAPI.Apply(c.GetPrim())
    b.Bind(mat)
    b.Bind(mat, UsdShade.Tokens.weakerThanDescendants, "physics")
    if collide:
        UsdPhysics.CollisionAPI.Apply(c.GetPrim())
    return c


def _mesh_box(st, path, center, size, mat):
    cx, cy, cz = center; hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
    F = [([(hx, -hy, -hz), (hx, hy, -hz), (hx, hy, hz), (hx, -hy, hz)], 1, 2),
         ([(-hx, hy, -hz), (-hx, -hy, -hz), (-hx, -hy, hz), (-hx, hy, hz)], 1, 2),
         ([(hx, hy, -hz), (-hx, hy, -hz), (-hx, hy, hz), (hx, hy, hz)], 0, 2),
         ([(-hx, -hy, -hz), (hx, -hy, -hz), (hx, -hy, hz), (-hx, -hy, hz)], 0, 2),
         ([(-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)], 0, 1),
         ([(-hx, hy, -hz), (hx, hy, -hz), (hx, -hy, -hz), (-hx, -hy, -hz)], 0, 1)]
    P, UV = [], []
    for cs, u, v in F:
        for c in cs:
            P.append(Gf.Vec3f(cx + c[0], cy + c[1], cz + c[2]))
            UV.append(Gf.Vec2f(cx + c[0] if u == 0 else cy + c[1], cz + c[2] if v == 2 else cy + c[1]))
    m = UsdGeom.Mesh.Define(st, path)
    m.CreatePointsAttr(P); m.CreateFaceVertexCountsAttr([4] * 6); m.CreateFaceVertexIndicesAttr(list(range(24)))
    m.CreateSubdivisionSchemeAttr("none")
    UsdGeom.PrimvarsAPI(m).CreatePrimvar("st", Sdf.ValueTypeNames.TexCoord2fArray, UsdGeom.Tokens.faceVarying).Set(UV)
    b = UsdShade.MaterialBindingAPI.Apply(m.GetPrim())
    b.Bind(mat)
    b.Bind(mat, UsdShade.Tokens.weakerThanDescendants, "physics")
    UsdPhysics.CollisionAPI.Apply(m.GetPrim())
    UsdPhysics.MeshCollisionAPI.Apply(m.GetPrim()).CreateApproximationAttr("convexHull")
    return m


def table_usd(t):
    path = os.path.abspath(os.path.join(GEN, "table.usd"))
    st, r = _stage(path, "/Table")
    if t.get("collider_only"):
        steel = _material(st, "/Table/Looks/Steel", (0.25, 0.26, 0.27), 0.35)
        h, w, d, th = t["height"], t["width"], t["depth"], t["top_thickness"]
        m = _mesh_box(st, "/Table/Top", (d / 2, 0, h - th / 2), (d, w, th), steel)
        UsdGeom.Imageable(m.GetPrim()).MakeInvisible()
        st.GetRootLayer().Save()
        return path
    maps = _wood_maps()
    mat = _material(st, "/Table/Looks/Wood", (1.0, 1.0, 1.0) if maps else t["color"], 0.6, maps)
    steel = _material(st, "/Table/Looks/Steel", (0.25, 0.26, 0.27), 0.35)
    h, w, d, th, leg = t["height"], t["width"], t["depth"], t["top_thickness"], t["leg"]
    _mesh_box(st, "/Table/Top", (d / 2, 0, h - th / 2), (d, w, th), mat)
    lh = h - th
    for i, (x, y) in enumerate([(leg, w / 2 - leg), (leg, -w / 2 + leg), (d - leg, w / 2 - leg), (d - leg, -w / 2 + leg)]):
        _mesh_box(st, f"/Table/Leg_{i}", (x, y, lh / 2), (leg, leg, lh), steel)
    st.GetRootLayer().Save()
    return path


def tray_usd(name, size, wall, color):
    path = os.path.abspath(os.path.join(GEN, f"{name}.usd"))
    st, r = _stage(path, "/Tray")
    rb = UsdPhysics.RigidBodyAPI.Apply(r.GetPrim())
    rb.CreateKinematicEnabledAttr(True)
    UsdPhysics.MassAPI.Apply(r.GetPrim()).CreateMassAttr(0.5)
    mat = _material(st, "/Tray/Looks/Plastic", color, 0.5)
    sx, sy, sz = size
    _box(st, "/Tray/Bottom", (0, 0, wall / 2), (sx, sy, wall), mat)
    _box(st, "/Tray/WallXp", (sx / 2 - wall / 2, 0, sz / 2), (wall, sy, sz), mat)
    _box(st, "/Tray/WallXn", (-sx / 2 + wall / 2, 0, sz / 2), (wall, sy, sz), mat)
    _box(st, "/Tray/WallYp", (0, sy / 2 - wall / 2, sz / 2), (sx, wall, sz), mat)
    _box(st, "/Tray/WallYn", (0, -sy / 2 + wall / 2, sz / 2), (sx, wall, sz), mat)
    st.GetRootLayer().Save()
    return path


def open_box_usd(name, size, wall=0.006):
    path = os.path.abspath(os.path.join(GEN, f"{name}.usd"))
    st, r = _stage(path, "/Box")
    maps = _hd_maps("cardboard", 1.0)
    mat = _material(st, "/Box/Looks/Cardboard", (1.0, 1.0, 1.0) if maps else (0.55, 0.40, 0.24), 0.9, maps)
    sx, sy, sz = size
    _mesh_box(st, "/Box/Bottom", (0, 0, wall / 2), (sx, sy, wall), mat)
    _mesh_box(st, "/Box/WallXp", (sx / 2 - wall / 2, 0, sz / 2), (wall, sy, sz), mat)
    _mesh_box(st, "/Box/WallXn", (-sx / 2 + wall / 2, 0, sz / 2), (wall, sy, sz), mat)
    _mesh_box(st, "/Box/WallYp", (0, sy / 2 - wall / 2, sz / 2), (sx - 2 * wall, wall, sz), mat)
    _mesh_box(st, "/Box/WallYn", (0, -sy / 2 + wall / 2, sz / 2), (sx - 2 * wall, wall, sz), mat)
    st.GetRootLayer().Save()
    return path


def static_object_usd(src, name):
    if not os.path.isfile(src):
        return None
    s_st = Usd.Stage.Open(src)
    s_root = s_st.GetDefaultPrim() or next(iter(s_st.GetPseudoRoot().GetChildren()))
    mpu, up = UsdGeom.GetStageMetersPerUnit(s_st), UsdGeom.GetStageUpAxis(s_st)
    path = os.path.abspath(os.path.join(GEN, f"static_{name}.usd"))
    st, root = _stage(path, "/Object")
    fix = abs(mpu - 1.0) > 1e-6 or up != UsdGeom.Tokens.z
    holder = UsdGeom.Xform.Define(st, "/Object/geom") if fix else root
    holder.GetPrim().GetReferences().AddReference(src, s_root.GetPath())
    if fix:
        if up == UsdGeom.Tokens.y:
            holder.AddRotateXOp().Set(90.0)
        if abs(mpu - 1.0) > 1e-6:
            holder.AddScaleOp().Set(Gf.Vec3f(mpu, mpu, mpu))
    for p in Usd.PrimRange(s_root):
        if p.HasAPI(UsdPhysics.RigidBodyAPI):
            rel = p.GetPath().MakeRelativePath(s_root.GetPath())
            q = holder.GetPrim() if str(rel) == "." else st.OverridePrim(holder.GetPath().AppendPath(rel))
            q.CreateAttribute("physics:rigidBodyEnabled", Sdf.ValueTypeNames.Bool).Set(False)
    st.GetRootLayer().Save()
    bb = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render]) \
        .ComputeWorldBound(root.GetPrim()).ComputeAlignedRange()
    return path, list(bb.GetMin()), list(bb.GetMax())
