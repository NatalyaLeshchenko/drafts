#!/bin/bash
# Simulator container: build the image, start, initialise, check, shell.
# Author: Nikolay Semenov <nssr.nikolay@gmail.com>
set -e
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
CONTAINER_NAME="${SIM_CONTAINER:-nssr-sim}"
IMAGE="${SIM_IMAGE:-nssr-sim:latest}"
BASE_IMAGE="${BASE_IMAGE:-nvcr.io/nvidia/isaac-lab:2.2.0}"
CACHE_DIR="${SIM_CACHE_DIR:-$HOME/.cache/nssr-sim}"
ASSETS="${ISAAC_ASSETS:-$PROJECT_DIR/assets/isaac}"
[ -n "${ISAAC_ASSETS:-}" ] || [ -d "$ASSETS" ] || ASSETS="$HOME/isaacsim_assets"
ROBOT_USD="$PROJECT_DIR/assets/robots/tiangong_pro/tiangong_pro_v2.usd"

exists() { docker ps -a --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; }
running() { docker ps --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; }
need_running() { running || { echo "[ERROR] container $CONTAINER_NAME is not running: bash $0 start"; exit 1; }; }

case "${1:-}" in
  build)
    docker build --build-arg BASE_IMAGE="$BASE_IMAGE" -t "$IMAGE" -f "$PROJECT_DIR/hackathon/docker/Dockerfile" "$PROJECT_DIR"
    ;;
  start)
    if running; then echo "[INFO] $CONTAINER_NAME is already running"; exit 0; fi
    xhost +local: >/dev/null 2>&1 || true
    if exists; then docker start "$CONTAINER_NAME"; exit 0; fi
    [ -d "$ASSETS" ] || echo "[WARN] no asset folder ($ASSETS): bash hackathon/tools/get_assets.sh, then bash $0 rm && bash $0 start"
    mkdir -p "$CACHE_DIR"/{kit,glcache,ov,pip,computecache,data,logs,documents}
    [ -f "$HOME/.Xauthority" ] || touch "$HOME/.Xauthority"
    MOUNT_ASSETS=()
    [ -d "$ASSETS" ] && MOUNT_ASSETS=(-v "$ASSETS:/isaac-assets:ro")
    docker run -d --name "$CONTAINER_NAME" --gpus all --network host --ipc host --privileged \
      --entrypoint /bin/bash --shm-size=16g \
      -v "$PROJECT_DIR:/nssr_sim" "${MOUNT_ASSETS[@]}" \
      -v "$CACHE_DIR/kit:/isaac-sim/kit/cache:rw" \
      -v "$CACHE_DIR/glcache:/root/.cache/nvidia/GLCache:rw" \
      -v "$CACHE_DIR/ov:/root/.cache/ov:rw" \
      -v "$CACHE_DIR/pip:/root/.cache/pip:rw" \
      -v "$CACHE_DIR/computecache:/root/.nv/ComputeCache:rw" \
      -v "$CACHE_DIR/data:/root/.local/share/ov/data:rw" \
      -v "$CACHE_DIR/logs:/root/.nvidia-omniverse/logs:rw" \
      -v "$CACHE_DIR/documents:/root/Documents:rw" \
      -v /tmp/.X11-unix:/tmp/.X11-unix -v "$HOME/.Xauthority:/root/.Xauthority:rw" -v /dev/shm:/dev/shm \
      -e DISPLAY="$DISPLAY" -w /nssr_sim "$IMAGE" -c "tail -f /dev/null"
    echo "[INFO] $CONTAINER_NAME started. First time: bash $0 init"
    ;;
  init)
    need_running
    docker exec "$CONTAINER_NAME" bash -c "cd /nssr_sim/source && /isaac-sim/python.sh -m pip install --no-deps -e ."
    echo "[INFO] initialized. Next: bash hackathon/tools/task.sh sort3"
    ;;
  check)
    need_running
    docker exec "$CONTAINER_NAME" bash -c "set -e; \
      /isaac-sim/python.sh -c 'import nssr_sim' && echo '[OK] simulator package'; \
      /isaac-sim/python.sh -c 'import zmq, numpy; assert int(numpy.__version__.split(\".\")[0]) < 2' && echo '[OK] python deps'; \
      test -f /opt/ros/humble/setup.bash && echo '[OK] ROS 2 Humble'; \
      dpkg -l ros-humble-bodyctrl-msgs >/dev/null && echo '[OK] bodyctrl_msgs'; \
      nvidia-smi --query-gpu=name,memory.total --format=csv,noheader | sed 's/^/[OK] GPU: /'; \
      if test \$(stat -c %s /nssr_sim/assets/robots/tiangong_pro/tiangong_pro_v2.usd 2>/dev/null || echo 0) -gt 1000000; \
      then echo '[OK] robot model'; else echo '[ERROR] no robot model: bash hackathon/tools/get_assets.sh'; fi; \
      if test -d /isaac-assets/Assets/Isaac; then echo '[OK] local Isaac asset pack'; \
      else echo '[WARN] no Isaac assets mounted: bash hackathon/tools/get_assets.sh, then run.sh rm / start / init'; fi"
    ;;
  bash)
    need_running
    docker exec -it "$CONTAINER_NAME" bash -c "source /opt/ros/humble/setup.bash; exec bash"
    ;;
  stop)
    running && docker stop "$CONTAINER_NAME" || echo "[INFO] $CONTAINER_NAME is not running"
    ;;
  rm)
    exists && docker rm -f "$CONTAINER_NAME" >/dev/null && echo "[INFO] $CONTAINER_NAME removed" || true
    ;;
  *)
    cat <<'TXT'
Simulator container (host, from the repository root):
  bash hackathon/docker/run.sh build    build the image (once, ~30 min, needs internet)
  bash hackathon/docker/run.sh start    create / start the container
  bash hackathon/docker/run.sh init     install the simulator package inside (once per container)
  bash hackathon/docker/run.sh check    check the environment
  bash hackathon/docker/run.sh bash     shell inside the container with ROS 2
  bash hackathon/docker/run.sh stop | rm
Assets (robot model, warehouse): bash hackathon/tools/get_assets.sh before the first start
Environment: SIM_CONTAINER, SIM_IMAGE, BASE_IMAGE, SIM_CACHE_DIR, ISAAC_ASSETS (Isaac asset folder, default assets/isaac)
TXT
    ;;
esac
