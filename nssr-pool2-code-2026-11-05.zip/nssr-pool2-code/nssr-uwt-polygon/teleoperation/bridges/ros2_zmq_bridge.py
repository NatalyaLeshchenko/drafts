#!/usr/bin/env python3
# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState, Image
from geometry_msgs.msg import Point
from std_msgs.msg import Bool, Float32
from rosgraph_msgs.msg import Clock
from builtin_interfaces.msg import Time
try:
    from bodyctrl_msgs.msg import MotorStatusMsg, MotorStatus, CmdSetMotorPosition, CmdMotorCtrl
except ImportError:
    raise ImportError(
        "bodyctrl_msgs not found. "
        "source /opt/ros/humble/setup.bash && "
        "colcon build --packages-select bodyctrl_msgs"
    )

import zmq
import yaml
import os
import sys
import subprocess
import threading
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "control"))
from constants import ID_TO_NAME as _ID_TO_NAME, NAME_TO_ID as _NAME_TO_ID
from constants import HAND_L_MAP as _HAND_L_MAP, HAND_R_MAP as _HAND_R_MAP
from constants import ID_HEAD, ID_ARM_L, ID_ARM_R, ID_WAIST, ID_LEG_L, ID_LEG_R


def load_bridge_config():
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bridge_config.yaml")
    with open(config_path) as f:
        return yaml.safe_load(f)


MSG_TYPES = {
    "CmdSetMotorPosition": CmdSetMotorPosition,
    "CmdMotorCtrl": CmdMotorCtrl,
    "JointState": JointState,
    "Point": Point,
    "Bool": Bool,
    "MotorStatusMsg": MotorStatusMsg,
    "Float32": Float32,
    "Image": Image,
}


class TiangongRosBridge(Node):
    def __init__(self):
        super().__init__('tiangong_ros_bridge')

        self.cfg = load_bridge_config()
        zmq_cfg = self.cfg["zmq"]

        self.zmq_context = zmq.Context()

        self.cmd_socket = self.zmq_context.socket(zmq.PUB)
        self.cmd_socket.bind(f"tcp://*:{zmq_cfg['cmd_port']}")

        self.status_socket = self.zmq_context.socket(zmq.SUB)
        self.status_socket.connect(f"tcp://127.0.0.1:{zmq_cfg['status_port']}")
        self.status_socket.setsockopt(zmq.RCVHWM, 1)
        self.status_socket.setsockopt_string(zmq.SUBSCRIBE, "")

        self.ID_HEAD = ID_HEAD
        self.ID_ARM_L = ID_ARM_L
        self.ID_ARM_R = ID_ARM_R
        self.ID_WAIST = ID_WAIST
        self.ID_LEG_L = ID_LEG_L
        self.ID_LEG_R = ID_LEG_R

        self.ID_TO_NAME = _ID_TO_NAME
        self.NAME_TO_ID = _NAME_TO_ID

        self.HAND_L_MAP = _HAND_L_MAP
        self.HAND_R_MAP = _HAND_R_MAP

        SUB_CALLBACKS = {
            "arm_cmd_pos":   self.cmd_pos_cb,
            "arm_cmd_ctrl":  self.cmd_ctrl_cb,
            "head_cmd_pos":  self.cmd_pos_cb,
            "head_cmd_ctrl": self.cmd_ctrl_cb,
            "leg_cmd_pos":   self.cmd_pos_cb,
            "leg_cmd_ctrl":  self.cmd_ctrl_cb,
            "waist_cmd_pos": self.cmd_pos_cb,
            "waist_cmd_ctrl":self.cmd_ctrl_cb,
            "hand_l_ctrl":   lambda m: self.hand_cb(m, "left"),
            "hand_r_ctrl":   lambda m: self.hand_cb(m, "right"),
            "apple_offset":  self.apple_cb,
            "cmd_reset":     self.cmd_reset_cb,
        }
        self._shaper = os.environ.get("HACK_SHAPER", "1") == "1"
        _shaped = ("arm_cmd_pos", "arm_cmd_ctrl", "head_cmd_pos", "head_cmd_ctrl", "waist_cmd_pos", "waist_cmd_ctrl",
                   "hand_l_ctrl", "hand_r_ctrl")
        for key, spec in self.cfg["topics"]["sub"].items():
            if self._shaper and key in _shaped:
                continue
            msg_type = MSG_TYPES[spec["type"]]
            cb = SUB_CALLBACKS.get(key)
            if cb:
                self.create_subscription(msg_type, spec["topic"], cb, spec.get("qos", 1))

        self.pubs = {}
        for key, spec in self.cfg["topics"]["pub"].items():
            if key in ("image_rgb", "image_depth"):
                continue
            if os.environ.get("HACK_SHAPER", "1") == "1" and key in ("hand_l_state", "hand_r_state"):
                continue
            msg_type = MSG_TYPES[spec["type"]]
            self.pubs[key] = self.create_publisher(msg_type, spec["topic"], spec.get("qos", 10))

        self.pub_joint_states = self.create_publisher(JointState, "/joint_states", 10)
        self.pub_clock = self.create_publisher(Clock, "/clock", 10)
        self.extra_procs = []
        if os.environ.get("HACK_SIM_NODE", "1") == "1":
            _node = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                  "..", "..", "hackathon", "ros2", "nssr_polygon",
                                                  "nssr_polygon", "sim_node.py"))
            if os.path.isfile(_node):
                import sys as _sys
                self.extra_procs.append(subprocess.Popen([_sys.executable, _node]))
                self.get_logger().info(f"hack_sim_node started: {_node}")
        if os.environ.get("HACK_RSP", "1") == "1":
            urdf_path = os.environ.get("HACK_URDF", os.path.normpath(os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "..", "..",
                "assets/robots/tiangong_pro/tiangong_pro_with_hands.urdf")))
            try:
                with open(urdf_path) as f:
                    urdf = f.read()
                params = "/tmp/hack_rsp_params.yaml"
                with open(params, "w") as f:
                    yaml.safe_dump({"robot_state_publisher": {"ros__parameters": {
                        "robot_description": urdf, "use_sim_time": True, "publish_frequency": 100.0}}}, f)
                self.extra_procs.append(subprocess.Popen([
                    "ros2", "run", "robot_state_publisher", "robot_state_publisher",
                    "--ros-args", "--params-file", params]))
                self.get_logger().info(f"robot_state_publisher started with {urdf_path}")
            except Exception as e:
                self.get_logger().error(f"robot_state_publisher not started: {e}")

        self._running = True
        self._poll_thread = threading.Thread(target=self._poll_loop)
        self._poll_thread.start()
        self.get_logger().info("Tiangong ROS 2 Bridge (Control Only) Started")

        self.cpp_bridge_process = None
        if os.environ.get("DISABLE_CPP_IMAGE_BRIDGE", "0") != "1":
            self.start_cpp_bridge()
        else:
            self.get_logger().info("C++ Image Bridge disabled by environment variable.")

    def start_cpp_bridge(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        if os.environ.get("HACK_CAM_BRIDGE", "py") == "py":
            import sys as _sys
            cam_bridge = os.path.normpath(os.path.join(script_dir, "..", "..", "hackathon", "ros2", "nssr_polygon",
                                                       "nssr_polygon", "camera_bridge.py"))
            self.get_logger().info(f"Starting Python camera bridge: {cam_bridge}")
            self.cpp_bridge_process = subprocess.Popen([_sys.executable, cam_bridge], cwd=script_dir)
            return
        build_script = os.path.join(script_dir, "build_cpp_bridge.sh")
        executable = os.path.join(script_dir, "zmq_image_bridge")
        cpp_source = os.path.join(script_dir, "zmq_image_bridge.cpp")
        cmake_source = os.path.join(script_dir, "CMakeLists.txt")

        need_build = True
        if os.path.isfile(executable) and os.access(executable, os.X_OK):
            exe_mtime = os.path.getmtime(executable)
            src_mtime = max(os.path.getmtime(cpp_source), os.path.getmtime(cmake_source))
            if exe_mtime > src_mtime:
                need_build = False
                self.get_logger().info("C++ Bridge binary is up-to-date, skipping build.")

        if need_build:
            self.get_logger().info(f"Building C++ Bridge: {build_script} ...")
            subprocess.run(["chmod", "+x", build_script], cwd=script_dir)
            res = subprocess.run([build_script], cwd=script_dir,
                                 capture_output=True, text=True)
            if res.returncode != 0:
                self.get_logger().error(
                    f"C++ Bridge build failed:\n{res.stderr}\n"
                    "Image publishing will be unavailable. "
                    "Set DISABLE_CPP_IMAGE_BRIDGE=1 to suppress."
                )
                return

        if not os.path.isfile(executable):
            self.get_logger().error("C++ Bridge executable not found. Image publishing unavailable.")
            return

        pub_cfg = self.cfg["topics"]["pub"]
        zmq_cfg = self.cfg["zmq"]
        args = [
            executable,
            "--zmq-port",    str(zmq_cfg["image_port"]),
            "--rgb-topic",   pub_cfg["image_rgb"]["topic"],
            "--depth-topic", pub_cfg["image_depth"]["topic"],
        ]
        self.get_logger().info(f"Starting C++ Bridge: {' '.join(args)}")
        try:
            self.cpp_bridge_process = subprocess.Popen(args, cwd=script_dir)
        except Exception as e:
            self.get_logger().error(f"Failed to start C++ Bridge: {e}")
            self.cpp_bridge_process = None

    def cmd_pos_cb(self, msg):
        current_action = {}
        for cmd in msg.cmds:
            joint_name = self.ID_TO_NAME.get(cmd.name)
            if joint_name:
                current_action[joint_name] = float(cmd.pos)
        self.cmd_socket.send_json(current_action)

    def cmd_ctrl_cb(self, msg):
        current_action = {}
        for cmd in msg.cmds:
            joint_name = self.ID_TO_NAME.get(cmd.name)
            if joint_name:
                current_action[joint_name] = float(cmd.pos)
        self.cmd_socket.send_json(current_action)

    def hand_cb(self, msg, side):
        current_action = {}
        map_target = self.HAND_L_MAP if side == "left" else self.HAND_R_MAP
        for i, name in enumerate(msg.name):
            try:
                id_val = int(name)
                joint_name = map_target.get(id_val)
                if joint_name:
                    current_action[joint_name] = float(msg.position[i])
            except: pass
        self.cmd_socket.send_json(current_action)

    def apple_cb(self, msg):
        self.cmd_socket.send_json({"apple_offset": [msg.x, msg.y]})

    def cmd_reset_cb(self, msg):
        if msg.data:
             self.cmd_socket.send_json({"reset": True})

    def _poll_loop(self):
        poller = zmq.Poller()
        poller.register(self.status_socket, zmq.POLLIN)

        while self._running:
            socks = dict(poller.poll(timeout=1))
            if self.status_socket in socks:
                try:
                    msg = self.status_socket.recv_json(flags=zmq.NOBLOCK)
                    self.publish_status(msg)
                    if "task_dist" in msg:
                        f = Float32()
                        f.data = float(msg["task_dist"])
                        self.pubs["task_dist"].publish(f)
                except Exception as e:
                    pass

    def publish_status(self, data):
        if isinstance(data, dict) and "joint_names" in data:
            pos_map = dict(zip(data["joint_names"], data["joint_pos"]))
            finger_percentages = data.get("finger_percentages", {})
            vel_map = dict(zip(data["joint_names"], data["joint_vel"])) if "joint_vel" in data else {}
        else:
            pos_map = data
            finger_percentages = {}
            vel_map = {}

        if isinstance(data, dict) and "sim_time" in data:
            _t = float(data["sim_time"])
            header = Time(sec=int(_t), nanosec=int((_t - int(_t)) * 1e9))
            self.pub_clock.publish(Clock(clock=header))
        else:
            header = self.get_clock().now().to_msg()
        if isinstance(data, dict) and "joint_names" in data:
            js = JointState()
            js.header.stamp = header
            js.name = list(data["joint_names"])
            js.position = [float(x) for x in data["joint_pos"]]
            if "joint_vel" in data:
                js.velocity = [float(x) for x in data["joint_vel"]]
            self.pub_joint_states.publish(js)

        def create_motor_msg(id_range):
            m_msg = MotorStatusMsg()
            m_msg.header.stamp = header
            for name, id_val in self.NAME_TO_ID.items():
                if id_val in id_range and name in pos_map:
                    s = MotorStatus()
                    s.name = id_val
                    s.pos = float(pos_map[name])
                    s.speed = float(vel_map.get(name, 0.0))
                    m_msg.status.append(s)
            return m_msg

        def create_hand_msg(hand_map):
            h_msg = JointState()
            h_msg.header.stamp = header
            h_msg.name = []
            h_msg.position = []
            h_msg.velocity = []

            for i in range(1, 7):
                sim_name = hand_map.get(i)
                h_msg.name.append(str(i))

                pos_val = 0.0
                vel_val = 0.0

                if sim_name and sim_name in finger_percentages:
                    pos_val = float(finger_percentages[sim_name])
                    if sim_name in vel_map:
                        vel_val = float(vel_map[sim_name])

                h_msg.position.append(pos_val)
                h_msg.velocity.append(vel_val)
                h_msg.effort.append(0.0)

            return h_msg

        self.pubs["arm_status"].publish(create_motor_msg(self.ID_ARM_L + self.ID_ARM_R))
        self.pubs["head_status"].publish(create_motor_msg(self.ID_HEAD))
        self.pubs["leg_status"].publish(create_motor_msg(self.ID_LEG_L + self.ID_LEG_R))
        self.pubs["waist_status"].publish(create_motor_msg(self.ID_WAIST))

        if not self._shaper:
            self.pubs["hand_l_state"].publish(create_hand_msg(self.HAND_L_MAP))
            self.pubs["hand_r_state"].publish(create_hand_msg(self.HAND_R_MAP))

    def stop(self):
        self._running = False
        self._poll_thread.join()
        for p in getattr(self, "extra_procs", []):
            p.terminate()
        if self.cpp_bridge_process:
            self.get_logger().info("Stopping C++ Bridge...")
            self.cpp_bridge_process.terminate()
            try:
                self.cpp_bridge_process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.cpp_bridge_process.kill()

if __name__ == '__main__':
    rclpy.init()
    node = TiangongRosBridge()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    node.stop()
    node.destroy_node()
    rclpy.shutdown()
