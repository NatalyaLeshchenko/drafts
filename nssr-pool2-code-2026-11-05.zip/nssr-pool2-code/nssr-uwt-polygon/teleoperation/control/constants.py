# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
ID_TO_NAME = {
    1: "head_roll_joint", 2: "head_pitch_joint", 3: "head_yaw_joint",
    11: "shoulder_pitch_l_joint", 12: "shoulder_roll_l_joint", 13: "shoulder_yaw_l_joint",
    14: "elbow_pitch_l_joint", 15: "elbow_yaw_l_joint", 16: "wrist_pitch_l_joint", 17: "wrist_roll_l_joint",
    21: "shoulder_pitch_r_joint", 22: "shoulder_roll_r_joint", 23: "shoulder_yaw_r_joint",
    24: "elbow_pitch_r_joint", 25: "elbow_yaw_r_joint", 26: "wrist_pitch_r_joint", 27: "wrist_roll_r_joint",
    31: "body_yaw_joint",
    51: "hip_roll_l_joint", 52: "hip_pitch_l_joint", 53: "hip_yaw_l_joint",
    54: "knee_pitch_l_joint", 55: "ankle_pitch_l_joint", 56: "ankle_roll_l_joint",
    61: "hip_roll_r_joint", 62: "hip_pitch_r_joint", 63: "hip_yaw_r_joint",
    64: "knee_pitch_r_joint", 65: "ankle_pitch_r_joint", 66: "ankle_roll_r_joint",
}

NAME_TO_ID = {v: k for k, v in ID_TO_NAME.items()}

ID_HEAD = [1, 2, 3]
ID_ARM_L = [11, 12, 13, 14, 15, 16, 17]
ID_ARM_R = [21, 22, 23, 24, 25, 26, 27]
ID_WAIST = [31]
ID_LEG_L = [51, 52, 53, 54, 55, 56]
ID_LEG_R = [61, 62, 63, 64, 65, 66]

HAND_L_MAP = {
    1: "left_little_1_joint",
    2: "left_ring_1_joint",
    3: "left_middle_1_joint",
    4: "left_index_1_joint",
    5: "left_thumb_2_joint",
    6: "left_thumb_1_joint",
}

HAND_R_MAP = {
    1: "right_little_1_joint",
    2: "right_ring_1_joint",
    3: "right_middle_1_joint",
    4: "right_index_1_joint",
    5: "right_thumb_2_joint",
    6: "right_thumb_1_joint",
}

ARM_HOME_DEFAULT = [
    -0.152, 0.067, 0.135, -1.155, 0.124, -0.361, -0.005,
    -0.291, -0.003, -0.136, -0.868, -0.287, -0.448, 0.194,
]

ARM_HOME_PICK_PLACE = [
    -0.152, 0.068, 0.135, -1.155, 0.124, -0.361, -0.006,
    -0.291, -0.003, -0.136, -1.155, -0.124, -0.361, 0.194,
]

HAND_OPEN = [1, 1, 1, 1, 1, 1]
HAND_CLOSE = [0.3, 0.3, 0.3, 0.3, 0.3, 0]

DEFAULT_MOTOR_SPEED = 0.2
DEFAULT_MOTOR_CURRENT = 5.0
CONTROL_LOOP_HZ = 15

RIGHT_ARM_JOINTS = [
    "shoulder_pitch_r_joint",
    "shoulder_roll_r_joint",
    "shoulder_yaw_r_joint",
    "elbow_pitch_r_joint",
    "elbow_yaw_r_joint",
    "wrist_pitch_r_joint",
    "wrist_roll_r_joint",
]
