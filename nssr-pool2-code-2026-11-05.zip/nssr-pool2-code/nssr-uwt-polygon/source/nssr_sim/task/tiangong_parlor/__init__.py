# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
import gymnasium as gym

gym.register(
    id="NSSRSim-TiangongPro-Parlor-v0",
    entry_point="nssr_sim.env:ManagerBasedRLDigitalTwinEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.tiangong_parlor_env_cfg:TiangongParlorEnvCfg",
    },
)
