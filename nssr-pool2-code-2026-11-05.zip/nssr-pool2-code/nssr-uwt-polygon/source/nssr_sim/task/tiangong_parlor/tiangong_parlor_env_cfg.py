# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
from pxr import Usd, UsdGeom, Gf, Sdf
import isaaclab.sim as sim_utils
from isaaclab.assets import AssetBaseCfg, ArticulationCfg
from isaaclab.managers import SceneEntityCfg, ObservationGroupCfg
from isaaclab.sensors import TiledCameraCfg
from isaaclab.utils import configclass
import isaaclab.envs.mdp as mdp
from isaaclab.envs import ViewerCfg
from isaaclab.actuators import ImplicitActuatorCfg

from isaaclab.scene import InteractiveSceneCfg
from nssr_sim.devices.tiangong_pro.config import (
    TIANGONG_PRO_CFG,
    TIANGONG_PRO_HOME_POSE,
    TIANGONG_PRO_LEFT_ARM_JOINTS,
    TIANGONG_PRO_RIGHT_ARM_JOINTS,
    TIANGONG_PRO_LEFT_HAND_JOINTS,
    TIANGONG_PRO_RIGHT_HAND_JOINTS,
    TIANGONG_PRO_HEAD_JOINTS,
    TIANGONG_PRO_WAIST_JOINTS,
    TIANGONG_PRO_LEFT_LEG_JOINTS,
    TIANGONG_PRO_RIGHT_LEG_JOINTS,
    TIANGONG_PRO_USD_PATH,
)
from nssr_sim.utils.config_loader import load_config, resolve_asset_path
from nssr_sim.env.digital_twin_env_cfg import (
    ManagerBasedRLDigitalTwinEnvCfg,
)

_TASK_CFG = load_config("tiangong_parlor.yaml")
_SCENE_USD_PATH = resolve_asset_path(_TASK_CFG["scene"]["usd_path"])

PARLOR_SCENE_CFG = AssetBaseCfg(
    spawn=sim_utils.UsdFileCfg(usd_path=_SCENE_USD_PATH),
)


import os as _os
_CAM_W = int(_os.environ.get("HACK_CAM_W", "640"))
_CAM_H = int(_os.environ.get("HACK_CAM_H", "360"))
_RENDER_INTERVAL = int(_os.environ.get("HACK_RENDER_INTERVAL", "6"))
_CAM_HZ = float(_os.environ.get("HACK_CAM_HZ", str(1.0 / (0.01 * _RENDER_INTERVAL))))
_CAM_HAP = float(_os.environ.get("HACK_CAM_HAPERTURE", "44.76"))
_CAM_VAP = _CAM_HAP * _CAM_H / _CAM_W


def _find_torso_parent():
    env = _os.environ.get("HACK_TORSO_PARENT")
    if env:
        print(f"[hack] torso camera parent (env): {env}", flush=True)
        return env
    try:
        stage = Usd.Stage.Open(str(TIANGONG_PRO_USD_PATH.resolve()))
        root = stage.GetDefaultPrim()
        base = str(root.GetPath())
        names = {}
        for p in Usd.PrimRange(root):
            names.setdefault(p.GetName(), str(p.GetPath())[len(base) + 1:])
        links = sorted(n for n in names if n.endswith("_link") or n in ("pelvis", "humanoid"))
        print(f"[hack] robot USD default prim {base}; links: {links}", flush=True)
        for cand in ("waist_yaw_link", "body_yaw_link", "waist_link", "torso_link", "body_link"):
            if cand in names:
                print(f"[hack] torso camera parent: {names[cand]}", flush=True)
                return names[cand]
        for n, rel in names.items():
            if "waist" in n.lower() or "body_yaw" in n.lower():
                print(f"[hack] torso camera parent (fuzzy): {rel}", flush=True)
                return rel
    except Exception as e:
        print(f"[hack] torso prim autodetect failed: {e}", flush=True)
    print("[hack] torso camera parent: fallback humanoid/waist_yaw_link", flush=True)
    return "humanoid/waist_yaw_link"


_TORSO_PARENT = _find_torso_parent()
_TORSO_DEPTH = _os.environ.get("HACK_TORSO_DEPTH", "1") == "1"


def _hack_camera(prim_path, pos, rot, depth=True):
    cfg = TiledCameraCfg(
        prim_path=prim_path,
        offset=TiledCameraCfg.OffsetCfg(pos=pos, rot=rot, convention="ros"),
        update_period=max(0.0, 1.0 / _CAM_HZ - 1e-3),
        height=_CAM_H,
        width=_CAM_W,
        data_types=["rgb", "distance_to_image_plane"] if depth else ["rgb"],
        spawn=sim_utils.PinholeCameraCfg(
            focal_length=24.0,
            focus_distance=400.0,
            horizontal_aperture=_CAM_HAP,
            vertical_aperture=_CAM_VAP,
            clipping_range=(0.05, 20.0),
        ),
    )
    if hasattr(cfg, "update_latest_camera_pose"):
        cfg.update_latest_camera_pose = True
    return cfg


@configclass
class TiangongParlorSceneCfg(InteractiveSceneCfg):
    scene = PARLOR_SCENE_CFG.replace(prim_path="{ENV_REGEX_NS}/Scene")
    robot = TIANGONG_PRO_CFG.replace(
        prim_path="{ENV_REGEX_NS}/Robot",
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(7.80, 6.08257, 0.02),
            rot=(0.99939, 0.0, 0.0349, 0.0),
            joint_pos=TIANGONG_PRO_HOME_POSE
        )
    )

    light = AssetBaseCfg(
        prim_path="{ENV_REGEX_NS}/Light",
        spawn=sim_utils.DomeLightCfg(color=(0.9, 0.9, 0.9), intensity=1000.0),
    )

    cam_head = _hack_camera(
        "{ENV_REGEX_NS}/Robot/humanoid/head_roll_link/cam_head",
        pos=(0.075191, 0.010935, 0.074436),
        rot=(0.430457, -0.560985, 0.560987, -0.430459),
    )
    cam_torso = _hack_camera(
        "{ENV_REGEX_NS}/Robot/" + _TORSO_PARENT + "/cam_torso",
        pos=(0.090583, 0.02375, 0.039012),
        rot=(0.337388, -0.621424, 0.621426, -0.337389),
        depth=_TORSO_DEPTH,
    )

@configclass
class ActionsCfg:

    left_arm_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_LEFT_ARM_JOINTS,
        scale=1.0,
    )
    right_arm_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_RIGHT_ARM_JOINTS,
        scale=1.0,
    )

    left_hand_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_LEFT_HAND_JOINTS,
        scale=1.0,
    )
    right_hand_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_RIGHT_HAND_JOINTS,
        scale=1.0,
    )

    head_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_HEAD_JOINTS,
        scale=1.0,
    )
    waist_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_WAIST_JOINTS,
        scale=1.0,
    )

    left_leg_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_LEFT_LEG_JOINTS,
        scale=1.0,
    )
    right_leg_action = mdp.JointPositionActionCfg(
        asset_name="robot",
        joint_names=TIANGONG_PRO_RIGHT_LEG_JOINTS,
        scale=1.0,
    )


@configclass
class ObservationsCfg:
    @configclass
    class PolicyCfg(ObservationGroupCfg):
        joint_pos = mdp.ObservationTermCfg(
            func=mdp.joint_pos_rel,
            params={"asset_cfg": SceneEntityCfg("robot")},
        )
        joint_vel = mdp.ObservationTermCfg(
            func=mdp.joint_vel_rel,
            params={"asset_cfg": SceneEntityCfg("robot")},
        )
        def __post_init__(self):
            self.enable_corruption = False
            self.concatenate_terms = True

    policy: PolicyCfg = PolicyCfg()

@configclass
class EventCfg:
    pass


@configclass
class RewardsCfg:
    pass


@configclass
class TerminationsCfg:
    pass


@configclass
class TiangongParlorEnvCfg(ManagerBasedRLDigitalTwinEnvCfg):
    scene: TiangongParlorSceneCfg = TiangongParlorSceneCfg(num_envs=1, env_spacing=5.0)

    viewer = ViewerCfg(eye=(5.5, 6.0, 2.0), lookat=(7.9, 6.08, 1.0))

    actions: ActionsCfg = ActionsCfg()
    observations: ObservationsCfg = ObservationsCfg()
    events: EventCfg = EventCfg()
    rewards: RewardsCfg = RewardsCfg()
    terminations: TerminationsCfg = TerminationsCfg()

    episode_length_s = 1000.0
    dynamic_reset_gripper_effort_limit = False

    def __post_init__(self):
        super().__post_init__()
        self.sim.use_fabric = True
        self.sim.enable_scene_query_support = False


        self.sim.disable_contact_processing = True

        self.sim.dt = 0.01
        self.decimation = 1

        self.sim.render_interval = _RENDER_INTERVAL

        import sys as _sys, pathlib as _pl
        _hack = str(_pl.Path(__file__).resolve().parents[4] / "hackathon")
        if _hack not in _sys.path:
            _sys.path.insert(0, _hack)
        from hack_sim import scene as _hack_scene
        _hack_scene.apply(self)


    def use_teleop_device(self, teleop_device: str) -> None:
        self.task_type = teleop_device
        from nssr_sim.devices.action_process import init_action_cfg
        self.actions = init_action_cfg(self.actions, device=teleop_device)

    def preprocess_device_action(self, action, teleop_device):
        from nssr_sim.devices.action_process import preprocess_device_action
        return preprocess_device_action(action, teleop_device)
