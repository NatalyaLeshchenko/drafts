# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
def patch_termination_manager():
    import torch
    from isaaclab.managers import TerminationManager

    def compute(self) -> torch.Tensor:
        self._truncated_buf[:] = False
        self._terminated_buf[:] = False
        for i, term_cfg in enumerate(self._term_cfgs):
            value = term_cfg.func(self._env, **term_cfg.params)
            if term_cfg.time_out:
                self._truncated_buf |= value
            else:
                self._terminated_buf |= value
            self._term_dones[:, i] = value
            rows = value.nonzero(as_tuple=True)[0]
            if rows.numel() > 0:
                self._term_dones[rows] = False
                self._term_dones[rows, i] = True
        return self._truncated_buf | self._terminated_buf

    TerminationManager.compute = compute


_applied = False


def monkey_patch():
    global _applied
    if _applied:
        return
    _applied = True
    patch_termination_manager()
