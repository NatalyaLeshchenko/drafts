# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
import os
from pathlib import Path


def _detect_project_root() -> Path:
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / "assets").is_dir() and (parent / "source").is_dir():
            return parent
    return Path(__file__).resolve().parents[3]


def _resolve_assets_root() -> str:
    env_root = os.environ.get("NSSR_SIM_ASSETS_ROOT")
    if env_root:
        return Path(env_root).expanduser().resolve().as_posix()

    return (_detect_project_root() / "assets").resolve().as_posix()


ASSETS_ROOT = _resolve_assets_root()
