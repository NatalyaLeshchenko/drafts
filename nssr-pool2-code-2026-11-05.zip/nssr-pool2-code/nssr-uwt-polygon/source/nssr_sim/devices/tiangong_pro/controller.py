# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
from typing import Any
import time
import torch
import json
import numpy as np
import cv2
import os
import omni.usd
from pxr import Gf, UsdGeom, Usd
try:
    from isaacsim.core.prims import RigidPrim
except ImportError:
    try:
        from omni.isaac.core.prims import RigidPrim
    except ImportError:
        RigidPrim = None

from ..device_base import DeviceBase
from .action_process import to_controller_data, to_ros_data

try:
    import zmq
    HAS_ZMQ = True
except ImportError:
    HAS_ZMQ = False

class TiangongProController(DeviceBase):
    def __init__(self, env, **kwargs):
        super().__init__()
        self.env = env
        self.device = env.device
        self._last_camera_send_time = -1.0
        
        self._last_depth_send_time = -1.0
        self._action = {}
        self.apple_initial_pos = None
        self.reset_requested = False
        
        self.apple_prim = self._init_prim("/World/envs/env_0/Scene/apple", rigid=True)
        self.plate_prim = self._init_prim("/World/envs/env_0/Scene/plate", rigid=False)

        if HAS_ZMQ:
            self.context = zmq.Context()
            self.sub_socket = self.context.socket(zmq.SUB)
            self.sub_socket.connect("tcp://127.0.0.1:5555")
            self.sub_socket.setsockopt_string(zmq.SUBSCRIBE, "")
            self.sub_socket.connect("tcp://127.0.0.1:5558")
            
            self.pub_socket = self.context.socket(zmq.PUB)
            self.pub_socket.setsockopt(zmq.SNDHWM, 1)
            self.pub_socket.bind("tcp://*:5556")

            self.img_socket = self.context.socket(zmq.PUB)
            self.img_socket.setsockopt(zmq.SNDHWM, 4)
            self.img_socket.bind("tcp://*:5557")
            
            print("[INFO] ZMQ Subscriber connected to tcp://127.0.0.1:5555")
            print("[INFO] ZMQ Publisher bound to tcp://*:5556")
            print("[INFO] ZMQ Image Publisher bound to tcp://*:5557")
        else:
            print("[WARNING] zmq not found. ZMQ control will not be available.")

    def __str__(self) -> str:
        return "Tiangong Pro ZMQ Controller"

    def _init_prim(self, prim_path, rigid=True):
        if not RigidPrim and rigid:
            print("[WARNING] RigidPrim class not available (isaacsim/omni.isaac.core not found)")
            rigid = False
            
        try:
            stage = omni.usd.get_context().get_stage()
            if stage:
                prim = stage.GetPrimAtPath(prim_path)
                if prim.IsValid():
                    if not rigid:
                        print(f"[INFO] Prim (read-only) initialized: {prim_path}")
                        return prim

                    try:
                        try:
                            rp = RigidPrim(prim_path)
                        except TypeError:
                            rp = RigidPrim(prim_path=prim_path)
                        rp.initialize()
                        print(f"[INFO] RigidPrim initialized: {prim_path}")
                        return rp
                    except Exception as e:
                        print(f"[WARNING] Failed to initialize RigidPrim for {prim_path}: {e}. Returning raw Prim.")
                        return prim
                else:
                    print(f"[WARNING] Prim not found at {prim_path}")
        except Exception as e:
            print(f"[WARNING] Could not initialize RigidPrim {prim_path}: {e}")
        return None

    def reset(self):
        self._action = {}
        self.apple_initial_pos = None
        self.reset_requested = False

    def reset_to_pose(self, pose_dict: dict[str, float]):
        self._action = pose_dict.copy()

    def add_callback(self, key, func):
        pass

    def _get_status_from_sim(self) -> dict:
        
        return to_ros_data(self.env)

    _HACK_CAMS = ("cam_head", "cam_torso")
    _DEPTH_MIN = float(os.environ.get("HACK_DEPTH_MIN", "0.15"))
    _DEPTH_MAX = float(os.environ.get("HACK_DEPTH_MAX", "6.0"))

    def _sim_time(self) -> float:
        t = getattr(self.env.sim, "current_time", None)
        if t is None:
            t = float(self.env.common_step_counter) * float(self.env.step_dt)
        return float(t)

    _CAM_COLORS = {"cam_head": (0.1, 0.9, 1.0, 1.0), "cam_torso": (1.0, 0.2, 0.8, 1.0)}

    def _init_depth_windows(self):
        self._depth_win = {}
        if os.environ.get("HACK_DEPTH_WINDOWS", "0") != "1":
            return
        try:
            import omni.ui as ui
            for name in self._HACK_CAMS:
                if name not in self.env.scene.keys():
                    continue
                win = ui.Window(f"{name} depth", width=660, height=420)
                prov = ui.ByteImageProvider()
                with win.frame:
                    try:
                        ui.ImageWithProvider(prov, fill_policy=ui.IwpFillPolicy.IWP_PRESERVE_ASPECT_FIT)
                    except Exception:
                        ui.ImageWithProvider(prov)
                self._depth_win[name] = (win, prov)
            print(f"[hack] depth windows ON: {list(self._depth_win)}", flush=True)
        except Exception as e:
            print(f"[hack] depth windows unavailable: {e}", flush=True)

    def _show_depth(self, name, dm_mm):
        try:
            _, prov = self._depth_win[name]
            maxmm = float(os.environ.get("HACK_DEPTH_VIS_MAX", "2.5")) * 1000.0
            vis = cv2.applyColorMap(np.clip(dm_mm / maxmm * 255.0, 0, 255).astype(np.uint8), cv2.COLORMAP_TURBO)
            vis[dm_mm <= 0] = 0
            rgba = np.ascontiguousarray(cv2.cvtColor(vis, cv2.COLOR_BGR2RGBA))
            h, w = rgba.shape[:2]
            if hasattr(prov, "set_data_array"):
                prov.set_data_array(rgba, [w, h])
            else:
                prov.set_bytes_data(rgba.reshape(-1).tolist(), [w, h])
        except Exception as e:
            print(f"[hack] depth window {name} failed: {e}", flush=True)
            self._depth_win.pop(name, None)

    def _init_viewports(self):
        if os.environ.get("HACK_CAM_VIEWPORTS", "0") != "1":
            return
        try:
            import re
            from omni.kit.viewport.utility import create_viewport_window
            x = 40
            for name in self._HACK_CAMS:
                if name not in self.env.scene.keys():
                    continue
                path = re.sub(r"env_\.\*", "env_0", self.env.scene[name].cfg.prim_path.replace("{ENV_REGEX_NS}", "/World/envs/env_0"))
                create_viewport_window(name, width=640, height=400, position_x=x, position_y=60,
                                       camera_path=path)
                print(f"[hack] viewport {name} -> {path}", flush=True)
                x += 660
        except Exception as e:
            print(f"[hack] camera viewports unavailable: {e}", flush=True)

    def _init_draw(self):
        self._draw, self._cloud = None, {}
        if os.environ.get("HACK_DRAW_CLOUD", "0") != "1":
            return
        try:
            from isaacsim.core.utils.extensions import enable_extension
            enable_extension("isaacsim.util.debug_draw")
            from isaacsim.util.debug_draw import _debug_draw
            self._draw = _debug_draw.acquire_debug_draw_interface()
            self._draw_stride = int(os.environ.get("HACK_DRAW_STRIDE", "6"))
            self._draw_size = float(os.environ.get("HACK_DRAW_SIZE", "4"))
            self._draw_mode = os.environ.get("HACK_DRAW_COLOR", "cam")
            print("[hack] point-cloud overlay ON", flush=True)
        except Exception as e:
            print(f"[hack] point-cloud overlay unavailable: {e}", flush=True)

    def _cam_pose_w(self, cam):
        import isaaclab.utils.math as mu
        if not hasattr(self, "_cam_parent"):
            self._cam_parent = {}
        key = cam.cfg.prim_path
        robot = self.env.scene["robot"]
        if key not in self._cam_parent:
            parent = key.rstrip("/").split("/")[-2]
            idx = robot.find_bodies(parent)[0][0]
            off_p = torch.tensor(cam.cfg.offset.pos, device=self.device, dtype=torch.float32)
            off_q = torch.tensor(cam.cfg.offset.rot, device=self.device, dtype=torch.float32)
            self._cam_parent[key] = (idx, off_p, off_q)
            print(f"[hack] camera {key.split('/')[-1]} pose from body {parent} (#{idx}), "
                  f"convention {cam.cfg.offset.convention}", flush=True)
        idx, off_p, off_q = self._cam_parent[key]
        bp = robot.data.body_pos_w[0, idx]
        bq = robot.data.body_quat_w[0, idx]
        pos = bp + mu.quat_apply(bq.unsqueeze(0), off_p.unsqueeze(0))[0]
        quat = mu.quat_mul(bq.unsqueeze(0), off_q.unsqueeze(0))[0]
        return pos, quat

    def _draw_cloud(self, name, cam, depth):
        import isaaclab.utils.math as mu
        st = self._draw_stride
        dep = depth[::st, ::st, 0] if depth.dim() == 3 else depth[::st, ::st]
        H, W = dep.shape
        K = cam.data.intrinsic_matrices[0]
        v, u = torch.meshgrid(torch.arange(H, device=dep.device) * st,
                              torch.arange(W, device=dep.device) * st, indexing="ij")
        m = torch.isfinite(dep) & (dep > self._DEPTH_MIN) & (dep < self._DEPTH_MAX)
        z = dep[m]
        x = (u[m].float() - K[0, 2]) * z / K[0, 0]
        y = (v[m].float() - K[1, 2]) * z / K[1, 1]
        pc = torch.stack([x, y, z], 1)
        pos_w, quat_w = self._cam_pose_w(cam)
        q = quat_w.unsqueeze(0).expand(pc.shape[0], 4)
        pw = mu.quat_apply(q, pc) + pos_w
        pts = [tuple(p) for p in pw.cpu().numpy().tolist()]
        if self._draw_mode == "rgb":
            rgb = cam.data.output["rgb"][0, ::st, ::st, :3][m].float() / 255.0
            cols = [tuple(c) + (1.0,) for c in rgb.cpu().numpy().tolist()]
        else:
            cols = [self._CAM_COLORS.get(name, (1.0, 1.0, 0.0, 1.0))] * len(pts)
        self._cloud[name] = (pts, cols)
        self._draw.clear_points()
        for p, c in self._cloud.values():
            if p:
                self._draw.draw_points(p, c, [self._draw_size] * len(p))

    def _send_camera_data(self):
        if not hasattr(self, "_cam_last"):
            self._cam_last = {}
            self._init_draw()
            self._init_viewports()
            self._init_depth_windows()
            if os.environ.get("HACK_CAM_HZ"):
                self._cam_period = 1.0 / float(os.environ["HACK_CAM_HZ"])
            else:
                self._cam_period = float(self.env.cfg.sim.render_interval) * float(self.env.cfg.sim.dt)
            print(f"[hack] camera period {self._cam_period:.4f} s sim, render_interval "
                  f"{self.env.cfg.sim.render_interval}", flush=True)
        now = self._sim_time()
        keys = self.env.scene.keys()
        for name in self._HACK_CAMS:
            if name not in keys:
                continue
            last = self._cam_last.get(name, -1e9)
            if now < last:
                last = -1e9
            if now - last < self._cam_period - 1e-3:
                continue
            cam = self.env.scene[name]
            out = cam.data.output
            if out is None or "rgb" not in out or out["rgb"].shape[0] == 0:
                continue
            rgb = out["rgb"][0, ..., :3].contiguous().cpu().numpy()
            depth_bytes = b""
            d = out.get("distance_to_image_plane")
            if d is not None and d.shape[0] != 0:
                dm = d[0].squeeze(-1).cpu().numpy()
                bad = ~np.isfinite(dm) | (dm < self._DEPTH_MIN) | (dm > self._DEPTH_MAX)
                dm = np.where(bad, 0.0, dm * 1000.0)
                if getattr(self, "_depth_win", None) and name in self._depth_win:
                    self._show_depth(name, dm)
                depth_bytes = dm.astype(np.uint16).tobytes()
            if self._draw is not None and d is not None and d.shape[0] != 0:
                try:
                    self._draw_cloud(name, cam, d[0])
                except Exception as e:
                    print(f"[hack] draw cloud failed: {e}", flush=True)
                    self._draw = None
            K = cam.data.intrinsic_matrices[0].cpu().numpy().reshape(-1).tolist()
            meta = {"name": name, "width": int(rgb.shape[1]), "height": int(rgb.shape[0]),
                    "stamp": now, "K": K, "has_depth": bool(depth_bytes)}
            try:
                self.img_socket.send_json(meta, flags=zmq.SNDMORE | zmq.NOBLOCK)
                self.img_socket.send(rgb.tobytes(), flags=zmq.SNDMORE | zmq.NOBLOCK)
                self.img_socket.send(depth_bytes, flags=zmq.NOBLOCK)
                self._cam_last[name] = now
            except zmq.Again:
                pass

    def _get_prim_pose(self, prim_obj):
        current_pos = None
        current_rot = None
        
        if hasattr(prim_obj, "get_world_pose"):
            current_pos, current_rot = prim_obj.get_world_pose()
        
        elif hasattr(prim_obj, "get_world_poses"):
                positions, orientations = prim_obj.get_world_poses()
                if len(positions) > 0:
                    current_pos = positions[0] 
                    current_rot = orientations[0]
                    if isinstance(current_pos, torch.Tensor):
                        current_pos = current_pos.cpu().numpy()
                    if isinstance(current_rot, torch.Tensor):
                        current_rot = current_rot.cpu().numpy()

        else:
            prim = getattr(prim_obj, "prim", None)
            if prim is None:
                prims = getattr(prim_obj, "prims", [])
                if len(prims) > 0:
                    prim = prims[0]
            
            if prim is None and isinstance(prim_obj, Usd.Prim):
                prim = prim_obj
            
            if prim:
                xform = UsdGeom.Xformable(prim)
                world_transform = xform.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
                translation = world_transform.ExtractTranslation()
                rotation = world_transform.ExtractRotation().GetQuat()
                current_pos = [translation[0], translation[1], translation[2]]
                current_rot = np.array([rotation.GetReal(), rotation.GetImaginary()[0], rotation.GetImaginary()[1], rotation.GetImaginary()[2]])
        
        return current_pos, current_rot

    def _set_prim_pose(self, prim_obj, pos, rot=None):
        if hasattr(prim_obj, "set_world_pose"):
            prim_obj.set_world_pose(position=pos, orientation=rot)
            if hasattr(prim_obj, "set_velocities"):
                zero_vel = np.zeros(6)
                prim_obj.set_velocities(zero_vel)
        elif hasattr(prim_obj, "set_world_poses"):
            device = prim_obj._device if hasattr(prim_obj, "_device") else "cuda:0"
            pos_tensor = torch.tensor([pos], dtype=torch.float32, device=device)
            rot_tensor = torch.tensor([rot], dtype=torch.float32, device=device) if rot is not None else None
            prim_obj.set_world_poses(positions=pos_tensor, orientations=rot_tensor)
            if hasattr(prim_obj, "set_velocities"):
                vel_tensor = torch.zeros((1, 6), dtype=torch.float32, device=device)
                prim_obj.set_velocities(vel_tensor)

    def _apply_apple_offset(self):
        if not self.apple_prim or "apple_offset" not in self._action:
            return

        try:
            offset = self._action["apple_offset"]
            self._action.pop("apple_offset")
            
            if not (offset[0]==0 and offset[1]==0): 
                current_pos, current_rot = self._get_prim_pose(self.apple_prim)
                
                if current_pos is None:
                    current_pos = [0, 0, 0.8]
                    current_rot = [1, 0, 0, 0]

                try:
                    z_val = current_pos[2]
                except:
                    z_val = 0.8
                
                if z_val < 0.1:
                    print(f"[WARNING] Apple Z is {z_val:.3f}, resetting to default table height 0.8")
                    z_val = 0.8

                if self.apple_initial_pos is None:
                        if current_pos is not None:
                            self.apple_initial_pos = np.array(current_pos) if not isinstance(current_pos, np.ndarray) else current_pos
                            print(f"[INFO] Apple Initial Position Captured: {self.apple_initial_pos}")

                if self.apple_initial_pos is not None:
                        base_x = self.apple_initial_pos[0]
                        base_y = self.apple_initial_pos[1]
                else:
                        base_x = 0.0
                        base_y = 0.0

                new_pos = np.array([base_x + float(offset[0]), base_y + float(offset[1]), z_val])
                
                self._set_prim_pose(self.apple_prim, new_pos, current_rot)
                
                print(f"[INFO] Applied apple offset: {offset} (Pos: {new_pos})")
        except Exception as e:
            print(f"[WARNING] move error apple: {e}")
            import traceback
            traceback.print_exc()

    def _get_apple_plate_dist(self):
        if not self.apple_prim or not self.plate_prim:
            return -1.0
        
        try:
            apple_pos, _ = self._get_prim_pose(self.apple_prim)
            plate_pos, _ = self._get_prim_pose(self.plate_prim)
            
            if apple_pos is not None and plate_pos is not None:
                dist = np.linalg.norm(np.array(apple_pos) - np.array(plate_pos))
                return float(dist)
        except Exception:
            pass
        return -1.0

    def advance(self) -> dict[str, Any]:
        if HAS_ZMQ:
            while True:
                try:
                    msg = self.sub_socket.recv_json(flags=zmq.NOBLOCK)
                    self._action.update(msg)
                except zmq.Again:
                    break
            
            if "reset" in self._action:
                if self._action.pop("reset"):
                    self.reset_requested = True

            if not hasattr(self, "_hack_rt"):
                self._hack_rt = None
                try:
                    import sys as _sys, pathlib as _pl
                    _h = str(_pl.Path(__file__).resolve().parents[4] / "hackathon")
                    if _h not in _sys.path:
                        _sys.path.insert(0, _h)
                    from hack_sim import objects as _ho
                    if [k for k in _ho.STATE if not k.startswith("_")]:
                        self._hack_rt = _ho.Runtime(self.env)
                except Exception as _e:
                    print(f"[hack] objects runtime off: {_e}", flush=True)
            if self._hack_rt is not None:
                self._hack_rt.handle(self._action, self.reset_requested)

            self._apply_apple_offset()
            
            dist = self._get_apple_plate_dist()

            try:
                status = self._get_status_from_sim()
                status["task_dist"] = dist
                status["sim_time"] = self._sim_time()
                if getattr(self, "_hack_rt", None) is not None:
                    status.update(self._hack_rt.status())
                self.pub_socket.send_json(status, flags=zmq.NOBLOCK)
            except Exception:
                pass
            try:
                self._send_camera_data()
            except Exception:
                pass

        return {"tiangong_pro": to_controller_data(self._action,self.env)}

    def display_controls(self):
        if HAS_ZMQ:
            print("Tiangong Pro Controller: Full ROS Interface enabled via ZMQ Bridge")
            print("  - Command Sub: tcp://127.0.0.1:5555")
            print("  - Status Pub:  tcp://127.0.0.1:5556")
