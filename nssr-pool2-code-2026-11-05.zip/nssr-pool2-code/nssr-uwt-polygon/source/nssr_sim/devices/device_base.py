# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#
# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.


from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any


class DeviceBase(ABC):

    def __init__(self):
        pass

    def __str__(self) -> str:
        return f"{self.__class__.__name__}"

    @abstractmethod
    def reset(self):
        raise NotImplementedError

    @abstractmethod
    def add_callback(self, key: Any, func: Callable):
        raise NotImplementedError

    @abstractmethod
    def advance(self) -> Any:
        raise NotImplementedError
