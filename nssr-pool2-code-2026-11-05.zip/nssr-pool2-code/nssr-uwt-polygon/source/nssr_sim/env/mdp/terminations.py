# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
import torch
from isaaclab.assets import RigidObject
from isaaclab.envs import DirectRLEnv, ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg


def object_in_container(
    env: ManagerBasedRLEnv | DirectRLEnv,
    object_cfg: SceneEntityCfg,
    container_cfg: SceneEntityCfg,
    x_range: tuple[float, float] = (-0.05, 0.05),
    y_range: tuple[float, float] = (-0.05, 0.05),
    height_threshold: float = 0.05,
) -> torch.Tensor:

    done = torch.ones(env.num_envs, dtype=torch.bool, device=env.device)

    container: RigidObject = env.scene[container_cfg.name]
    container_x = container.data.root_pos_w[:, 0] - env.scene.env_origins[:, 0]
    container_y = container.data.root_pos_w[:, 1] - env.scene.env_origins[:, 1]

    object: RigidObject = env.scene[object_cfg.name]
    object_x = object.data.root_pos_w[:, 0] - env.scene.env_origins[:, 0]
    object_y = object.data.root_pos_w[:, 1] - env.scene.env_origins[:, 1]
    object_z = object.data.root_pos_w[:, 2] - env.scene.env_origins[:, 2]

    done = torch.logical_and(done, object_x < container_x + x_range[1])
    done = torch.logical_and(done, object_x > container_x + x_range[0])
    done = torch.logical_and(done, object_y < container_y + y_range[1])
    done = torch.logical_and(done, object_y > container_y + y_range[0])
    done = torch.logical_and(done, object_z < height_threshold)

    return done
