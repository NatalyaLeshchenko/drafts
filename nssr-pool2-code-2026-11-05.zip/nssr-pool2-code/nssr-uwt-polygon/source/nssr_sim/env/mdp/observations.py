# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
import isaaclab.utils.math as math_utils
import torch
from isaaclab.assets import Articulation
from isaaclab.envs import ManagerBasedEnv, ManagerBasedRLEnv
from isaaclab.envs.mdp.observations import image
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import FrameTransformer


def overlay_image(
    env: ManagerBasedEnv,
    sensor_cfg: SceneEntityCfg = SceneEntityCfg("tiled_camera"),
    data_type: str = "rgb",
    convert_perspective_to_orthogonal: bool = False,
    normalize: bool = True,
) -> torch.Tensor:
    assert data_type == "rgb", "Only 'rgb' is supported for overlay_image."

    sim_image = image(env, sensor_cfg, data_type, convert_perspective_to_orthogonal, normalize)

    def image_overlapping(
        back_image: torch.Tensor,
        fore_image: torch.Tensor,
        back_mask: torch.Tensor | None = None,
        fore_mask: torch.Tensor | None = None,
        back_alpha: float = 0.5,
        fore_alpha: float = 0.5,
    ) -> torch.Tensor:
        if back_mask is None:
            back_mask = torch.ones_like(back_image[:, :, :, 0], dtype=torch.bool, device=back_image.device)
            back_mask = back_mask.unsqueeze(-1)
        if fore_mask is None:
            fore_mask = torch.ones_like(fore_image[:, :, :, 0], dtype=torch.bool, device=fore_image.device)
            fore_mask = fore_mask.unsqueeze(-1)
        image = back_alpha * back_image * back_mask + fore_alpha * fore_image * fore_mask
        return torch.clamp(image, 0.0, 255.0).to(torch.uint8)

    semantic_id = env.foreground_semantic_id_mapping.get(sensor_cfg.name)
    if semantic_id is not None:
        camera_output = env.scene.sensors[sensor_cfg.name].data.output
        if env.cfg.rgb_overlay_mode == "background":
            semantic_mask = camera_output["semantic_segmentation"]
            overlay_mask = semantic_mask == semantic_id
            sim_image = image_overlapping(
                back_image=env.rgb_overlay_images[sensor_cfg.name],
                fore_image=sim_image,
                back_mask=torch.logical_not(overlay_mask),
                fore_mask=overlay_mask,
                back_alpha=1.0,
                fore_alpha=1.0,
            )
        elif env.cfg.rgb_overlay_mode == "debug":
            sim_image = image_overlapping(
                back_image=env.rgb_overlay_images[sensor_cfg.name],
                fore_image=sim_image,
                back_alpha=0.5,
                fore_alpha=0.5,
            )

    return sim_image


def ee_frame_state(
    env: ManagerBasedRLEnv,
    ee_frame_cfg: SceneEntityCfg = SceneEntityCfg("ee_frame"),
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    robot = env.scene[robot_cfg.name]
    robot_root_pos, robot_root_quat = robot.data.root_pos_w, robot.data.root_quat_w
    ee_frame: FrameTransformer = env.scene[ee_frame_cfg.name]
    ee_frame_pos, ee_frame_quat = ee_frame.data.target_pos_w[:, 0, :], ee_frame.data.target_quat_w[:, 0, :]
    ee_frame_pos_robot, ee_frame_quat_robot = math_utils.subtract_frame_transforms(
        robot_root_pos, robot_root_quat, ee_frame_pos, ee_frame_quat
    )
    ee_frame_state = torch.cat([ee_frame_pos_robot, ee_frame_quat_robot], dim=1)

    return ee_frame_state


def joint_pos_target(env: ManagerBasedEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    asset: Articulation = env.scene[asset_cfg.name]
    return asset.data.joint_pos_target[:, asset_cfg.joint_ids]
