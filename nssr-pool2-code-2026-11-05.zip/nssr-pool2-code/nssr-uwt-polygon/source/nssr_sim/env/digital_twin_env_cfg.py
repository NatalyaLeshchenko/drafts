# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
from typing import Literal

from isaaclab.envs.manager_based_rl_env_cfg import ManagerBasedRLEnvCfg
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils import configclass


@configclass
class ManagerBasedRLDigitalTwinEnvCfg(ManagerBasedRLEnvCfg):

    rgb_overlay_paths: dict[str, str] | None = None

    rgb_overlay_mode: Literal["none", "debug", "background"] | None = "none"

    render_objects: list[SceneEntityCfg] | None = []
