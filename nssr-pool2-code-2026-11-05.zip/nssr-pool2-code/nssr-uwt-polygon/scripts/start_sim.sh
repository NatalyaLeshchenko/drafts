#!/bin/bash
# Based on UBT Sim by UBTECH Robotics, licensed under the Apache License 2.0.
# Modified by Nikolay Semenov <nssr.nikolay@gmail.com> for the nssr-polygon simulator.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

BRIDGE_PID=""

cleanup() {
    if [ -n "$BRIDGE_PID" ]; then
        echo "[INFO] Stopping ROS2-ZMQ bridge (PID=$BRIDGE_PID)..."
        kill "$BRIDGE_PID" 2>/dev/null
        for i in 1 2 3; do
            if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then
                break
            fi
            sleep 1
        done
        if kill -0 "$BRIDGE_PID" 2>/dev/null; then
            kill -9 "$BRIDGE_PID" 2>/dev/null
        fi
        wait "$BRIDGE_PID" 2>/dev/null
    fi
    exit 0
}
trap cleanup EXIT INT TERM

if [ -z "$NSSR_SIM_NO_BRIDGE" ]; then
    if [ -f /opt/ros/humble/setup.bash ]; then
        source /opt/ros/humble/setup.bash
        export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-146}"
        /usr/bin/python3 "$PROJECT_DIR/teleoperation/bridges/ros2_zmq_bridge.py" &
        BRIDGE_PID=$!
        echo "[INFO] ROS2-ZMQ bridge started (PID=$BRIDGE_PID)"
        sleep 2
    else
        echo "[WARN] ROS2 not found in container. Skipping bridge. Set NSSR_SIM_NO_BRIDGE=1 to suppress."
    fi
fi

/isaac-sim/python.sh "$SCRIPT_DIR/sim_runner.py" \
    --task NSSRSim-TiangongPro-Parlor-v0 \
    --enable_cameras \
    --num_envs 1 \
    "$@"
