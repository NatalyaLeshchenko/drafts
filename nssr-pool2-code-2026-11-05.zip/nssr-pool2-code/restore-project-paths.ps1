$ErrorActionPreference='Stop'
$reportPath=Join-Path $PSScriptRoot 'vision\training_report.json'
$report=Get-Content -LiteralPath $reportPath -Raw | ConvertFrom-Json
$report.weights=Join-Path $PSScriptRoot 'vision\runs\pool2_yolo11n_seg\weights\best.pt'
$report.dataset=Join-Path $PSScriptRoot 'vision\dataset\data.yaml'
$report | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $reportPath -Encoding utf8
Write-Output 'Updated vision model paths. Simulator and Python dependencies must be installed separately.'
