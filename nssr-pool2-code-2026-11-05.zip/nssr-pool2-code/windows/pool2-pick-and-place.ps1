﻿param([ValidateSet('auto','marc_anthony','wilton','beta_glucan','deskstar','razer_mouse','rocksmith_cable')][string]$Object='marc_anthony',
      [ValidateSet('left','right','auto')][string]$Side='left',
      [string]$PalmRoll='0',
      [Alias('HoldingVerifiedMarc')][switch]$HoldingVerifiedObject,
      [ValidateSet('plan','raise','transfer','place')][string]$FromStage='plan',[switch]$ReuseDeliveryPlan,[switch]$AllowExperimental,[switch]$ReuseObservation,[switch]$ReusePlan)
$ErrorActionPreference='Stop'
$env:PYTHONUTF8='1'
$workspaceRoot=Split-Path $PSScriptRoot
$python=Join-Path $env:USERPROFILE 'isaac-win\Scripts\python.exe'
if ($Object -eq 'auto') {
    if ($HoldingVerifiedObject) { throw 'Automatic selection requires an empty hand.' }
    & (Join-Path $workspaceRoot 'vision\vision.ps1') -Action Observe
    if ($LASTEXITCODE -ne 0) { throw 'Fresh target observation failed.' }
    $selectionArgs=@((Join-Path $workspaceRoot 'vision\select_pool2_target.py'))
    if ($AllowExperimental) { $selectionArgs+='--allow-experimental' }
    & $python @selectionArgs
    if ($LASTEXITCODE -ne 0) { throw 'Target selection failed.' }
    $selection=Get-Content (Join-Path $workspaceRoot 'nssr-uwt-polygon\logs\pool2-next-target.json') -Raw | ConvertFrom-Json
    if (!$selection.selected) { Write-Output 'No supported unsorted target remains.'; return }
    $Object=$selection.selected.object; $Side=$selection.selected.side; $PalmRoll=$selection.selected.palm_roll
    $ReuseObservation=$true
}
function Invoke-DeliveryStage([string]$stage) {
    docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && python3 /windows-support/deliver_pool2.py $stage 2>&1"
    if ($LASTEXITCODE -ne 0) { throw "Delivery stopped at $stage; inspect feedback before restarting." }
}
if (!$HoldingVerifiedObject) {
    & (Join-Path $PSScriptRoot 'pool2-grasp.ps1') -Object $Object -Side $Side -PalmRoll $PalmRoll -ReuseObservation:$ReuseObservation -ReusePlan:$ReusePlan
    if ($LASTEXITCODE -ne 0) { throw 'Grasp failed.' }
} else {
    $logs=Join-Path $workspaceRoot 'nssr-uwt-polygon\logs'
    $verification=Join-Path $logs 'pool2-grasp-verification.json'
    $last=Get-Content -LiteralPath $verification -Raw | ConvertFrom-Json
    if (!$last.success -or $last.object -ne $Object) { throw 'No verified grasp of the requested object.' }
    foreach ($name in @('pool2-released-grip.json','pool2-delivery-released-state.json')) {
        $release=Join-Path $logs $name
        if ((Test-Path -LiteralPath $release) -and ((Get-Item -LiteralPath $release).LastWriteTime -gt (Get-Item -LiteralPath $verification).LastWriteTime)) {
            throw 'The verified object has already been released.'
        }
    }
}
if (!$ReuseDeliveryPlan) {
    & $python (Join-Path $workspaceRoot 'vision\held_payload_geometry.py')
    if ($LASTEXITCODE -ne 0) { throw 'Held object bounds could not be measured; no transfer started.' }
    docker exec nssr-ros-win bash -lc 'source /opt/ros/humble/setup.bash && python3 /windows-support/observe_tray.py'
    if ($LASTEXITCODE -ne 0) { throw 'Destination observation failed.' }
    & $python (Join-Path $workspaceRoot 'vision\localize_tray.py')
    if ($LASTEXITCODE -ne 0) { throw 'Destination was not reliably localized.' }
} else {
    $delivery=Get-Content (Join-Path $workspaceRoot 'nssr-uwt-polygon\logs\pool2-delivery-plan.json') -Raw | ConvertFrom-Json
    $grasp=Get-Content (Join-Path $workspaceRoot 'nssr-uwt-polygon\logs\pool2-grasp-plan.json') -Raw | ConvertFrom-Json
    if (!$HoldingVerifiedObject -or $delivery.planning_sim_time -ne $grasp.selected.planning_sim_time) { throw 'Delivery plan does not match the verified held object.' }
}
$stages=@('plan','raise','transfer','place','release','withdraw')
if ($FromStage -in @('transfer','place')) {
    if (!$ReuseDeliveryPlan) { throw 'Resuming requires the same delivery plan.' }
    $prior=if ($FromStage -eq 'transfer') { 'raise' } else { 'transfer' }
    $proof=Get-Content (Join-Path $workspaceRoot ('nssr-uwt-polygon\logs\pool2-carry-'+$prior+'-verification.json')) -Raw | ConvertFrom-Json
    if (!$proof.success -or $proof.planning_sim_time -ne $grasp.selected.planning_sim_time) { throw 'Prior carry stage is not verified for this plan.' }
}
foreach ($stage in $stages[[array]::IndexOf($stages,$FromStage)..($stages.Count-1)]) {
    if ($stage -eq 'plan' -and $ReuseDeliveryPlan) { continue }
    Invoke-DeliveryStage $stage
    if ($stage -in @('raise','transfer')) {
        & $python (Join-Path $workspaceRoot 'vision\verify_carry.py') $stage
        if ($LASTEXITCODE -ne 0) { throw "Carry not confirmed after $stage; stopped before proceeding." }
    }
}
& $python (Join-Path $workspaceRoot 'vision\verify_pool2_delivery.py')
if ($LASTEXITCODE -ne 0) { throw 'Delivery was not confirmed by RGB-D.' }
Invoke-DeliveryStage 'return'
docker exec nssr-ros-win bash -lc 'source /opt/ros/humble/setup.bash && python3 /windows-support/grasp_pool2.py home'
if ($LASTEXITCODE -ne 0) { throw 'Delivery completed, but empty arm failed to return home.' }
Write-Output "Automatic camera-based $Object pick and place completed."
