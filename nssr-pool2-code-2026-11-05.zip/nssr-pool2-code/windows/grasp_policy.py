"""Pure, geometry-driven grasp policy. No ROS, object poses, or object-name tuning."""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class GraspProfile:
    family: str
    mode: str
    opened: tuple
    closed: tuple
    lift_m: float = .06
    max_width_m: float = .105


def select_profile(target):
    height = float(target['height_above_observed_table_m'])
    dimensions = sorted(map(float, target['visible_footprint_dimensions_m']))
    if len(dimensions) != 2 or not all(math.isfinite(v) and v > 0 for v in [height, *dimensions]):
        raise ValueError('Invalid observed object dimensions')
    # Geometry determines posture; semantic category determines grasp material family.
    flat = height < .065 or height < .9 * dimensions[0]
    if not flat and target.get('category')=='electronics' and dimensions[0]>.065:
        return GraspProfile('upper_edge_pinch', 'top', (.8,.8,.8,.8,.95,.12),
                            (0.,0.,0.,0.,.05,.12))
    if flat:
        return GraspProfile('flat_pinch', 'top', (.4, .4, .4, .4, .95, .12),
                            (.18, .18, .18, .18, .35, .12))
    return GraspProfile('upright_enclosure', 'side', (1., 1., 1., 1., .95, .12),
                        (.18, .18, .18, .18, .35, .12))


def projected_width(dimensions, relative_angle_deg, uncertainty_deg=0):
    """Worst-case rectangular width, including extrema between sample angles."""
    small, large = sorted(dimensions)
    low, high = relative_angle_deg - uncertainty_deg, relative_angle_deg + uncertainty_deg
    peak = math.degrees(math.atan2(small, large))
    angles = [low, high]
    for turn in range(math.floor(low / 180) - 1, math.ceil(high / 180) + 2):
        for angle in (turn * 180 + peak, turn * 180 - peak):
            if low <= angle <= high:
                angles.append(angle)
    return max(large * abs(math.cos(math.radians(a))) +
               small * abs(math.sin(math.radians(a))) for a in angles)
