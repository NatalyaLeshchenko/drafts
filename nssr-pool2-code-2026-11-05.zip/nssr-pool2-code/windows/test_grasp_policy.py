"""Offline policy checks: no simulator or robot commands."""
import math
import unittest
from grasp_policy import select_profile, projected_width


class PolicyTests(unittest.TestCase):
    def test_geometry_not_name(self):
        target = dict(name='a', category='jar', height_above_observed_table_m=.15,
                      visible_footprint_dimensions_m=[.05, .06])
        first = select_profile(target)
        target['name'] = 'entirely_different'
        self.assertEqual(first, select_profile(target))
        self.assertEqual(first.mode, 'side')
        target['height_above_observed_table_m'] = .03
        self.assertEqual(select_profile(target).mode, 'top')

    def test_uncertainty_includes_peak(self):
        self.assertAlmostEqual(projected_width((.06, .1), 30, 20), math.hypot(.06, .1))
        self.assertGreater(projected_width((.06, .1), 90, 12), projected_width((.06, .1), 90))

    def test_invalid_geometry(self):
        for bad in (-1, 0, float('nan')):
            with self.assertRaises(ValueError):
                select_profile(dict(height_above_observed_table_m=bad,
                                    visible_footprint_dimensions_m=[.05, .06]))


if __name__ == '__main__':
    unittest.main()
