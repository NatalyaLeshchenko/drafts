#!/bin/bash
set -e
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=146
export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml
export PYTHONPATH="/windows-support:${PYTHONPATH:-}"
if [ -f /windows-support/.dance-fast ]; then
    export HACK_MAX_JOINT_SPEED=2.8
fi
cd /nssr_sim
exec /usr/bin/python3 teleoperation/bridges/ros2_zmq_bridge.py
