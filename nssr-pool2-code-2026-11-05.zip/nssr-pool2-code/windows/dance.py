"""A coordinated arm and leg dance through public ROS interfaces."""
import json
from pathlib import Path
import sys
import time
import xml.etree.ElementTree as ET

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from rosgraph_msgs.msg import Clock
from bodyctrl_msgs.msg import CmdSetMotorPosition, SetMotorPosition

sys.path.insert(0, '/nssr_sim/teleoperation/control')
from constants import ID_TO_NAME
from dance_choreography import prepare, sample
from leg_shuffle import LegShuffle, NEUTRAL_LEGS


def main():
    rclpy.init()
    node = Node('upper_body_dance')
    state = {}
    last_state = [0.0]
    sim_time = [None]
    clock_subscription = node.create_subscription(Clock, '/clock', lambda msg: sim_time.__setitem__(0, msg.clock.sec + msg.clock.nanosec * 1e-9), 10)
    def observe(msg):
        state.update(zip(msg.name, msg.position))
        last_state[0] = time.monotonic()
    subscription = node.create_subscription(JointState, '/joint_states', observe, 10)
    groups = {'arm': [11, 12, 14, 16, 17, 21, 22, 24, 26, 27], 'head': [1, 2, 3], 'waist': [31], 'leg': [51, 52, 53, 54, 55, 56, 61, 62, 63, 64, 65, 66]}
    default_offsets = {52: -0.5, 54: 1.0, 55: -0.5, 62: -0.5, 64: 1.0, 65: -0.5}
    publishers = {group: node.create_publisher(CmdSetMotorPosition, f'/{group}/cmd_pos', 10)
                  for group in groups}
    limits = {}
    for joint in ET.parse('/nssr_sim/assets/robots/tiangong_pro/tiangong_pro_with_hands.urdf').getroot().findall('joint'):
        limit = joint.find('limit')
        if limit is not None and 'lower' in limit.attrib:
            limits[joint.attrib['name']] = (float(limit.attrib['lower']), float(limit.attrib['upper']))
    def spin(seconds):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            rclpy.spin_once(node, timeout_sec=0.02)
    def publish(target):
        for group, ids in groups.items():
            msg = CmdSetMotorPosition()
            for motor in ids:
                low, high = limits[ID_TO_NAME[motor]]
                value = max(low + 0.03, min(high - 0.03, target[motor]))
                msg.cmds.append(SetMotorPosition(name=motor, pos=float(value - default_offsets.get(motor, 0)), spd=2.8, cur=3.0))
            publishers[group].publish(msg)
    original = None
    sim_start = None
    duration = 0.0
    extrema = {}
    foot_height_errors = {'l': 0.0, 'r': 0.0}
    initial_neutral_feet = None
    try:
        spin(3)
        ids = sum(groups.values(), [])
        if any(ID_TO_NAME[motor] not in state for motor in ids):
            raise RuntimeError('Simulator joint feedback is missing')
        original = {motor: state[ID_TO_NAME[motor]] for motor in ids}
        measured_start = dict(original)
        # Never use the previous run's measured leg bias as a new home pose.
        original.update(NEUTRAL_LEGS)
        extrema = {motor: [original[motor], original[motor]] for motor in ids}
        if sim_time[0] is None:
            raise RuntimeError('Simulator clock is missing')
        print('Returning legs to the fixed standing pose before dancing.', flush=True)
        home_start = sim_time[0]
        home_deadline = time.monotonic() + 15
        while sim_time[0] - home_start < 2.5:
            if time.monotonic() > home_deadline or time.monotonic() - last_state[0] > 2:
                raise RuntimeError('No fresh feedback during leg homing')
            u = min(1.0, (sim_time[0] - home_start) / 1.2)
            blend = u ** 3 * (10 - 15 * u + 6 * u * u)
            publish({k: measured_start[k] + blend * (original[k] - measured_start[k]) for k in ids})
            spin(0.025)
        leg_solver = LegShuffle(original, '/nssr_sim/assets/robots/tiangong_pro/tiangong_pro_with_hands.urdf')
        initial_neutral_feet = leg_solver.foot_positions({k: state[ID_TO_NAME[k]] for k in ids})
        segments = prepare(original, limits, ID_TO_NAME, speed_limit=2.5, leg_solver=leg_solver)
        planned_foot_height_error = max(abs(value)
            for i in range(501)
            for value in leg_solver.height_errors(sample(segments, sum(s[0] for s in segments) * i / 500)[0]).values())
        if planned_foot_height_error > 0.012:
            raise RuntimeError(f'Foot trajectory lifts too far: {planned_foot_height_error:.4f} m')
        duration = sum(segment[0] for segment in segments)
        print(f'Starting pose choreography: {duration:.1f} simulation seconds, smooth transitions.', flush=True)
        start = time.monotonic()
        sim_start = sim_time[0]
        last_label = None
        while (elapsed := sim_time[0] - sim_start) < duration:
            if time.monotonic() - last_state[0] > 2:
                raise RuntimeError('Simulator feedback stopped')
            if time.monotonic() - start > 90:
                raise RuntimeError('Dance timed out')
            target, label = sample(segments, elapsed)
            if label != last_label:
                print(label, flush=True)
                last_label = label
            publish(target)
            spin(0.025)
            for motor in ids:
                value = state[ID_TO_NAME[motor]]
                extrema[motor][0] = min(extrema[motor][0], value)
                extrema[motor][1] = max(extrema[motor][1], value)
            for side, value in leg_solver.height_errors({k: state[ID_TO_NAME[k]] for k in ids}).items():
                foot_height_errors[side] = max(foot_height_errors[side], abs(value))
    finally:
        if original is not None:
            for _ in range(120):
                publish(original)
                spin(0.05)
            report = {'completed': sim_start is not None and sim_time[0] - sim_start >= duration,
                      'movement_ranges_rad': {ID_TO_NAME[k]: round(v[1] - v[0], 4) for k, v in extrema.items()},
                      'return_max_error_rad': max(abs(state[ID_TO_NAME[k]] - v) for k, v in original.items())}
            report['measured_foot_height_drift_m_urdf'] = foot_height_errors
            report['neutral_leg_command_rad'] = {ID_TO_NAME[k]: v for k, v in NEUTRAL_LEGS.items()}
            if initial_neutral_feet is not None:
                final_feet = leg_solver.foot_positions({k: state[ID_TO_NAME[k]] for k in ids})
                report['neutral_feet_before_m'] = initial_neutral_feet
                report['neutral_feet_after_m'] = final_feet
                report['foot_return_distance_m'] = {
                    side: sum((a - b) ** 2 for a, b in zip(final_feet[side], initial_neutral_feet[side])) ** 0.5
                    for side in final_feet}
            Path('/nssr_sim/logs/dance-result.json').write_text(json.dumps(report, indent=2))
            with Path('/nssr_sim/logs/dance-history.jsonl').open('a') as history:
                history.write(json.dumps(report) + '\n')
            print(json.dumps(report, indent=2), flush=True)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


