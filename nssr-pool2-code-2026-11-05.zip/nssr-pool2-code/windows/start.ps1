param(
    [ValidateSet('sort2','sort3','tubes')][string]$Task = 'sort2',
    [ValidateRange(1,6)][int]$Pool = 1,
    [ValidateSet('easy','standard','color','lying')][string]$Variant = 'standard',
    [switch]$Headless,
    [switch]$DanceView
)
$ErrorActionPreference = 'Stop'
$workspace = Split-Path $PSScriptRoot
$project = Join-Path $workspace 'nssr-uwt-polygon'
$python = Join-Path $env:USERPROFILE 'isaac-win\Scripts\python.exe'
$containerName = 'nssr-ros-win'
$existing = docker ps -a --filter "name=^/$containerName`$" --format '{{.Names}}'
if ($LASTEXITCODE -ne 0) { throw 'Start Docker Desktop first.' }
if ($existing -eq $containerName) {
    docker start $containerName | Out-Null
} else {
    docker run -d --name $containerName --ipc host `
        -p 127.0.0.1:5555:5555 -p 127.0.0.1:5558:5558 `
        --mount "type=bind,source=$project,target=/nssr_sim" `
        --mount "type=bind,source=$PSScriptRoot,target=/windows-support,readonly" `
        -e NSSR_SIM_HOST=host.docker.internal `
        --entrypoint /bin/bash nssr-sim:latest `
        /windows-support/start_ros_bridge.sh | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'ROS bridge container did not start.' }
}
$env:PYTHONUTF8 = '1'
$env:OMNI_KIT_ACCEPT_EULA = 'YES'
$simArguments = @((Join-Path $PSScriptRoot 'run_sim_windows.py'), $Task, '--pool', $Pool, '--variant', $Variant)
if ($Headless) { $simArguments += '--headless' }
if ($DanceView) { $simArguments += '--dance-view' }
& $python @simArguments
exit $LASTEXITCODE
