"""Conservative point-envelope clearance against observed neighbour volumes."""
import numpy as np
from scipy.spatial import ConvexHull


def object_clearance(points, other, normal, margin=.012):
    normal=np.asarray(normal)
    center=np.asarray(other['approximate_body_center_pelvis_m'])
    yaw=np.deg2rad(other.get('yaw_deg_mod_180') or 0.)
    x=np.array([np.cos(yaw),np.sin(yaw),0.]);x-=normal*(x@normal);x/=np.linalg.norm(x)
    y=np.cross(normal,x)
    small,large=sorted(other['visible_footprint_dimensions_m'])
    if other.get('yaw_deg_mod_180') is None:small=large
    local=(np.asarray(points)-center)@np.column_stack((x,y,normal))
    excess=abs(local)-np.array([large,small,other['height_above_observed_table_m']])/2
    signed=np.linalg.norm(np.maximum(excess,0),axis=1)+np.minimum(excess.max(axis=1),0)
    return float(signed.min()-margin)


def approach_envelope(local_points, rotation, above, beside, positioned, step=.012):
    poses=[]
    for start,end in ((above,beside),(beside,positioned)):
        count=max(2,int(np.ceil(np.linalg.norm(end-start)/step))+1)
        poses.extend(np.linspace(start,end,count))
    oriented=np.asarray(local_points)@np.asarray(rotation).T
    return np.concatenate([oriented+pose for pose in poses])


def open_hand_hits_surface(hulls, rotation, above, beside, positioned, surface):
    """Check the observed target itself before closing, including other strands."""
    surface=np.asarray(surface)
    if not len(surface):return False
    poses=[]
    for start,end in ((above,beside),(beside,positioned)):
        poses.extend(np.linspace(start,end,max(2,int(np.ceil(np.linalg.norm(end-start)/.006))+1)))
    for points in hulls.values():
        points=np.asarray(points);low=points.min(0);high=points.max(0)
        equations=ConvexHull(points).equations
        for pose in poses:
            local=(surface-pose)@rotation
            near=np.all((local>low)&(local<high),axis=1)
            if not near.any():continue
            signed=(local[near]@equations[:,:3].T+equations[:,3]).max(axis=1)
            if np.any(signed<-.001):return True
    return False
