"""Fit the whole observed payload footprint, allowing a controlled stack."""
import numpy as np


def choose_placement(tray,relative_points_world):
    normal=np.array(tray['support_normal_pelvis']);x=np.array([1.,0,0])
    x-=normal*(x@normal);x/=np.linalg.norm(x);y=np.cross(normal,x)
    basis=np.column_stack((x,y,normal));points=np.asarray(relative_points_world)@basis
    low,high=np.quantile(points[:,:2],[.02,.98],axis=0)
    half=(high-low)/2;mid=(high+low)/2
    inner=np.array(tray['visible_dimensions_m'])/2-.012
    room=inner-half-.005
    if np.any(room<0):raise RuntimeError(f'Payload footprint does not fit tray: half={half}, inner={inner}')
    occupied=np.array(tray.get('occupied_points_in_plane_m',[])).reshape(-1,3)
    choices=[]
    for a in (-room[0],0.,room[0]):
        for b in (-room[1],0.,room[1]):
            slot=np.array([a,b]);overlap=np.zeros(len(occupied),bool)
            if len(occupied):overlap=np.all(abs(occupied[:,:2]-slot)<half+.008,axis=1)
            support=float(np.quantile(occupied[overlap,2],.95)) if overlap.any() else 0.
            cost=support*3+.1*np.linalg.norm(slot)+.02*float(overlap.mean() if len(overlap) else 0)
            choices.append((cost,slot,support))
    _,slot,support=min(choices,key=lambda c:c[0])
    offset=basis[:,:2]@(slot-mid)
    return offset,max(0.,support),{'footprint_dimensions_m':(half*2).tolist(),'slot_in_plane_m':slot.tolist(),'stack_support_height_m':support}
