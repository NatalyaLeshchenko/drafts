"""Inspect robot-only fingertip geometry from a recorded commanded pose."""
import json,argparse
from pathlib import Path
import numpy as np
from manipulation import Kinematics
parser=argparse.ArgumentParser();parser.add_argument('--stage',default='closed');args=parser.parse_args()
k=Kinematics();record=json.loads(Path('/nssr_sim/logs/pool2-'+args.stage+'-grip.json').read_text())
side=record['side'];joints=record['joints'];T=k.transform(side+'_tcp_link',joints);inv=np.linalg.inv(T)
parents={v[0] for v in k.parents.values()}
tips=[link for link in k.parents if link not in parents and link.startswith(side+'_') and any(s in link for s in ('thumb','index','middle','ring','little'))]
print(json.dumps({'side':side,'tips_tcp':{link:(inv@k.transform(link,joints))[:3,3].tolist() for link in tips}},indent=2))
