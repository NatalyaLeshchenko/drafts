"""Offline contact-midpoint audit of saved joint feedback."""
import json
import numpy as np
from pathlib import Path
from manipulation import Kinematics
from hand_geometry import envelopes_tcp

k=Kinematics();root=Path('/nssr_sim/logs')
for stage in ('position','closed','lift','held'):
    record=json.loads((root/f'pool2-{stage}-grip.json').read_text())
    side=record['side'];plan=record['plan'];joints=record['joints']
    envelopes=envelopes_tcp(k,side,joints)
    centers=[envelopes[k.aliases[side+'_'+finger]].mean(0) for finger in ('thumb_4','index_2')]
    tcp=np.array(record['tcp']);center=tcp[:3,:3]@np.mean(centers,axis=0)+tcp[:3,3]
    expected=np.array(plan['grip_center'])
    if stage in ('lift','held'):expected+=np.array(plan['target']['support_normal_pelvis'])*plan.get('lift_distance_m',.06)
    print(json.dumps({'stage':stage,'actual_midpoint':center.tolist(),'pad_centers_world':[(tcp[:3,:3]@v+tcp[:3,3]).tolist() for v in centers],'planned_point_error_m':(center-expected).tolist()}))
