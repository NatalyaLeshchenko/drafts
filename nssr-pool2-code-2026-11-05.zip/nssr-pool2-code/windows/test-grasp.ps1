﻿param(
    [ValidateSet('beta_glucan','marc_anthony','wilton','deskstar','razer_mouse','rocksmith_cable')]
    [string]$Object='razer_mouse',
    [switch]$ReuseObservation,
    [switch]$ReusePlan,
    [switch]$PlanOnly
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
$run=Join-Path $root ('nssr-uwt-polygon\logs\grasp-test-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $run | Out-Null
$timer=[Diagnostics.Stopwatch]::StartNew()
$status='failed'
try {
    if ($PlanOnly) {
        # Deliberately no sensor/arm commands: inspect the last saved observation.
        docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && python3 /windows-support/plan_pool2_grasp.py --object $Object --side auto" *> (Join-Path $run 'planning.log')
        if ($LASTEXITCODE -ne 0) { throw 'No feasible plan; see planning.log.' }
        $status='planned_only'
    } else {
        # Existing grasp runner enforces observation freshness and holding-object guard.
        & (Join-Path $PSScriptRoot 'pool2-grasp.ps1') -Object $Object -Side auto -PalmRoll auto -ReuseObservation:$ReuseObservation -ReusePlan:$ReusePlan *> (Join-Path $run 'execution.log')
        $status='holding_verified'
    }
} catch {
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $run 'error.txt')
} finally {
    Get-ChildItem -LiteralPath (Join-Path $root 'nssr-uwt-polygon\logs') -Filter 'pool2-*' -File |
        Copy-Item -Destination $run
    $summary=[ordered]@{object=$Object;status=$status;seconds=[math]::Round($timer.Elapsed.TotalSeconds,1);logs=$run}
    $summary | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'summary.json')
    $summary | ConvertTo-Json -Compress | Write-Output
}
if ($status -eq 'failed') { throw "Grasp test stopped; logs: $run" }
