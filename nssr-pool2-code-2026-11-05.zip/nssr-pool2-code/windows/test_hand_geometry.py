"""Robot-model regression checks, run in the ROS environment; no movement."""
import unittest
import numpy as np
from manipulation import Kinematics
from hand_geometry import BOUNDS,HULLS,flat_hand_geometry


class GeometryTests(unittest.TestCase):
    def test_collision_hulls_stay_inside_original_bounds(self):
        self.assertEqual(set(HULLS),set(BOUNDS))
        for body,points in HULLS.items():
            box=np.array(BOUNDS[body]);points=np.array(points)
            self.assertTrue(np.all(points>=box.min(0)-1e-8),body)
            self.assertTrue(np.all(points<=box.max(0)+1e-8),body)

    def test_aperture_adapts_and_rejects_oversize(self):
        k=Kinematics()
        for side in ('left','right'):
            narrow=flat_hand_geometry(k,side,{},.035)
            wider=flat_hand_geometry(k,side,{},.075)
            self.assertGreaterEqual(wider[-1],.081)
            self.assertGreater(wider[3][0],narrow[3][0])
            with self.assertRaises(ValueError):
                flat_hand_geometry(k,side,{},.20)


if __name__=='__main__':unittest.main()
