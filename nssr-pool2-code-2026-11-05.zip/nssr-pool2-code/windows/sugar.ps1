$ErrorActionPreference = 'Stop'
docker start nssr-ros-win | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Start Docker Desktop first.' }
docker exec nssr-ros-win bash -lc 'source /opt/ros/humble/setup.bash && export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml && python3 /windows-support/sugar_demo.py'
if ($LASTEXITCODE -ne 0) { throw 'Sugar demo stopped; inspect the reported stage before retrying.' }
