"""Check sensor streams and a small reversible head movement over public ROS APIs."""
import json
from pathlib import Path
import time

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from sensor_msgs.msg import Image, JointState
from std_msgs.msg import String
from bodyctrl_msgs.msg import CmdSetMotorPosition, SetMotorPosition


def main():
    rclpy.init()
    node = Node("windows_installation_check")
    joints, images, task = {}, {}, {}
    subscriptions = []
    def on_joints(msg):
        joints.update(zip(msg.name, msg.position))
    subscriptions.append(node.create_subscription(JointState, "/joint_states", on_joints, 10))
    for camera in ("head", "torso"):
        for kind in ("color", "depth"):
            key = f"{camera}_{kind}"
            subscriptions.append(node.create_subscription(
                Image, f"/cam_{camera}/{kind}/image_raw",
                lambda msg, name=key: images.__setitem__(name, msg), 2))
    qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                     reliability=ReliabilityPolicy.RELIABLE)
    subscriptions.append(node.create_subscription(
        String, "/sim/task", lambda msg: task.update(json.loads(msg.data)), qos))
    publisher = node.create_publisher(CmdSetMotorPosition, "/head/cmd_pos", 10)
    def spin(seconds):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.1)
    def move(yaw):
        message = CmdSetMotorPosition()
        message.cmds = [SetMotorPosition(name=3, pos=float(yaw), spd=0.5, cur=1.0)]
        publisher.publish(message)
    report = {}
    initial = None
    try:
        spin(4)
        initial = joints.get("head_yaw_joint")
        if initial is None:
            raise RuntimeError("No head joint state received")
        move(initial + 0.10)
        spin(3)
        moved = joints["head_yaw_joint"]
        move(initial)
        spin(3)
        report.update(task=task.get("task"), joints=len(joints),
                      head_initial=initial, head_moved=moved,
                      head_returned=joints["head_yaw_joint"],
                      head_motion_ok=abs(moved - initial) > 0.025)
        output = Path("/nssr_sim/logs")
        output.mkdir(exist_ok=True)
        for name, msg in images.items():
            row = np.frombuffer(bytes(msg.data), dtype=np.uint8).reshape(msg.height, msg.step)
            details = {"width": msg.width, "height": msg.height, "encoding": msg.encoding}
            if name.endswith("color"):
                pixels = row[:, :msg.width * 3].reshape(msg.height, msg.width, 3)
                details.update(mean=float(pixels.mean()), std=float(pixels.std()))
                image_path = output / f"windows-{name}.png"
                bgr = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR) if msg.encoding == "rgb8" else pixels
                ok, encoded = cv2.imencode(".png", bgr)
                if not ok:
                    raise RuntimeError("Image encoding failed")
                image_path.write_bytes(encoded.tobytes())
            else:
                depths = row[:, :msg.width * 2].copy().view(np.uint16)
                valid = depths[depths > 0]
                details.update(valid_pixels=int(valid.size),
                               median_mm=float(np.median(valid)) if valid.size else None)
            report[name] = details
        report["ok"] = (report["head_motion_ok"] and task.get("task") == "sort2"
                        and all(name in images for name in
                                ("head_color", "head_depth", "torso_color", "torso_depth"))
                        and all(report[name]["std"] > 1 for name in ("head_color", "torso_color"))
                        and all(report[name]["valid_pixels"] > 0 for name in ("head_depth", "torso_depth")))
        (output / "windows-verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(json.dumps(report, indent=2))
        if not report["ok"]:
            raise RuntimeError("End-to-end verification failed")
    finally:
        if initial is not None:
            move(initial)
            spin(0.5)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
