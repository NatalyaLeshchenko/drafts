"""Development-only layout reset. Never imported by the sorting controller."""
import argparse
import rclpy
from std_msgs.msg import Int32
from collect_pool2 import Recorder

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--seed',type=int,required=True)
args=parser.parse_args()
rclpy.init();node=Recorder()
try:
    node.wait(2)
    if node.task.get('task')!='sort2' or node.task.get('objects_from')!='pool 2':
        raise RuntimeError('Expected development sort2 pool 2')
    if not node.randomize.get_subscription_count():
        raise RuntimeError('Development layout reset unavailable')
    node.randomize.publish(Int32(data=args.seed));node.wait(5)
    print('Development layout reset, seed='+str(args.seed),flush=True)
finally:
    node.destroy_node();rclpy.shutdown()
