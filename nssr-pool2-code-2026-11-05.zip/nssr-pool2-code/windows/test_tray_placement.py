import unittest
import numpy as np
from tray_placement import choose_placement

class PlacementTests(unittest.TestCase):
    def test_full_payload_fits_without_putting_edge_at_center(self):
        tray=dict(support_normal_pelvis=[0,0,1],visible_dimensions_m=[.22,.32])
        points=np.array([[x,y,z] for x in (-.08,.08) for y in (-.08,.08) for z in (-.02,.02)])
        offset,support,report=choose_placement(tray,points)
        self.assertLess(np.linalg.norm(offset),1e-8)
        self.assertEqual(support,0)
        self.assertTrue(np.all(abs((points+offset)[:,:2])<np.array([.11,.16])))

    def test_occupied_area_sets_stack_height(self):
        tray=dict(support_normal_pelvis=[0,0,1],visible_dimensions_m=[.22,.32],
                  occupied_points_in_plane_m=[[0,0,.08]])
        points=np.array([[x,y,0] for x in (-.08,.08) for y in (-.14,.14)])
        self.assertGreater(choose_placement(tray,points)[1],.07)

if __name__=='__main__':unittest.main()
