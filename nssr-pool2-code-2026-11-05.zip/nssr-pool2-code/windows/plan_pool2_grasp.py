"""Plan sensor-relative side grasps; no arm movement and no object-state access."""
import argparse
import subprocess,sys
import json
from pathlib import Path
from itertools import product
from dataclasses import replace
import numpy as np
import rclpy
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from manipulation import Robot
from pick_sugar import Manipulator
from hand_geometry import commanded_joints,envelopes_tcp,flat_hand_geometry
from grasp_policy import select_profile, projected_width
from grasp_clearance import approach_envelope,object_clearance,open_hand_hits_surface


def solve(arm,position,rotation,initial):
    def error(q):
        t = arm.transform(q)
        return np.r_[t[:3,3]-position,.2*Rotation.from_matrix(rotation.T@t[:3,:3]).as_rotvec(),.001*(q-initial)]
    starts = [initial,arm.current()]+[np.random.default_rng(i).uniform(arm.low,arm.high) for i in range(4)]
    for start in starts:
        result = least_squares(error,np.clip(start,arm.low,arm.high),bounds=(arm.low,arm.high),max_nfev=180)
        t = arm.transform(result.x)
        if np.linalg.norm(t[:3,3]-position)<.004 and np.linalg.norm(Rotation.from_matrix(rotation.T@t[:3,:3]).as_rotvec())<.035:
            return result.x
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--object',default='beta_glucan')
    parser.add_argument('--patch-index',type=int,default=-1)
    parser.add_argument('--output',type=Path,default=Path('/nssr_sim/logs/pool2-grasp-plan.json'))
    parser.add_argument('--grasp-mode',choices=('auto','side','top'),default='auto')
    parser.add_argument('--waist-angle',type=float,default=0.)
    parser.add_argument('--side',choices=('left','right','auto'),default='auto')
    parser.add_argument('--height-offset',type=float,default=None,
        help='Grip-center offset from estimated body center in metres')
    parser.add_argument('--palm-roll',type=float)
    parser.add_argument('--depth-offset',type=float,default=.135)
    args = parser.parse_args()
    args.output.write_text(json.dumps({'selected':None,'candidates':[],'rejections':[{'reason':'planning not completed'}]}))
    data = json.loads(Path('/nssr_sim/logs/pool2-targets.json').read_text())
    target = next(o for o in data['objects'] if o['name']==args.object)
    if not target['repeatability_check_passed']:
        raise RuntimeError('Object localization did not pass multi-view consistency')
    center = np.array(target['approximate_body_center_pelvis_m'])
    normal = np.array(target['support_normal_pelvis'])
    height = target['height_above_observed_table_m']
    support = center-normal*height/2
    height_offset=args.height_offset if args.height_offset is not None else .008
    grip_center = support+normal*(height/2+height_offset)
    profile=select_profile(target)
    if args.grasp_mode!="auto":profile=replace(profile,mode=args.grasp_mode,family="upper_edge_pinch" if args.grasp_mode=="top" else profile.family)
    top_grasp=profile.mode=='top'
    if top_grasp and args.height_offset is None:
        grip_center=support+normal*(height*.7)
    geometry_target=target
    patches=target.get('local_grasp_patches',[])
    if patches and args.patch_index<0:
        combined=[];failures=[]
        for index in range(len(patches)):
            output=args.output.with_name(args.output.stem+f'-patch-{index}.json')
            logfile=output.with_suffix('.log')
            with logfile.open('w') as log:
                try:
                    subprocess.run([sys.executable,__file__,*sys.argv[1:],'--patch-index',str(index),'--output',str(output)],
                        stdout=log,stderr=subprocess.STDOUT,timeout=90,check=False)
                except subprocess.TimeoutExpired:
                    failures.append({'patch':index,'reason':'planning timeout'});continue
            if output.exists():
                trial=json.loads(output.read_text())
                combined.extend(trial.get('candidates',[]))
                failures.append({'patch':index,'rejections':trial.get('rejections',[])})
            if len({p['patch_index'] for p in combined})>=2:break
        selected=min(combined,key=lambda p:p['score']) if combined else None
        args.output.write_text(json.dumps({'selected':selected,'candidates':combined,'rejections':failures},indent=2))
        print(json.dumps({'object':target['name'],'selected_patch':selected['patch_index'] if selected else None,'candidates':len(combined)}),flush=True)
        if selected is None:raise RuntimeError('No collision-free observed loop patch')
        return
    if patches:
        patch=patches[args.patch_index]
        geometry_target={**target,**patch,'yaw_max_deviation_deg':10.}
        support=np.array(patch['support_pelvis_m'])
        height=patch['height_above_observed_table_m']
        grip_center=support+normal*(height*.7)
    base_grip_center=grip_center.copy()
    rclpy.init(); robot = Robot()
    try:
        robot.spin(3)
        if not robot.joints or robot.sim_time is None:
            raise RuntimeError('No live robot state')
        robot.joints['body_yaw_joint']=args.waist_angle
        plans,rejections = [],[]
        sides = ('left','right') if args.side=='auto' else (args.side,)
        for side in sides:
            side_count=0
            arm = Manipulator(robot,side)
            open_hand=list(profile.opened)
            close_hand=list(profile.closed)
            def contact_frame(command):
                bounds=envelopes_tcp(robot.kinematics,side,commanded_joints(side,command,robot.joints))
                thumb=bounds[robot.kinematics.aliases[side+'_thumb_4']].mean(0)
                index=bounds[robot.kinematics.aliases[side+'_index_2']].mean(0)
                return (thumb+index)/2,thumb-index,bounds
            measured_gap=profile.max_width_m
            flat_states=None
            if top_grasp:
                dims=geometry_target['visible_footprint_dimensions_m']
                required=projected_width(dims,90,geometry_target.get('yaw_max_deviation_deg') or 0.)
                try:
                    bottom,_,hand_preorientation,opened,closed,flat_states,measured_gap=flat_hand_geometry(robot.kinematics,side,robot.joints,required,height*.9)
                    desired_height=height*(.9 if profile.family=="upper_edge_pinch" else .65)
                    if patches:
                        desired_height=float((np.array(patch['surface_contact_pelvis_m'])-support)@normal)-patch.get('surface_radius_estimate_m',.003)
                    base_grip_center=support+normal*max(desired_height,.006-bottom)
                    if float((base_grip_center-support)@normal)>height*(1. if patches else .9):
                        raise ValueError("No grasp fits below the observed object top with table clearance")
                except ValueError as error:
                    rejections.append({'side':side,'reason':str(error)});continue
                open_hand=opened.tolist();close_hand=closed.tolist()
            open_offset,pinch_vector,_=contact_frame(open_hand)
            closed_offset,_,_=contact_frame(close_hand)
            offset=closed_offset
            tilt=float(np.arctan2(-pinch_vector[2],abs(pinch_vector[1]))) * (1 if pinch_vector[1]>0 else -1) if top_grasp else 0.
            if top_grasp:tilt=Rotation.from_matrix(hand_preorientation).as_euler("xyz")[0]
            # Cache static hand closure once per side, not once per candidate/IK.
            closure_geometry=[]
            for blend in np.linspace(0.,1.,9):
                command=np.array(open_hand)*(1-blend)+np.array(close_hand)*blend
                midpoint,_,bounds=contact_frame(command)
                hulls=envelopes_tcp(robot.kinematics,side,commanded_joints(side,command,robot.joints),collision=True)
                closure_geometry.append((midpoint,np.concatenate(list(hulls.values()))))
            preferred = np.array([.52,-.01 if side=='left' else .01,-.40 if side=='left' else .40,-1.98,-.12 if side=='left' else .12,-.10,1.27 if side=='left' else -1.27])
            rolls=(0.,) if top_grasp else ((args.palm_roll,) if args.palm_roll is not None else (0,30,-30,60,-60,90,-90,120,-120,150,-150,180))
            angles=[180,210,0,30,330,150,120,240,90,270,60,300]
            if geometry_target.get('yaw_deg_mod_180') is not None:
                yaw=geometry_target['yaw_deg_mod_180']
                if top_grasp:
                    local_axis=hand_preorientation@pinch_vector
                    yaw+=90-np.rad2deg(np.arctan2(local_axis[1],local_axis[0]))
                angles=[yaw,yaw+180]+angles
            preferred_angle=120 if side=="left" else 240
            angles.sort(key=lambda a:abs((a-preferred_angle+180)%360-180))
            heights=(float((base_grip_center-support)@normal),) if top_grasp else (height*.5+.008,height*.65,height*.75)
            for angle,roll,contact_height,elevation,route in product(angles,rolls,heights,(0.,20.,-20.,40.,-40.) if not top_grasp else (0.,),("vertical",) if top_grasp else ("side","vertical")):
                grip_center=support+normal*contact_height
                outward = np.array([np.cos(np.deg2rad(angle)),np.sin(np.deg2rad(angle)),0.])
                outward -= normal*np.dot(outward,normal); outward /= np.linalg.norm(outward)
                tangent = np.cross(outward,normal)
                hand_x = normal*np.cos(np.deg2rad(roll))+tangent*np.sin(np.deg2rad(roll))
                rotation = np.column_stack((hand_x,np.cross(outward,hand_x),outward))
                if elevation:
                    rotation=Rotation.from_rotvec(np.cross(outward,normal)*np.deg2rad(elevation)).as_matrix()@rotation
                if top_grasp:
                    rotation=np.column_stack((outward,np.cross(normal,outward),normal))@hand_preorientation
                pinch_axis=rotation@pinch_vector/np.linalg.norm(pinch_vector) if top_grasp else rotation[:,1]
                target_yaw=geometry_target.get('yaw_deg_mod_180')
                if target_yaw is not None:
                    a=np.deg2rad(target_yaw);long_axis=np.array([np.cos(a),np.sin(a),0.])
                    long_axis-=normal*(long_axis@normal);long_axis/=np.linalg.norm(long_axis)
                    short_axis=np.cross(normal,long_axis)
                    small,large=sorted(geometry_target['visible_footprint_dimensions_m'])
                    uncertainty=geometry_target.get('yaw_max_deviation_deg') or 0.
                    relative=np.rad2deg(np.arctan2(pinch_axis@short_axis,pinch_axis@long_axis))
                    closing_width=projected_width((small,large),relative,uncertainty)
                    if closing_width+(.006 if top_grasp else 0)>min(profile.max_width_m,measured_gap):
                        rejections.append({'side':side,'angle':angle,'reason':'object too wide across finger closing direction','width_m':float(closing_width)})
                        continue
                grasp = grip_center-rotation@offset
                open_tcp=grip_center-rotation@open_offset
                beside = open_tcp+(normal*.10 if route=="vertical" else outward*.13)
                above = open_tcp+normal*.24 if route=="vertical" else beside+normal*.24
                closed_tcp=grasp.copy()
                lift_distance=.06
                if patches:
                    delta=grip_center-np.array(target['approximate_body_center_pelvis_m'])
                    horizontal=delta-normal*(delta@normal)
                    lift_distance=max(.06,float(np.linalg.norm(horizontal))+.5*max(target['visible_footprint_dimensions_m'])+.03-contact_height)
                lift = closed_tcp+normal*lift_distance
                # TCP follows the changing contact midpoint while the fingers close.
                predicted_hand=np.concatenate([grip_center+(points-midpoint)@rotation.T
                    for midpoint,points in closure_geometry])
                clearance = float(np.min((predicted_hand-support)@normal)-.003)
                if clearance<.003:
                    rejections.append({'side':side,'angle':angle,'reason':'insufficient side-grasp finger clearance above table','clearance_m':clearance})
                    continue
                # Check the full open-hand sweep and closing envelopes, not a TCP ray.
                swept=approach_envelope(closure_geometry[0][1],rotation,above,beside,open_tcp)
                all_points=np.concatenate((swept,predicted_hand))
                neighbor_clearance=min([object_clearance(all_points,other,normal)
                    for other in data['objects'] if other['name']!=target['name']] or [1.])
                if neighbor_clearance<.005:
                    rejections.append({'side':side,'angle':angle,'reason':'neighbor envelope intersects approach','clearance_m':neighbor_clearance})
                    continue
                if patches and target.get('visible_grasp_surface_pelvis_m'):
                    open_hulls=envelopes_tcp(robot.kinematics,side,commanded_joints(side,open_hand,robot.joints),collision=True)
                    if open_hand_hits_surface(open_hulls,rotation,above,beside,open_tcp,target['visible_grasp_surface_pelvis_m']):
                        rejections.append({'side':side,'angle':angle,'reason':'open hand intersects another observed part of target'});continue
                q_open = solve(arm,open_tcp,rotation,preferred)
                if q_open is None:
                    rejections.append({"side":side,"angle":angle,"roll":roll,"height":contact_height,"elevation":elevation,"reason":"open-hand IK unavailable"}); continue
                q = solve(arm,grasp,rotation,q_open)
                if q is None:
                    rejections.append({'side':side,'angle':angle,'reason':'grasp IK unavailable'}); continue
                q_closure=[q_open]
                closure_ok=True
                for midpoint,_ in closure_geometry[1:]:
                    solution=solve(arm,grip_center-rotation@midpoint,rotation,q_closure[-1])
                    if solution is None or np.max(abs(solution-q_closure[-1]))>.22:
                        closure_ok=False;break
                    q_closure.append(solution)
                if not closure_ok:
                    rejections.append({'side':side,'angle':angle,'reason':'continuous closure IK unavailable'});continue
                q_beside = solve(arm,beside,rotation,q_open)
                q_above = solve(arm,above,rotation,q_beside) if q_beside is not None else None
                q_lift = solve(arm,lift,rotation,q)
                q_closed=solve(arm,closed_tcp,rotation,q)
                if q_above is None or q_lift is None or q_closed is None:
                    rejections.append({'side':side,'angle':angle,'reason':'approach/lift IK unavailable'}); continue
                score = float(np.linalg.norm(q_above-arm.current())+.4*np.linalg.norm(q-q_beside)-2*neighbor_clearance+.01*abs(roll))
                plans.append({'waist_angle':args.waist_angle,'object':target['name'],'side':side,'angle_deg':angle,'palm_roll_deg':roll,'score':score,
                    'approach_route':route,'approach_elevation_deg':elevation,'lift_distance_m':float(lift_distance),'contact_height_m':float(contact_height),'grasp_mode':profile.mode,'grasp_family':profile.family,'policy_version':2,
                    'measured_open_gap_m':measured_gap,'open_hand':open_hand,'close_hand':close_hand,'hand_tilt_deg':float(np.rad2deg(tilt)),
                    'rotation':rotation.tolist(),'grasp_tcp':closed_tcp.tolist(),'open_tcp':open_tcp.tolist(),'beside_tcp':beside.tolist(),
                    'above_tcp':above.tolist(),'lift_tcp':lift.tolist(),'grip_center':grip_center.tolist(),
                    'q_closure':[v.tolist() for v in q_closure],
                    'closure_commands':[(np.array(open_hand)*(1-v)+np.array(close_hand)*v).tolist() for v in np.linspace(0.,1.,9)],
                    'q_grasp':q_closed.tolist(),'q_beside':q_beside.tolist(),'q_above':q_above.tolist(),'q_lift':q_lift.tolist(),
                    'finger_table_clearance_estimate_m':clearance,'neighbor_clearance_estimate_m':neighbor_clearance,
                    'target':target,'patch_index':args.patch_index if patches else None,'local_patch':patch if patches else None,'planning_sim_time':robot.sim_time,
                    'limitations':'Approximate object envelopes, not a complete robot collision checker.'})
                side_count+=1
                if side_count>=3:
                    break
        output = {'selected':min(plans,key=lambda p:p['score']) if plans else None,'candidates':plans,'rejections':rejections}
        args.output.write_text(json.dumps(output,indent=2))
        print(json.dumps({'selected':None if not plans else {key:output['selected'][key] for key in ('object','side','grasp_family','angle_deg','finger_table_clearance_estimate_m')},'candidates':len(plans),'rejections':len(rejections)}),flush=True)
        if not plans:
            raise RuntimeError('No feasible side grasp found; arms were not moved')
    finally:
        robot.destroy_node(); rclpy.shutdown()


if __name__=='__main__':
    main()
