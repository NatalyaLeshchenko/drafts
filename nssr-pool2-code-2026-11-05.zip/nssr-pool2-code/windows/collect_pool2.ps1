param([string]$Output = '/nssr_sim/datasets/pool2_stage1')
$ErrorActionPreference = 'Stop'
if ($Output -notmatch '^/nssr_sim/datasets/[A-Za-z0-9_/-]+$') {
    throw 'Output must be a dataset path containing only ASCII letters, digits, underscores, slashes and hyphens.'
}
docker start nssr-ros-win | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Start Docker Desktop first.' }
docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml && python3 /windows-support/collect_pool2.py --output $Output"
if ($LASTEXITCODE -ne 0) { throw 'Dataset collection failed; existing captures have been preserved.' }
docker exec nssr-ros-win python3 /windows-support/inspect_pool2_dataset.py $Output
if ($LASTEXITCODE -ne 0) { throw 'Dataset quality check failed.' }
