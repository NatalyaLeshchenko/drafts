"""Verify lift and retention from the visible yellow box region in saved RGB-D frames."""
import argparse
import json
from pathlib import Path
import cv2
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--lift-only', action='store_true')
args = parser.parse_args()
folder = Path('/nssr_sim/logs')

def observed(name):
    image = cv2.imread(str(folder / f'{name}-head_color.png'))
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    metadata = json.loads((folder / f'{name}.json').read_text())
    depth = np.load(folder / f'{name}-depth.npz')['head_depth']
    v, u = np.mgrid[:depth.shape[0], :depth.shape[1]]
    mask = ((u > 480) & (u < 625) & (v > 200) & (hsv[:, :, 0] > 18) &
            (hsv[:, :, 0] < 42) & (hsv[:, :, 1] > 80) & (hsv[:, :, 2] > 110) & (depth > 0))
    if mask.sum() < 40:
        raise RuntimeError(f'Yellow sugar region is not visible: {name}')
    camera = metadata['cameras']['head']
    k, transform = np.array(camera['k']).reshape(3, 3), np.array(camera['transform'])
    z = depth[mask] / 1000.
    points = np.c_[(u[mask] - k[0, 2]) * z / k[0, 0],
                   (v[mask] - k[1, 2]) * z / k[1, 1], z] @ transform[:3, :3].T + transform[:3, 3]
    return np.median(points, axis=0)

closed, lifted = observed('sugar-closed'), observed('sugar-lifted')
report = {'lift_observed_m': float(lifted[2] - closed[2])}
report['lift_verified'] = report['lift_observed_m'] > .025
if not args.lift_only:
    shaken = observed('sugar-shaken')
    report['shift_after_shake_m'] = float(np.linalg.norm(shaken - lifted))
    report['retained_after_shake'] = (shaken[2] - closed[2] > .025 and report['shift_after_shake_m'] < .04)
report['ok'] = report['lift_verified'] and report.get('retained_after_shake', True)
(folder / 'sugar-verification.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2), flush=True)
if not report['ok']:
    raise RuntimeError('Camera verification did not confirm a retained physical grasp')
