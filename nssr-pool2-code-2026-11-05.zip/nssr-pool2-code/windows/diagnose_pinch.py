"""Static geometry diagnostic; never publishes commands."""
import json
import numpy as np
from scipy.spatial.transform import Rotation
from manipulation import Kinematics
from hand_geometry import commanded_joints,envelopes_tcp

k=Kinematics()
base=json.load(open('/nssr_sim/logs/pool2-before-grasp-grip.json'))['joints']
rows=[]
for side in ('left','right'):
    for aperture in (.2,.4,.6,.8,1.):
        opened=np.array([aperture]*4+[.95,.12]);closed=np.array([.18]*4+[.35,.12])
        states=[]
        for blend in np.linspace(0,1,9):
            joints=commanded_joints(side,opened*(1-blend)+closed*blend,base)
            boxes=envelopes_tcp(k,side,joints)
            thumb=boxes[k.aliases[side+'_thumb_4']].mean(0)
            index=boxes[k.aliases[side+'_index_2']].mean(0)
            hulls=envelopes_tcp(k,side,joints,collision=True)
            states.append(((thumb+index)/2,thumb-index,np.concatenate(list(hulls.values()))))
        best=None
        for tilt in range(-80,81,5):
            r=Rotation.from_euler('x',tilt,degrees=True).as_matrix()
            gap=r@states[0][1]
            if abs(gap[2])>.025:continue
            bottom=min(((points-mid)@r.T)[:,2].min() for mid,_,points in states)
            row=dict(side=side,aperture=aperture,tilt=tilt,bottom=float(bottom),gap=float(np.linalg.norm(gap[:2])))
            if best is None or bottom>best['bottom']:best=row
        if best:rows.append(best)
print(json.dumps(rows))
