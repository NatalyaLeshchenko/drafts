"""Development-only judge check; never used by the delivery controller."""
import json,time
from pathlib import Path
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32,String
rclpy.init();n=Node('development_delivery_check');result={}
sub=n.create_subscription(String,'/sim/task/result',lambda m:result.update(json.loads(m.data)),10)
pub=n.create_publisher(Int32,'/sim/task/check',10)
try:
    deadline=time.monotonic()+3
    while time.monotonic()<deadline:rclpy.spin_once(n,timeout_sec=.1)
    pub.publish(Int32(data=1));deadline=time.monotonic()+15
    while not result and time.monotonic()<deadline:rclpy.spin_once(n,timeout_sec=.1)
    if not result:raise RuntimeError('No judge response')
    Path('/nssr_sim/logs/pool2-delivery-judge.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2),flush=True)
finally:n.destroy_node();rclpy.shutdown()
