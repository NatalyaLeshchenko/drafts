"""ROS sensor/command helpers and URDF kinematics for local manipulation."""
import json
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState, Image, CameraInfo
from rosgraph_msgs.msg import Clock
from scipy.spatial.transform import Rotation
from bodyctrl_msgs.msg import CmdSetMotorPosition, SetMotorPosition

URDF = '/nssr_sim/assets/robots/tiangong_pro/tiangong_pro_with_hands.urdf'


class Kinematics:
    def __init__(self, path=URDF):
        self.parents = {}
        self.limits = {}
        for joint in ET.parse(path).getroot().findall('joint'):
            origin = joint.find('origin')
            transform = np.eye(4)
            if origin is not None:
                transform[:3, 3] = np.fromstring(origin.get('xyz', '0 0 0'), sep=' ')
                transform[:3, :3] = Rotation.from_euler('xyz', np.fromstring(origin.get('rpy', '0 0 0'), sep=' ')).as_matrix()
            axis = joint.find('axis')
            axis = np.fromstring(axis.get('xyz'), sep=' ') if axis is not None else np.zeros(3)
            self.parents[joint.find('child').get('link')] = (joint.find('parent').get('link'), joint.get('name'), joint.get('type'), transform, axis)
            limit = joint.find('limit')
            if limit is not None and limit.get('lower') is not None:
                self.limits[joint.get('name')] = (float(limit.get('lower')), float(limit.get('upper')))
        self.actual = {}
        self.aliases = {}
        model_path = Path(__file__).with_name('robot-physics-kinematics.json')
        if model_path.exists():
            model = json.loads(model_path.read_text())
            self.actual_root = model['root']
            self.aliases['pelvis'] = self.actual_root
            self.aliases['right_tcp_link'] = '/World/humanoid/R_tcp_link'
            self.aliases['left_tcp_link'] = '/World/humanoid/L_tcp_link'
            by_name = {j['name']: j for j in model['joints']}
            for link, (parent, name, *_) in self.parents.items():
                if name in by_name:
                    self.aliases[link] = by_name[name]['child']
                    self.aliases[parent] = by_name[name]['parent']
            for joint in model['joints']:
                anchors = []
                for number in (0, 1):
                    anchor = np.eye(4)
                    anchor[:3, 3] = joint[f'p{number}']
                    anchor[:3, :3] = Rotation.from_quat(joint[f'q{number}']).as_matrix()
                    anchors.append(anchor)
                axis = np.eye(3)['XYZ'.index(joint.get('axis', 'X'))]
                self.actual[joint['child']] = (joint, anchors[0], np.linalg.inv(anchors[1]), axis)

    def actual_transform(self, link, positions):
        if link == self.actual_root:
            return np.eye(4)
        joint, anchor0, inverse1, axis = self.actual[link]
        motion = np.eye(4)
        if joint['revolute']:
            motion[:3, :3] = Rotation.from_rotvec(axis * positions.get(joint['name'], 0.) * joint.get('sign', 1)).as_matrix()
        return self.actual_transform(joint['parent'], positions) @ anchor0 @ motion @ inverse1

    def transform(self, link, positions):
        chain = []
        while link != 'pelvis':
            if link in self.aliases:
                result = self.actual_transform(self.aliases[link], positions)
                for transform in reversed(chain):
                    result = result @ transform
                return result
            parent, name, kind, transform, axis = self.parents[link]
            motion = np.eye(4)
            if kind in ('revolute', 'continuous'):
                motion[:3, :3] = Rotation.from_rotvec(axis * positions.get(name, 0.0)).as_matrix()
            chain.append(transform @ motion)
            link = parent
        result = np.eye(4)
        for transform in reversed(chain):
            result = result @ transform
        return result


class Robot(Node):
    def __init__(self):
        super().__init__('right_hand_manipulation')
        self.joints, self.images, self.info = {}, {}, {}
        self.last_state = 0.0
        self.sim_time = None
        self.subscriptions_ = [self.create_subscription(JointState, '/joint_states', self.observe, 10)]
        self.subscriptions_.append(self.create_subscription(Clock, '/clock', lambda m: setattr(self, 'sim_time', m.clock.sec + m.clock.nanosec * 1e-9), 10))
        for camera in ('head', 'torso'):
            for kind in ('color', 'depth'):
                key = f'{camera}_{kind}'
                self.subscriptions_.append(self.create_subscription(Image, f'/cam_{camera}/{kind}/image_raw', lambda m, k=key: self.images.__setitem__(k, m), 2))
            self.subscriptions_.append(self.create_subscription(CameraInfo, f'/cam_{camera}/color/camera_info', lambda m, c=camera: self.info.__setitem__(c, m), 2))
        self.publishers_ = {g: self.create_publisher(CmdSetMotorPosition, f'/{g}/cmd_pos', 10) for g in ('arm', 'head', 'waist')}
        self.hand_publishers = {side:self.create_publisher(JointState, f'/inspire_hand/ctrl/{side}_hand', 10) for side in ('left','right')}
        self.hand_publisher = self.hand_publishers['right']
        self.kinematics = Kinematics()

    def observe(self, msg):
        self.joints.update(zip(msg.name, msg.position))
        self.last_state = time.monotonic()

    def spin(self, seconds):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.02)

    def command(self, group, targets, speed=0.5):
        self.publishers_[group].publish(CmdSetMotorPosition(cmds=[SetMotorPosition(name=k, pos=float(v), spd=float(speed), cur=3.0) for k, v in targets.items()]))

    def hand(self, values, side='right'):
        self.hand_publishers[side].publish(JointState(name=[str(i) for i in range(1, 7)], position=[float(x) for x in values]))

    def save(self, name='pick-snapshot'):
        folder = Path('/nssr_sim/logs')
        metadata = {'joints': dict(self.joints), 'cameras': {}}
        depths = {}
        for key, msg in self.images.items():
            rows = np.frombuffer(bytes(msg.data), dtype=np.uint8).reshape(msg.height, msg.step)
            if key.endswith('color'):
                pixels = rows[:, :msg.width * 3].reshape(msg.height, msg.width, 3)
                pixels = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR) if msg.encoding == 'rgb8' else pixels
                ok, encoded = cv2.imencode('.png', pixels)
                if ok:
                    (folder / f'{name}-{key}.png').write_bytes(encoded.tobytes())
            else:
                depths[key] = rows[:, :msg.width * 2].copy().view(np.uint16).reshape(msg.height, msg.width)
        for camera, info in self.info.items():
            metadata['cameras'][camera] = {'k': list(info.k), 'frame': info.header.frame_id,
                'transform': self.kinematics.transform(info.header.frame_id, self.joints).tolist()}
        np.savez_compressed(folder / f'{name}-depth.npz', **depths)
        (folder / f'{name}.json').write_text(json.dumps(metadata, indent=2))
        print(json.dumps({'snapshot': name, 'images': list(self.images), 'cameras': list(metadata['cameras']),
                          'right_tcp': self.kinematics.transform('right_tcp_link', self.joints)[:3, 3].tolist()}), flush=True)
