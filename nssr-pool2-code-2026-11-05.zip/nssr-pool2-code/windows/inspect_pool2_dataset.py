"""Validate recorded RGB-D data and generate an overview without simulator access."""
import argparse
import hashlib
import json
from pathlib import Path
import cv2
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('dataset', type=Path)
args = parser.parse_args()
folders = sorted(p for p in args.dataset.glob('seed_*_view_*') if (p / 'metadata.json').exists())
report = {'captures': len(folders), 'seeds': [], 'issues': [], 'depth_valid_fraction': {}, 'max_rgb_depth_skew_s': 0.,
          'max_head_yaw_error_rad': 0., 'unique_layout_head_images': 0}
hashes, tiles = set(), []
for folder in folders:
    meta = json.loads((folder / 'metadata.json').read_text())
    report['seeds'].append(meta['seed'])
    error = abs(meta['joint_positions'].get('head_yaw_joint', 999) - meta['head_yaw_target'])
    report['max_head_yaw_error_rad'] = max(report['max_head_yaw_error_rad'], error)
    for camera in ('head', 'torso'):
        rgb = cv2.imread(str(folder / f'{camera}_color.png'))
        depth = cv2.imread(str(folder / f'{camera}_depth.png'), cv2.IMREAD_UNCHANGED)
        if rgb is None or depth is None:
            report['issues'].append(f'{folder.name}: missing {camera} image')
            continue
        if depth.dtype != np.uint16 or depth.shape != rgb.shape[:2]:
            report['issues'].append(f'{folder.name}: invalid {camera} depth format')
        if int(depth.max()) == int(depth.min()):
            report['issues'].append(f'{folder.name}: constant {camera} depth')
        fraction = float(np.mean(depth > 0))
        report['depth_valid_fraction'].setdefault(camera, []).append(fraction)
        if fraction < .1:
            report['issues'].append(f'{folder.name}: almost empty {camera} depth')
        cams = meta['cameras']
        skew = abs(cams[f'{camera}_color']['stamp'] - cams[f'{camera}_depth']['stamp'])
        report['max_rgb_depth_skew_s'] = max(report['max_rgb_depth_skew_s'], skew)
        if folder.name.endswith('_view_0') and camera == 'head':
            hashes.add(hashlib.sha256(rgb.tobytes()).hexdigest())
            tile = cv2.resize(rgb, (480, 270))
            cv2.rectangle(tile, (0, 0), (480, 23), (0, 0, 0), -1)
            cv2.putText(tile, f"seed {meta['seed']} | {meta['split']}", (8, 17), cv2.FONT_HERSHEY_SIMPLEX, .5, (255, 255, 255), 1)
            tiles.append(tile)
report['seeds'] = sorted(set(report['seeds']))
report['unique_layout_head_images'] = len(hashes)
manifest = args.dataset / 'COMPLETE.json'
report['collection_complete'] = manifest.exists()
if manifest.exists():
    expected = json.loads(manifest.read_text())
    if expected['captures'] != len(folders) or sorted(expected['seeds']) != report['seeds']:
        report['issues'].append('Capture count or seeds do not match completion manifest')
for camera, values in report['depth_valid_fraction'].items():
    report['depth_valid_fraction'][camera] = {'min': min(values), 'max': max(values), 'mean': float(np.mean(values))}
if len(hashes) != len(report['seeds']):
    report['issues'].append('Missing or duplicate central-view layouts')
if tiles:
    cols = 3
    canvas = np.zeros((((len(tiles) + cols - 1) // cols) * 270, cols * 480, 3), np.uint8)
    for i, tile in enumerate(tiles):
        y, x = (i // cols) * 270, (i % cols) * 480
        canvas[y:y + 270, x:x + 480] = tile
    cv2.imwrite(str(args.dataset / 'overview.jpg'), canvas)
(args.dataset / 'quality_report.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
if report['issues']:
    raise SystemExit(1)
