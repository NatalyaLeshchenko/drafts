"""Compact evidence index for all six objects; never commands the simulator."""
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
logs=root/'nssr-uwt-polygon/logs'
names=('marc_anthony','beta_glucan','wilton','razer_mouse','deskstar','rocksmith_cable')
results={name:{'verified_attempts':[],'failed_attempts':[]} for name in names}
for directory in sorted(logs.glob('grasp-test-*')):
    summary=directory/'summary.json';verification=directory/'pool2-grasp-verification.json'
    if not summary.exists():continue
    data=json.loads(summary.read_text(encoding='utf-8-sig'))
    name=data['object']
    if name not in results or data['status']=='planned_only':continue
    entry={'directory':str(directory),'status':data['status']}
    success=False
    if verification.exists():
        proof=json.loads(verification.read_text(encoding='utf-8-sig'))
        plan_path=directory/'pool2-grasp-plan.json'
        plan=json.loads(plan_path.read_text(encoding='utf-8-sig')).get('selected') if plan_path.exists() else None
        # Do not associate a stale verification from the preceding object/attempt.
        if plan and proof.get('object')==name and proof.get('planning_sim_time')==plan.get('planning_sim_time'):
            entry['camera_comparisons']=proof.get('camera_comparisons',{})
            success=bool(proof.get('success'))
    entry['verified']=success
    results[name]['verified_attempts' if success else 'failed_attempts'].append(entry)
report={'objects':results,'verified_objects':sum(bool(v['verified_attempts']) for v in results.values()),
        'total_objects':len(names),'scope':'Independent grasp tests, not a full sorting run'}
(root/'windows/grasp-results.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'verified_objects':report['verified_objects'],'total_objects':6,
                  'objects':{name:bool(v['verified_attempts']) for name,v in results.items()}}))
