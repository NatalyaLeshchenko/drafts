"""Reset the demo, locate sugar, grasp from the side, lift, verify and shake."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
steps = [
    ('reset_sugar.py',), ('locate_sugar.py',),
    ('pick_sugar.py', 'approach', '--side'),
    ('pick_sugar.py', 'position', '--side'),
    ('pick_sugar.py', 'close', '--side'),
    ('pick_sugar.py', 'lift', '--side'),
    ('verify_sugar.py', '--lift-only'),
    ('pick_sugar.py', 'shake', '--side'),
    ('verify_sugar.py',),
]
for script, *arguments in steps:
    print(f'=== {script} {" ".join(arguments)} ===', flush=True)
    subprocess.run([sys.executable, str(root / script), *arguments], check=True)
print('Sugar demo completed and verified by RGB-D.', flush=True)
