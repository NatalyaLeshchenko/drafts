"""Launch the unmodified hackathon simulator using native Windows Isaac Sim."""
import argparse
import os
from pathlib import Path
import random
import runpy
import sys


def main():
    sys.stdout.reconfigure(line_buffering=True)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task", choices=("sort2", "sort3", "tubes"), nargs="?", default="sort2")
    parser.add_argument("--pool", type=int, choices=range(1, 7), default=1)
    parser.add_argument("--variant", choices=("easy", "standard", "color", "lying"), default="standard")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--dance-view", action="store_true", help="Demo without RGB-D cameras or wrist force calculations")
    args, extra = parser.parse_known_args()
    root = Path(__file__).resolve().parent.parent
    project = root / "nssr-uwt-polygon"
    generated = Path.home() / "isaac-win" / "generated"
    generated.mkdir(parents=True, exist_ok=True)
    os.environ.update({
        "OMNI_KIT_ACCEPT_EULA": "YES",
        "NSSR_BIND_LOOPBACK": "1",
        "HACK_TASK": args.task,
        "HACK_POOL": str(args.pool),
        "HACK_TUBES": args.variant,
        "HACK_SEED": str(args.seed if args.seed is not None else random.randrange(32768)),
        "HACK_ASSET_ROOT": (project / "assets/isaac/Assets/Isaac/5.1").as_posix(),
        "HACK_RENDER_INTERVAL": "3",
        "HACK_GEN_DIR": generated.as_posix(),
    })
    os.environ.setdefault("HACK_CAMS", "head,torso")
    if args.dance_view:
        os.environ["HACK_CAMS"] = "none"
        os.environ["HACK_FT"] = "0"
    kit_args = os.environ.get("HACK_KIT_ARGS", "")
    os.environ["HACK_KIT_ARGS"] = (
        kit_args + " --/app/vulkan=false --/app/runLoops/main/rateLimitEnabled=false"
    ).strip()
    import sitecustomize
    sitecustomize.install()
    sys.path[:0] = [str(project / "source"), str(project / "scripts")]
    os.chdir(project)
    print(f"[windows] task={args.task} pool={args.pool} seed={os.environ['HACK_SEED']}", flush=True)
    sys.argv = [str(project / "scripts/sim_runner.py"),
                "--task", "NSSRSim-TiangongPro-Parlor-v0", "--enable_cameras",
                "--num_envs", "1", "--device", "cpu", "--step_hz", "100", "--perf_stats"]
    if args.headless:
        sys.argv.append("--headless")
    sys.argv.extend(extra)
    runpy.run_path(sys.argv[0], run_name="__main__")


if __name__ == "__main__":
    main()
