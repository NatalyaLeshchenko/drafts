"""URDF inverse kinematics for an anchored, approximately level-foot shuffle."""
import xml.etree.ElementTree as ET

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation


# Commanded standing pose, independent of measured tracking error on each run.
NEUTRAL_LEGS = {motor: 0.0 for motor in (*range(51, 57), *range(61, 67))}
NEUTRAL_LEGS.update({52: -0.5, 54: 1.0, 55: -0.5, 62: -0.5, 64: 1.0, 65: -0.5})


class LegShuffle:
    def __init__(self, original, urdf):
        joints = {j.get('name'): j for j in ET.parse(urdf).getroot().findall('joint')}
        self.legs = {}
        self.cache = {}
        for side, first in (('l', 51), ('r', 61)):
            names = [f'{name}_{side}_joint' for name in
                     ('hip_roll', 'hip_pitch', 'hip_yaw', 'knee_pitch', 'ankle_pitch', 'ankle_roll')]
            chain, lower, upper = [], [], []
            for name in names:
                joint = joints[name]
                origin = joint.find('origin')
                xyz = np.fromstring(origin.get('xyz', '0 0 0'), sep=' ')
                rpy = np.fromstring(origin.get('rpy', '0 0 0'), sep=' ')
                axis = np.fromstring(joint.find('axis').get('xyz'), sep=' ')
                chain.append((xyz, Rotation.from_euler('xyz', rpy).as_matrix(), axis))
                limit = joint.find('limit')
                lower.append(float(limit.get('lower')) + 0.01)
                upper.append(float(limit.get('upper')) - 0.01)
            initial = np.array([original[first + i] for i in range(6)])
            self.legs[side] = dict(first=first, chain=chain, lower=lower, upper=upper,
                                   initial=initial, base=self.forward(chain, initial))

    @staticmethod
    def forward(chain, angles):
        position, rotation = np.zeros(3), np.eye(3)
        for (xyz, origin_rotation, axis), angle in zip(chain, angles):
            position += rotation @ xyz
            rotation = rotation @ origin_rotation @ Rotation.from_rotvec(axis * angle).as_matrix()
        return position, rotation

    def targets(self, label):
        if label in self.cache:
            return self.cache[label]
        result = {}
        for side, leg in self.legs.items():
            sign = 1 if side == 'l' else -1
            dx, dy, yaw = 0.0, 0.035 * sign, 0.0
            if label.startswith('left') or label.startswith('right'):
                active = label.startswith('left') == (side == 'l')
                dx = 0.10 if active else -0.065
                dy = sign * (0.065 if active else 0.035)
                yaw = sign * (0.24 if active else -0.12)
            if label in ('return', 'complete'):
                dx, dy, yaw = 0.0, 0.0, 0.0
            base_position, base_rotation = leg['base']
            target_position = base_position + np.array([dx, dy, 0.0])
            target_rotation = Rotation.from_euler('z', yaw).as_matrix() @ base_rotation

            def error(angles):
                position, rotation = self.forward(leg['chain'], angles)
                angular = Rotation.from_matrix(target_rotation.T @ rotation).as_rotvec()
                return np.concatenate((position - target_position, 0.25 * angular))

            solution = least_squares(error, leg['initial'], bounds=(leg['lower'], leg['upper']),
                                     max_nfev=60, ftol=1e-9, xtol=1e-9, gtol=1e-9)
            if np.linalg.norm(error(solution.x)) > 0.002:
                raise RuntimeError(f'Foot pose is unreachable: {side}, {label}')
            result.update({leg['first'] + i: float(value) for i, value in enumerate(solution.x)})
        self.cache[label] = result
        return result

    def height_errors(self, positions):
        result = {}
        for side, leg in self.legs.items():
            angles = [positions[leg['first'] + i] for i in range(6)]
            position, _ = self.forward(leg['chain'], angles)
            result[side] = float(position[2] - leg['base'][0][2])
        return result

    def foot_positions(self, positions):
        return {side: self.forward(leg['chain'], [positions[leg['first'] + i] for i in range(6)])[0].tolist()
                for side, leg in self.legs.items()}
