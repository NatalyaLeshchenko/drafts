$ErrorActionPreference = 'Stop'
$demoFlag = Join-Path $PSScriptRoot '.dance-fast'
try {
    Set-Content -LiteralPath $demoFlag -Value 'temporary dance mode'
    docker restart nssr-ros-win | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not restart ROS bridge.' }
    docker exec nssr-ros-win bash -lc 'source /opt/ros/humble/setup.bash && export FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml && python3 /windows-support/dance.py'
    if ($LASTEXITCODE -ne 0) { throw 'Dance failed; check that the simulator and ROS bridge are running.' }
} finally {
    if (Test-Path -LiteralPath $demoFlag) { Remove-Item -LiteralPath $demoFlag }
    docker restart nssr-ros-win | Out-Null
}
