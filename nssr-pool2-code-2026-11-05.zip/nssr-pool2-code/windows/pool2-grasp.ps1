param([ValidateSet('beta_glucan','marc_anthony','wilton','deskstar','razer_mouse','rocksmith_cable')][string]$Object='marc_anthony',
    [ValidateSet('left','right','auto')][string]$Side='left',[string]$PalmRoll='0',[switch]$ReuseObservation,[switch]$ReusePlan)
$ErrorActionPreference = 'Stop'
$workspaceRoot = Split-Path $PSScriptRoot
$visionRoot = Join-Path $workspaceRoot 'vision'
$logsRoot = Join-Path $workspaceRoot 'nssr-uwt-polygon\logs'
$verification = Join-Path $logsRoot 'pool2-grasp-verification.json'
$env:PYTHONUTF8 = '1'
if (Test-Path -LiteralPath $verification) {
    $last = Get-Content -LiteralPath $verification -Raw | ConvertFrom-Json
    $releaseFile = Join-Path $logsRoot 'pool2-released-grip.json'
    $releasedAfter = @($releaseFile, (Join-Path $logsRoot 'pool2-delivery-released-state.json')) | Where-Object {
        (Test-Path -LiteralPath $_) -and ((Get-Item -LiteralPath $_).LastWriteTime -gt (Get-Item -LiteralPath $verification).LastWriteTime)
    }
    if ($last.success -and !$releasedAfter) {
        throw 'The last run ended holding an object. Place/release it before starting another grasp.'
    }
}
if (!$ReuseObservation) {
    & (Join-Path $visionRoot 'vision.ps1') -Action Observe
    if ($LASTEXITCODE -ne 0) { throw 'Fresh observation failed.' }
}
$observation = (Get-Content -LiteralPath (Join-Path $visionRoot 'latest_observation.txt') -Raw).Trim()
if (((Get-Date)-(Get-Item -LiteralPath (Join-Path $observation 'objects_fused.json')).LastWriteTime).TotalSeconds -gt 120) { throw 'Observation too old; capture fresh images.' }
Copy-Item -LiteralPath (Join-Path $observation 'objects_fused.json') -Destination (Join-Path $logsRoot 'pool2-targets.json')
$rollArgument = if ($PalmRoll -eq 'auto') { '' } else { '--palm-roll '+([double]::Parse($PalmRoll,[System.Globalization.CultureInfo]::InvariantCulture)).ToString([System.Globalization.CultureInfo]::InvariantCulture) }
if (!$ReusePlan) {
    docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && python3 /windows-support/plan_pool2_grasp.py --object $Object --side $Side $rollArgument"
    if ($LASTEXITCODE -ne 0) { throw 'No feasible grasp plan; arms were not moved.' }
} else {
    $savedPlan=Get-Content (Join-Path $logsRoot 'pool2-grasp-plan.json') -Raw | ConvertFrom-Json
    if (!$savedPlan.selected -or $savedPlan.selected.object -ne $Object) { throw 'Saved plan does not match selected object.' }
    $fresh=(Get-Content -LiteralPath (Join-Path $logsRoot 'pool2-targets.json') -Raw | ConvertFrom-Json).objects | Where-Object name -eq $Object
    if (!$fresh -or !$fresh.repeatability_check_passed) { throw 'Reused plan requires stable fresh localization.' }
    $squared=0.
    for ($axis=0;$axis -lt 3;$axis++) {
        $delta=$fresh.approximate_body_center_pelvis_m[$axis]-$savedPlan.selected.target.approximate_body_center_pelvis_m[$axis]
        $squared+=$delta*$delta
    }
    if ([math]::Sqrt($squared) -gt .01 -or [math]::Abs($fresh.height_above_observed_table_m-$savedPlan.selected.target.height_above_observed_table_m) -gt .01) {
        throw 'Object moved relative to saved plan; replan required.'
    }
    if ($null -ne $fresh.yaw_deg_mod_180 -and $null -ne $savedPlan.selected.target.yaw_deg_mod_180) {
        $difference=[math]::Abs(($fresh.yaw_deg_mod_180-$savedPlan.selected.target.yaw_deg_mod_180+450)%180-90)
        if ($difference -gt 10) { throw 'Object rotated relative to saved plan; replan required.' }
    }

}
foreach ($stage in @('approach','beside','position','close','lift','hold')) {
    docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && python3 /windows-support/grasp_pool2.py $stage 2>&1"
    if ($LASTEXITCODE -ne 0) { throw "Grasp stopped at $stage. Inspect feedback before continuing." }
}
& (Join-Path $env:USERPROFILE 'isaac-win\Scripts\python.exe') (Join-Path $visionRoot 'verify_pool2_grasp.py')
if ($LASTEXITCODE -ne 0) { throw 'Sensor verification failed to execute.' }
$result = Get-Content -LiteralPath $verification -Raw | ConvertFrom-Json
if (!$result.success) { throw 'Object lift/retention was not verified. Review pool2-grasp-verification.json; do not assume the hand is holding it.' }
Write-Output 'Physical grasp and sustained lift verified by RGB-D. Robot is holding the object.'

