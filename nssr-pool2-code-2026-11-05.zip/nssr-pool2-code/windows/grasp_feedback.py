"""Conservative online payload-loss suspicion; RGB-D still decides success."""
import math


class PayloadGuard:
    def __init__(self,reference_force,delay=.35):
        self.reference=math.sqrt(sum(float(v)**2 for v in reference_force))
        self.delay=delay
        self.since=None

    def update(self,sim_time,force,effort):
        magnitude=math.sqrt(sum(float(v)**2 for v in force))
        weak=bool(effort) and max(effort)<.15
        suspected=weak and self.reference>.5 and magnitude<self.reference*.5
        if not suspected:self.since=None
        elif self.since is None:self.since=sim_time
        return self.since is not None and sim_time-self.since>=self.delay
