$ErrorActionPreference = 'Stop'
docker exec -it `
    -e FASTRTPS_DEFAULT_PROFILES_FILE=/nssr_sim/hackathon/docker/fastdds_hack.xml `
    nssr-ros-win bash -c 'source /opt/ros/humble/setup.bash; cd /nssr_sim/hackathon/ros2; if [ -f install/setup.bash ]; then source install/setup.bash; fi; exec bash'
exit $LASTEXITCODE
