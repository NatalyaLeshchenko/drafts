"""Local demo preparation: move only the adjacent hair-dye box out of the grasp corridor."""
import json
import rclpy
from std_msgs.msg import String
from manipulation import Robot

rclpy.init()
robot = Robot()
try:
    publisher = robot.create_publisher(String, '/sim/objects/set', 10)
    robot.spin(2)
    publisher.publish(String(data=json.dumps({
        'Just_For_Men_Mustache_Beard_Brushin_Hair_Color_Gel_Kit_Jet_Black_M60': [.80, .45, 0.0]})))
    robot.spin(3)
    robot.save('sugar-clearance')
finally:
    robot.destroy_node()
    rclpy.shutdown()
