"""Start native Isaac Sim and verify that a graphics device is created."""
import os

os.environ["OMNI_KIT_ACCEPT_EULA"] = "YES"

from isaacsim import SimulationApp

app = SimulationApp({"headless": True, "width": 640, "height": 360,
                     "extra_args": ["--/app/vulkan=false"]})
try:
    for _ in range(30):
        app.update()
    print("[CHECK] Native Isaac Sim startup completed", flush=True)
finally:
    app.close()
