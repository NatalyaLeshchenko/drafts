import json
from pathlib import Path
import numpy as np
import rclpy
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from manipulation import Robot
from pick_sugar import Manipulator
rclpy.init(); r=Robot(); r.spin(3)
o=next(o for o in json.loads(Path('/nssr_sim/logs/pool2-targets.json').read_text())['objects'] if o['name']=='beta_glucan')
n=np.array(o['support_normal_pelvis']); c=np.array(o['approximate_body_center_pelvis_m'])+n*.008
for side in ['left','right']:
    a=Manipulator(r,side)
    z=np.array([-1.,0.,0.]); z-=n*np.dot(z,n); z/=np.linalg.norm(z)
    rot=np.column_stack((n,np.cross(z,n),z))
    goal=c-rot@np.array([0.,-.04 if side=='left' else .04,-.13])
    print('side',side,'current',a.current(),'tcp',a.transform(a.current())[:3,3],'goal',goal,'det',np.linalg.det(rot),flush=True)
    def error(q):
        t=a.transform(q)
        return np.r_[t[:3,3]-goal,.2*Rotation.from_matrix(rot.T@t[:3,:3]).as_rotvec()]
    for i in range(4):
        q=np.random.default_rng(i).uniform(a.low,a.high)
        res=least_squares(error,q,bounds=(a.low,a.high),max_nfev=350)
        print('error',error(res.x),'q',res.x,flush=True)
r.destroy_node(); rclpy.shutdown()
