import argparse
import rclpy
from std_msgs.msg import Bool, Int32
from manipulation import Robot

parser = argparse.ArgumentParser()
parser.add_argument('--seed', type=int, default=27524)
args = parser.parse_args()
rclpy.init()
robot = Robot()
try:
    reset = robot.create_publisher(Bool, '/sim/cmd_reset', 10)
    layout = robot.create_publisher(Int32, '/sim/objects/randomize', 10)
    robot.spin(2)
    reset.publish(Bool(data=True))
    robot.spin(3)
    layout.publish(Int32(data=args.seed))
    robot.spin(3)
    robot.command('head', {1: 0., 2: .4, 3: 0.})
    robot.command('waist', {31: 0.})
    robot.spin(5)
    robot.save('sugar-baseline')
finally:
    robot.destroy_node()
    rclpy.shutdown()
