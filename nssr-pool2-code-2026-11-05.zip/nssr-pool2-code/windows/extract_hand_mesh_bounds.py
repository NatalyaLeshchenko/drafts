"""Extract static collision envelopes from the distributed robot model only."""
import os,sys,json,tempfile,shutil,itertools
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1]
usdlibs=next((Path(sys.prefix)/'Lib/site-packages/isaacsim/extscache').glob('omni.usd.libs-*'))
sys.path.insert(0,str(usdlibs));dll=os.add_dll_directory(str(usdlibs/'bin'))
from pxr import Usd,UsdGeom,UsdPhysics,Plug
Plug.Registry().RegisterPlugins(str(usdlibs/'bin/usd'))
source=root/'nssr-uwt-polygon/assets/robots/tiangong_pro/tiangong_pro_v2.usd'
temp=Path(tempfile.gettempdir())/'nssr-hand-geometry.usd';shutil.copyfile(source,temp)
stage=Usd.Stage.Open(str(temp));cache=UsdGeom.XformCache();bodies={}
for prim in stage.Traverse():
    if '/hand' not in str(prim.GetPath()) or not prim.IsA(UsdGeom.Mesh) or not prim.HasAPI(UsdPhysics.CollisionAPI):continue
    body=prim
    while body and not body.HasAPI(UsdPhysics.RigidBodyAPI):body=body.GetParent()
    if not body:continue
    points=np.array(UsdGeom.Mesh(prim).GetPointsAttr().Get(),float)
    if not len(points):continue
    transform=np.array(cache.GetLocalToWorldTransform(body).GetInverse()).T@np.array(cache.GetLocalToWorldTransform(prim)).T
    transformed=points@transform[:3,:3].T+transform[:3,3]
    bodies.setdefault(str(body.GetPath()),[]).append(transformed)
from scipy.spatial import ConvexHull
out={}
hulls={}
for body,clouds in bodies.items():
    points=np.concatenate(clouds)
    out[body]=list(map(list,itertools.product(*zip(points.min(0),points.max(0)))))
    hulls[body]=points[ConvexHull(points).vertices].tolist()
path=root/'windows/robot-hand-mesh-bounds.json';path.write_text(json.dumps(out,indent=2))
(root/'windows/robot-hand-collision-hulls.json').write_text(json.dumps(hulls))
print(json.dumps({'bodies':len(out),'path':str(path)},ensure_ascii=True))
