"""Plan/execute a coordinated waist and arm delivery using a measured tray."""
import argparse,json,time
from pathlib import Path
import numpy as np
import rclpy
from scipy.optimize import least_squares,minimize
from scipy.spatial.transform import Rotation
from manipulation import Robot
from pick_sugar import Manipulator
from geometry_msgs.msg import WrenchStamped
from sensor_msgs.msg import JointState
from grasp_feedback import PayloadGuard
from tray_placement import choose_placement
from hand_geometry import envelopes_tcp

ROOT=Path('/nssr_sim/logs')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['plan','raise','transfer','place','release','withdraw','return','observe-raise','observe-transfer','inspect'])
    args=parser.parse_args()
    grasp=json.loads((ROOT/'pool2-grasp-plan.json').read_text())['selected']
    tray=json.loads((ROOT/'pool2-tray-target.json').read_text())
    rclpy.init(); r=Robot()
    force={};hand={}
    def force_update(message):
        force.update(values=[message.wrench.force.x,message.wrench.force.y,message.wrench.force.z],time=r.sim_time)
    subscriptions=[r.create_subscription(WrenchStamped,'/arm_6dof_'+grasp['side'],force_update,10),
        r.create_subscription(JointState,'/inspire_hand/state/'+grasp['side']+'_hand',lambda m:hand.update(effort=list(m.effort)),10)]
    try:
        r.spin(3)
        deadline=time.monotonic()+12
        while 'body_yaw_joint' not in r.joints:
            if time.monotonic()>deadline: raise RuntimeError('No live joint feedback')
            r.spin(.2)
        arm=Manipulator(r,grasp['side'])
        names=['body_yaw_joint']+arm.names
        low=np.r_[-2.8,arm.low]; high=np.r_[2.95,arm.high]
        def current(): return np.array([r.joints[n] for n in names])
        def tf(q,link=None):
            joints=dict(r.joints); joints.update(zip(names,q))
            return r.kinematics.transform(link or arm.tcp_link,joints)
        normal=np.array(tray['support_normal_pelvis'])
        floor=np.array(tray['center_floor_pelvis_m'])
        closed=json.loads((ROOT/'pool2-closed-grip.json').read_text())
        if closed['plan']['planning_sim_time']!=grasp['planning_sim_time']:
            raise RuntimeError('Closed pose does not match current grasp')
        offset=np.array(grasp['rotation']).T@(np.array(grasp['grip_center'])-np.array(closed['tcp'])[:3,3])
        if args.stage=='plan':
            q=current(); initial=q.copy(); T=tf(q); R0=T[:3,:3]
            payload=json.loads((ROOT/'pool2-held-payload.json').read_text())
            if payload['planning_sim_time']!=grasp['planning_sim_time']:raise RuntimeError('Stale held payload geometry')
            offset=np.array(payload['center_in_tcp_m'])
            center=T[:3,3]+R0@offset
            height=grasp['target']['height_above_observed_table_m']
            delivery_turn=(-1.0 if grasp['side']=='left' else 0.) if tray['tray']=='tray_right' else (1.0 if grasp['side']=='right' else 0.)
            final_rotation=Rotation.from_rotvec(normal*delivery_turn).as_matrix()@R0
            relative=(np.array(payload['points_in_tcp_m'])-offset)@final_rotation.T
            placement_offset,stack_height,packing=choose_placement(tray,relative)
            placement=floor+placement_offset
            hand=envelopes_tcp(r.kinematics,grasp['side'],r.joints,collision=True)
            hand_relative=(np.concatenate(list(hand.values()))-offset)@R0.T
            hand_below=max(0.,-float((hand_relative@normal).min()))
            observed=json.loads((ROOT/'pool2-targets.json').read_text())['objects']
            obstacle_height=max([o['height_above_observed_table_m'] for o in observed if o['name']!=grasp['object']] or [0.])
            transit_height=max(float(np.dot(center-floor,normal)),.30,obstacle_height+.05+max(payload['down_extent_m'],hand_below))
            vertical_center=center+normal*(transit_height-np.dot(center-floor,normal))
            forward_axis=np.array([1.,0,0]);forward_axis-=normal*(forward_axis@normal);forward_axis/=np.linalg.norm(forward_axis)
            liftcenter=vertical_center+forward_axis*max(0.,.52-float(vertical_center@forward_axis))
            dest=placement+normal*(transit_height+stack_height)
            release=placement+normal*(payload['down_extent_m']+stack_height+.080)
            stages={}; total=0
            for label,end,turn_end in [('raise',liftcenter,0.),('transfer',dest,delivery_turn),('place',release,delivery_turn)]:
                start=tf(q)[:3,3]+tf(q)[:3,:3]@offset
                turn_start=0. if label!='place' else delivery_turn
                path=[q.copy()]
                count=max(4,int(np.ceil((2*(np.linalg.norm(vertical_center-start)+np.linalg.norm(end-vertical_center)) if label=='raise' else np.linalg.norm(end-start)+.2)/.008)))
                for i in range(1,count+1):
                    u=i/count; c=start+(end-start)*u
                    if label=='raise':
                        c=start+(vertical_center-start)*(2*u) if u<.5 else vertical_center+(end-vertical_center)*(2*u-1)
                    elif label=='transfer':c+=forward_axis*(.10*np.sin(np.pi*u))
                    turn=turn_start+(turn_end-turn_start)*u
                    rot=Rotation.from_rotvec(normal*turn).as_matrix()@R0
                    target=c-rot@offset
                    previous=q.copy()
                    def error(v):
                        t=tf(v)
                        return np.r_[t[:3,3]-target,.2*Rotation.from_matrix(rot.T@t[:3,:3]).as_rotvec(),.006*(v-previous),.001*(v[0]-turn)]
                    result=least_squares(error,np.clip(q,low,high),bounds=(low,high),max_nfev=180)
                    q=result.x; t=tf(q)
                    pe=np.linalg.norm(t[:3,3]-target)
                    re=np.linalg.norm(Rotation.from_matrix(rot.T@t[:3,:3]).as_rotvec())
                    if pe>.004 or re>.035:
                        def position_slack(v):return .0035**2-float(np.sum((tf(v)[:3,3]-target)**2))
                        def rotation_slack(v):return .030**2-float(np.sum(Rotation.from_matrix(rot.T@tf(v)[:3,:3]).as_rotvec()**2))
                        refined=minimize(lambda v:float(np.sum((v-previous)**2)+.01*(v[0]-turn)**2),q,
                            method='SLSQP',bounds=list(zip(low,high)),
                            constraints=[{'type':'ineq','fun':position_slack},{'type':'ineq','fun':rotation_slack}],
                            options={'maxiter':180,'ftol':1e-11})
                        q=refined.x;t=tf(q)
                        pe=np.linalg.norm(t[:3,3]-target)
                        re=np.linalg.norm(Rotation.from_matrix(rot.T@t[:3,:3]).as_rotvec())
                    if pe>.004 or re>.035:
                        raise RuntimeError(f'Unreachable {label} point {i}/{count}: {pe:.3f}m {re:.3f}rad; no motion executed')
                    if np.max(abs(q-previous))>.22:
                        raise RuntimeError(f'Discontinuous IK branch {label} {i}/{count}: {np.max(abs(q-previous)):.3f}; no motion executed')
                    path.append(q.copy())
                stages[label]=np.array(path).tolist(); total+=count
            output={'planning_sim_time':grasp['planning_sim_time'],'object':grasp['object'],'side':grasp['side'],'tray':tray,'initial':initial.tolist(),
                    'payload':payload,'packing':packing,'names':names,'stages':stages,'object_height_m':height,'release_gap_m':.08,
                    'normal':normal.tolist(),'initial_rotation':R0.tolist(),
                    'limitations':'Sampled IK and raised transit, not complete mesh collision planning.'}
            (ROOT/'pool2-delivery-plan.json').write_text(json.dumps(output,indent=2))
            print(json.dumps({'planned_points':total,'waist_end':float(q[0]),'release_center':release.tolist()},indent=2),flush=True)
            return
        plan=json.loads((ROOT/'pool2-delivery-plan.json').read_text())
        def save_state(label,error=0.):
            r.save('pool2-delivery-'+label)
            (ROOT/f'pool2-delivery-{label}-state.json').write_text(json.dumps({
                'planning_sim_time':grasp['planning_sim_time'],'object':grasp['object'],
                'sim_time':r.sim_time,'joints':r.joints,'tcp':tf(current()).tolist(),
                'hand_hulls_tcp':{body:points.tolist() for body,points in envelopes_tcp(r.kinematics,grasp['side'],r.joints,collision=True).items()},
                'max_joint_error':error,'hand':hand,'wrist_force':force},indent=2))
        def look_at(q):
            t=tf(q);point=t[:3,3]+t[:3,:3]@np.array(plan['payload']['center_in_tcp_m'])
            yaw=float(np.clip(np.arctan2(point[1],point[0])-q[0],-1.45,1.45))
            frame=r.info['head'].header.frame_id
            def pixel_error(v):
                joints=dict(r.joints);joints.update(zip(names,q))
                joints.update(head_pitch_joint=v[0],head_yaw_joint=v[1],head_roll_joint=0.)
                camera=r.kinematics.transform(frame,joints)
                local=camera[:3,:3].T@(point-camera[:3,3])
                return np.r_[local[:2]/max(.05,local[2]),max(0.,.05-local[2])]
            aim=least_squares(pixel_error,[.4,yaw],bounds=([-.5,-1.45],[.95,1.45]),max_nfev=80).x
            r.command('head',{1:0.,2:aim[0],3:aim[1]})
            return aim
        def move(path,label,speed=.35):
            path=np.array(path)
            if np.max(abs(current()-path[0]))>.06:
                raise RuntimeError('Robot differs from planned start; refusing movement')
            lengths=np.max(abs(np.diff(path,axis=0)),axis=1); cum=np.r_[0.,np.cumsum(lengths)]
            duration=max(1.,1.875*cum[-1]/speed)
            begin=r.sim_time; previous=begin; bias=np.zeros(8); deadline=time.monotonic()+max(100,duration*4)
            held=json.loads((ROOT/'pool2-held-grip.json').read_text())
            if label in ('raise','transfer','place') and held['plan']['planning_sim_time']!=grasp['planning_sim_time']:
                raise RuntimeError('Payload reference belongs to another grasp')
            guard=PayloadGuard([held['wrist_force'][axis] for axis in ('x','y','z')]) if label in ('raise','transfer','place') else None
            samples=[]
            print(f'{label}: {duration:.1f}s simulation',flush=True)
            while r.sim_time-begin<duration+3:
                if time.monotonic()>deadline or time.monotonic()-r.last_state>2: raise RuntimeError('Feedback stopped')
                if guard is not None:
                    if 'values' not in force or r.sim_time-force.get('time',-999)>1.:
                        raise RuntimeError('Wrist feedback stale during payload transport')
                    samples.append({'time':r.sim_time,'force':force['values'],'effort':hand.get('effort',[])})
                    if guard.update(r.sim_time,force['values'],hand.get('effort',[])):
                        fixed=current()
                        r.command('waist',{31:fixed[0]},speed=.2)
                        r.command('arm',{arm.motor_start+i:v for i,v in enumerate(fixed[1:])},speed=.2)
                        (ROOT/('pool2-payload-loss-'+label+'.json')).write_text(json.dumps(samples))
                        raise RuntimeError('Payload loss suspected: wrist load fell and fingers unloaded; stopped')
                u=min(1.,(r.sim_time-begin)/duration); blend=u**3*(10-15*u+6*u*u)
                s=blend*cum[-1]; j=min(max(0,np.searchsorted(cum,s,side='right')-1),len(path)-2)
                f=(s-cum[j])/max(lengths[j],1e-12); target=path[j]+f*(path[j+1]-path[j])
                dt=min(.05,max(0.,r.sim_time-previous)); previous=r.sim_time
                bias=np.clip(bias+1.6*(target-current())*dt,-.25,.25)
                if np.max(abs(target-current()))>.16:
                    (ROOT/'pool2-delivery-tracking-error.json').write_text(json.dumps({'stage':label,'fraction':float(u),'target':target.tolist(),'actual':current().tolist(),'names':names,'force':force,'hand':hand},indent=2))
                    fixed=current()
                    r.command('waist',{31:fixed[0]},speed=.2)
                    r.command('arm',{arm.motor_start+i:v for i,v in enumerate(fixed[1:])},speed=.2)
                    raise RuntimeError('Excess tracking error; stopped')
                command=np.clip(target+bias,low,high)
                r.command('waist',{31:command[0]},speed=.5)
                r.command('arm',{arm.motor_start+i:v for i,v in enumerate(command[1:])},speed=.65)
                r.spin(.04)
            error=float(np.max(abs(current()-path[-1])))
            if error>.04: raise RuntimeError(f'Goal error {error:.3f} rad')
            save_state(label,error)
        if args.stage in plan['stages']:
            look_at(np.array(plan['stages'][args.stage][-1]))
            move(plan['stages'][args.stage],args.stage)
        elif args.stage=='inspect':
            look_at(current());r.spin(2.);save_state('inspection')
        elif args.stage.startswith('observe-'):
            label=args.stage.split('-',1)[1]
            expected=np.array(plan['stages'][label][-1])
            if np.max(abs(current()-expected))>.06:raise RuntimeError('Not at stage end for observation')
            aim=look_at(current());deadline=time.monotonic()+20
            while max(abs(r.joints.get('head_yaw_joint',999)-aim[1]),abs(r.joints.get('head_pitch_joint',999)-aim[0]))>.025:
                if time.monotonic()>deadline:raise RuntimeError('Camera did not reach payload view')
                r.spin(.1)
            r.spin(1.);save_state(label)
        elif args.stage=='release':
            goal=np.array(plan['stages']['place'][-1])
            if np.max(abs(current()-goal))>.04: raise RuntimeError('Not at release pose')
            r.hand(grasp.get('open_hand',[1.,1.,1.,1.,.95,.12]),grasp['side'])
            start=r.sim_time; deadline=time.monotonic()+35
            while r.sim_time-start<4:
                if time.monotonic()>deadline: raise RuntimeError('Release feedback timed out')
                r.spin(.04)
            r.save('pool2-delivery-released')
            (ROOT/'pool2-delivery-released-state.json').write_text(json.dumps({'sim_time':r.sim_time,'tcp':tf(current()).tolist(),'joints':r.joints},indent=2))
        elif args.stage=='withdraw':
            path=np.array(plan['stages']['place'])[::-1].copy();path[0]=current()
            move(path,'withdraw',.3)
        elif args.stage=='return':
            release=ROOT/'pool2-delivery-released-state.json'
            if not release.exists() or release.stat().st_mtime<(ROOT/'pool2-delivery-plan.json').stat().st_mtime:
                raise RuntimeError('No release recorded for this delivery')
            # Reverse only the raised transit, with the now empty hand.
            path=np.array(plan['stages']['transfer'])[::-1].copy()
            move(path,'return',.4)
            q=current(); neutral=q.copy(); neutral[0]=0.
            move([q,neutral],'waist-neutral',.3)
            r.command('head',{1:0.,2:.4,3:0.})
    finally:
        r.destroy_node();rclpy.shutdown()

if __name__=='__main__': main()





