"""Execute a planned physical grasp through public ROS commands, in inspectable stages."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import rclpy
from rclpy.qos import QoSProfile,DurabilityPolicy,ReliabilityPolicy
from sensor_msgs.msg import JointState
from geometry_msgs.msg import WrenchStamped
from std_msgs.msg import String
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares
from manipulation import Robot
from pick_sugar import Manipulator
from hand_geometry import envelopes_tcp


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=('approach','beside','position','close','lift','hold','lower','release','retreat','recover','home','inspect'))
    args=parser.parse_args()
    plan=json.loads(Path('/nssr_sim/logs/pool2-grasp-plan.json').read_text())['selected']
    if plan is None:
        raise RuntimeError('No selected grasp plan')
    rclpy.init(); robot=Robot(); side=plan['side']; state={}; force={}; task={}
    subscriptions=[robot.create_subscription(JointState,f'/inspire_hand/state/{side}_hand',lambda m:state.update(position=list(m.position),effort=list(m.effort)),10),
        robot.create_subscription(WrenchStamped,f'/arm_6dof_{side}',lambda m:force.update(x=m.wrench.force.x,y=m.wrench.force.y,z=m.wrench.force.z),10)]
    qos=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)
    subscriptions.append(robot.create_subscription(String,'/sim/task',lambda m:task.update(json.loads(m.data)),qos))
    def wait_sim(seconds):
        start=robot.sim_time; deadline=time.monotonic()+40
        while robot.sim_time-start<seconds:
            if time.monotonic()>deadline or time.monotonic()-robot.last_state>2:
                raise RuntimeError('Simulator feedback stopped')
            robot.spin(.04)
    def waist(target):
        deadline=time.monotonic()+20
        while abs(robot.joints.get('body_yaw_joint',999)-target)>.012:
            if time.monotonic()>deadline or time.monotonic()-robot.last_state>2:
                raise RuntimeError('Waist feedback did not reach target')
            robot.command('waist',{31:target},speed=.3)
            robot.spin(.05)
        wait_sim(1.)
    def snapshot(label):
        robot.spin(.4); robot.save(label)
        data={'stage':args.stage,'side':side,'object':plan['object'],'sim_time':robot.sim_time,
            'hand':state.copy(),'wrist_force':force.copy(),'tcp':arm.transform(arm.current()).tolist(),
            'joints':robot.joints.copy(),'plan':plan,
            'hand_hulls_tcp':{body:points.tolist() for body,points in envelopes_tcp(robot.kinematics,side,robot.joints,collision=True).items()}}
        Path(f'/nssr_sim/logs/{label}-grip.json').write_text(json.dumps(data,indent=2))
    try:
        robot.spin(3)
        if task.get('task')!='sort2' or task.get('objects_from')!='pool 2':
            raise RuntimeError('Current task is not sort2 pool 2')
        arm=Manipulator(robot,side)
        rotation=np.array(plan['rotation'])
        if args.stage=='inspect':
            snapshot('pool2-inspection')
            print(json.dumps({'actual_tcp':arm.transform(arm.current())[:3,3].tolist(),'open_target':plan.get('open_tcp',plan['grasp_tcp']),'force':force,'hand':state}),flush=True)
            return
        if args.stage=='approach':
            target_waist=plan.get('waist_angle',0.)
            if abs(robot.joints.get('body_yaw_joint',0)-target_waist)>.012:
                both=[Manipulator(robot,s) for s in ('left','right')]
                if any(np.max(abs(a.current()))>.12 for a in both):
                    raise RuntimeError('Both arms must be neutral before changing grasp waist angle')
                waist(target_waist)
            Path('/nssr_sim/logs/pool2-arm-start.json').write_text(json.dumps({'side':side,'angles':arm.current().tolist()}))
            robot.command('head',{1:0.,2:.65 if plan['target']['approximate_body_center_pelvis_m'][0]<.28 else .4,3:-plan.get('waist_angle',0.)})
            robot.hand(plan.get('open_hand',[1.,1.,1.,1.,.95,.12]),side)
            wait_sim(2)
            snapshot('pool2-before-grasp')
            normal=np.array(plan['target']['support_normal_pelvis'])
            support=np.array(plan['target']['approximate_body_center_pelvis_m'])-normal*plan['target']['height_above_observed_table_m']/2
            if np.dot(arm.transform(arm.current())[:3,3]-support,normal)<.26:
                spread=arm.current(); spread[1]=1.0 if side=='left' else -1.0
                arm.move(spread,'spread arm away from torso',speed=.5)
                fold=spread.copy(); fold[3]=-1.6
                arm.move(fold,'raise forearm above table',speed=.5)
            arm.move(np.array(plan['q_above']),'approach high beside object',speed=.45)
            snapshot('pool2-high-approach')
        elif args.stage in ('beside','position','lift','lower'):
            key={'beside':'beside_tcp','position':'grasp_tcp','lift':'lift_tcp','lower':'grasp_tcp'}[args.stage]
            target=np.array(plan[key])
            if args.stage=='position':target=np.array(plan.get('open_tcp',plan[key]))
            if args.stage in ('lift','lower'):
                closed=json.loads(Path('/nssr_sim/logs/pool2-closed-grip.json').read_text())
                if closed['plan']['planning_sim_time']!=plan['planning_sim_time']:
                    raise RuntimeError('Closed snapshot belongs to another plan')
                target=np.array(closed['tcp'])[:3,3]+np.array(plan['target']['support_normal_pelvis'])*(plan.get('lift_distance_m',.06) if args.stage=='lift' else 0.)
            arm.cartesian(target,rotation,args.stage,speed=.25 if args.stage in ('position','lower') else .4)
            transform=arm.transform(arm.current())
            position_error=float(np.linalg.norm(transform[:3,3]-target))
            rotation_error=float(np.linalg.norm(Rotation.from_matrix(rotation.T@transform[:3,:3]).as_rotvec()))
            if position_error>.010 or rotation_error>.10:
                raise RuntimeError(f'Hand did not reach pose: {position_error:.4f} m, {rotation_error:.3f} rad')
            if args.stage=='lift':
                wait_sim(2)
            snapshot('pool2-'+args.stage)
        elif args.stage=='close':
            if np.linalg.norm(arm.transform(arm.current())[:3,3]-np.array(plan.get('open_tcp',plan['grasp_tcp'])))>.015:
                raise RuntimeError('Hand is not at planned grasp pose; refusing to close')
            if plan.get('policy_version')!=2 or plan.get('close_hand') is None:
                raise RuntimeError('Replan with geometry policy v2 before closing')
            closing=plan['close_hand']
            top=plan.get('grasp_mode')=='top'

            path=np.array(plan['q_closure'])
            # A redundant arm can reach the same TCP pose on another joint branch.
            # Rebase the validated Cartesian closure onto actual measured joints.
            actual_path=[arm.current()]
            for planned in path[1:]:
                target_tcp=arm.transform(planned)[:3,3]
                previous=actual_path[-1]
                def residual(q):
                    transform=arm.transform(q)
                    return np.r_[transform[:3,3]-target_tcp,
                        .2*Rotation.from_matrix(rotation.T@transform[:3,:3]).as_rotvec(),
                        .001*(q-previous)]
                solution=least_squares(residual,previous,bounds=(arm.low,arm.high),max_nfev=120)
                if np.linalg.norm(residual(solution.x)[:6])>.004 or np.max(abs(solution.x-previous))>.22:
                    raise RuntimeError('Closure cannot continue from actual arm configuration')
                actual_path.append(solution.x)
            path=np.array(actual_path)
            contact_start=[None]
            def opposed_load():
                effort=state.get('effort',[])
                if plan.get('local_patch') and any(v>1.2 or v<-.15 for v in state.get('position',[])):
                    robot.hand(plan['open_hand'],side)
                    raise RuntimeError('Abnormal finger deflection; likely unintended collision, grasp stopped')
                loaded=len(effort)==6 and max(effort[:4])>.25 and effort[4]>.20
                if not loaded:contact_start[0]=None;return False
                if contact_start[0] is None:contact_start[0]=robot.sim_time
                return robot.sim_time-contact_start[0]>.2
            arm.move(path[-1],'close with contact-center compensation',speed=.15,settle=3.,
                     path=path,hand_commands=(plan['closure_commands'],side),stop_on_contact=opposed_load,min_duration=4. if plan.get('local_patch') else 1.)
            snapshot('pool2-closed')
        elif args.stage=='hold':
            arm.move(arm.current(),'hold object still',speed=.3,settle=2.)
            wait_sim(2)
            snapshot('pool2-held')
        elif args.stage=='release':
            robot.hand([1.,1.,1.,1.,.95,.12],side)
            wait_sim(2)
            snapshot('pool2-released')
        elif args.stage=='recover':
            arm.move(np.array(plan['q_above']),'raise open hand to validated clear pose',speed=.25,settle=3.)
            snapshot('pool2-recovered')
        elif args.stage=='home':
            start=json.loads(Path('/nssr_sim/logs/pool2-arm-start.json').read_text())
            neutral=np.zeros(7)
            clear=neutral.copy(); clear[1]=1.0 if side=='left' else -1.0; clear[3]=-1.6
            arm.move(clear,'move bent arm outside table',speed=.45)
            spread=neutral.copy(); spread[1]=1.0 if side=='left' else -1.0
            arm.move(spread,'unfold arm outside table',speed=.45)
            arm.move(neutral,'return free arm behind table',speed=.45)
            waist(0.)
            snapshot('pool2-home')
        else:
            away=arm.transform(arm.current())[:3,3]+rotation[:,2]*.15
            arm.cartesian(away,rotation,'withdraw open hand',speed=.3)
            normal=np.array(plan['target']['support_normal_pelvis'])
            support=np.array(plan['target']['approximate_body_center_pelvis_m'])-normal*plan['target']['height_above_observed_table_m']/2
            extra=max(0.,.32-float(np.dot(away-support,normal)))
            if extra>.005:
                arm.cartesian(away+normal*extra,rotation,'raise hand away',speed=.4)
            start=json.loads(Path('/nssr_sim/logs/pool2-arm-start.json').read_text())
            clear=np.array(start['angles']); clear[1]=1.0 if side=='left' else -1.0; clear[3]=-1.6
            arm.move(clear,'move bent arm outside table',speed=.4)
            spread=np.array(start['angles']); spread[1]=1.0 if side=='left' else -1.0
            arm.move(spread,'unfold arm outside table',speed=.4)
            arm.move(np.array(start['angles']),'return arm to initial pose',speed=.45)
            snapshot('pool2-retreated')
    finally:
        robot.destroy_node(); rclpy.shutdown()


if __name__=='__main__':
    main()
