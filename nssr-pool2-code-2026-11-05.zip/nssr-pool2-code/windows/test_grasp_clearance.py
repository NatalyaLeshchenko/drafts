import unittest
import numpy as np
from grasp_clearance import approach_envelope,object_clearance,open_hand_hits_surface


class SweepTests(unittest.TestCase):
    def test_other_strand_inside_open_finger_is_rejected(self):
        from itertools import product
        hulls={'finger':np.array(list(product((-.01,.01),repeat=3)))}
        position=np.array([0.,0.,.1])
        self.assertTrue(open_hand_hits_surface(hulls,np.eye(3),position+.1,position+.05,position,[[0,0,.1]]))
        self.assertFalse(open_hand_hits_surface(hulls,np.eye(3),position+.1,position+.05,position,[[.2,0,.1]]))

    def test_hand_volume_crosses_neighbour_even_when_tcp_misses(self):
        obj=dict(approximate_body_center_pelvis_m=[0,0,.1],yaw_deg_mod_180=0,
                 visible_footprint_dimensions_m=[.04,.04],height_above_observed_table_m=.2)
        hand=np.array([[0,-.08,0],[0,.08,0]])
        sweep=approach_envelope(hand,np.eye(3),np.array([-.1,.08,.3]),
                                np.array([-.1,.08,.1]),np.array([.1,.08,.1]))
        self.assertLess(object_clearance(sweep,obj,[0,0,1]),0)
        self.assertGreater(object_clearance(sweep+np.array([0,0,.25]),obj,[0,0,1]),0)


if __name__=='__main__':unittest.main()
