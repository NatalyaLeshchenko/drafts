"""Coordinated, anchored dance poses; values are offsets in radians."""


def choreography():
    ready = {11: -0.25, 12: 0.55, 14: -0.90,
             21: -0.25, 22: -0.55, 24: -0.90}

    def pose(changes, bend=0.0):
        result = dict(ready)
        result.update(changes)
        # Fixed pelvis: large knee flexion lifts the feet, so keep it subtle.
        bend = min(bend, 0.05)
        result.update({52: -bend / 2, 54: bend, 55: -bend / 2,
                       62: -bend / 2, 64: bend, 65: -bend / 2})
        return result

    left = pose({11: -0.90, 12: 1.05, 14: -0.45,
                 21: -0.15, 22: -0.35, 24: -1.20,
                 31: 0.18, 3: 0.20, 1: -0.045}, 0.12)
    right = pose({21: -0.90, 22: -1.05, 24: -0.45,
                  11: -0.15, 12: 0.35, 14: -1.20,
                  31: -0.18, 3: -0.20, 1: 0.045}, 0.12)
    # No sideways leg swing or knee lifts. Preserve the initial foot pitch.
    left.update({51: 0.0, 52: -0.025, 53: 0.0, 54: 0.05, 55: -0.025, 56: 0.0,
                 61: 0.0, 62: -0.01, 63: 0.0, 64: 0.02, 65: -0.01, 66: 0.0})
    right.update({61: 0.0, 62: -0.025, 63: 0.0, 64: 0.05, 65: -0.025, 66: 0.0,
                  51: 0.0, 52: -0.01, 53: 0.0, 54: 0.02, 55: -0.01, 56: 0.0})
    accent = pose({11: -0.65, 12: 1.10, 14: -1.15,
                   21: -0.65, 22: -1.10, 24: -1.15, 2: 0.08}, 0.22)
    wave = pose({21: -0.55, 22: -1.15, 24: -1.35,
                 31: -0.10, 3: -0.18})
    return [
        (1.4, ready, 'ready'),
        (0.85, left, 'left knee and arm'), (0.85, right, 'right knee and arm'),
        (0.85, left, 'left knee and arm'), (0.85, right, 'right knee and arm'),
        (0.75, accent, 'accent'), (0.55, ready, 'release'),
        (0.85, left, 'left knee and arm'), (0.85, right, 'right knee and arm'),
        (0.95, wave, 'raise hand'),
        (0.55, wave | {27: 0.25}, 'wave out'),
        (0.65, wave | {27: -0.25}, 'wave in'),
        (0.55, wave | {27: 0.20}, 'wave out'),
        (0.8, ready, 'finish'), (1.4, {}, 'return'),
    ]


def prepare(original, limits, names, speed_limit=1.3, leg_solver=None):
    previous = dict(original)
    segments = []
    for requested_duration, offsets, label in choreography():
        target = {}
        for motor, initial in original.items():
            low, high = limits[names[motor]]
            target[motor] = max(low, min(high, initial + offsets.get(motor, 0.0)))
        if leg_solver is not None:
            target.update(leg_solver.targets(label))
        # The quintic transition has peak speed 1.875 * distance / duration.
        duration = max(requested_duration,
                       1.875 * max(abs(target[k] - previous[k]) for k in original) / speed_limit)
        segments.append((duration, previous, target, label))
        previous = target
    return segments


def sample(segments, elapsed):
    for duration, start, end, label in segments:
        if elapsed <= duration:
            u = max(0.0, min(1.0, elapsed / duration))
            blend = u ** 3 * (10 - 15 * u + 6 * u * u)
            return {k: start[k] + blend * (end[k] - start[k]) for k in start}, label
        elapsed -= duration
    return dict(segments[-1][2]), 'complete'
