"""Record public ROS RGB-D sensors on randomized pool-2 layouts (development only)."""
import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from rclpy.time import Time
from sensor_msgs.msg import Image, CameraInfo, JointState
from std_msgs.msg import String, Int32
from rosgraph_msgs.msg import Clock
from bodyctrl_msgs.msg import CmdSetMotorPosition, SetMotorPosition
from tf2_ros import Buffer, TransformListener


def stamp(msg):
    return msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9


class Recorder(Node):
    def __init__(self,allow_randomize=True):
        super().__init__('pool2_dataset_recorder')
        self.images, self.info, self.joints = {}, {}, {}
        self.task, self.names, self.now = {}, {}, None
        self.subs = []
        for camera in ('head', 'torso'):
            for kind in ('color', 'depth'):
                key = f'{camera}_{kind}'
                self.subs.append(self.create_subscription(Image, f'/cam_{camera}/{kind}/image_raw',
                    lambda m, k=key: self.images.__setitem__(k, m), 2))
            for kind in ('color', 'depth'):
                key = f'{camera}_{kind}'
                self.subs.append(self.create_subscription(CameraInfo, f'/cam_{camera}/{kind}/camera_info',
                    lambda m, k=key: self.info.__setitem__(k, m), 2))
        qos = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                         reliability=ReliabilityPolicy.RELIABLE)
        self.subs.append(self.create_subscription(String, '/sim/task',
            lambda m: setattr(self, 'task', json.loads(m.data)), qos))
        self.subs.append(self.create_subscription(String, '/sim/objects/names',
            lambda m: setattr(self, 'names', json.loads(m.data)), qos))
        self.subs.append(self.create_subscription(JointState, '/joint_states',
            lambda m: self.joints.update(zip(m.name, m.position)), 10))
        self.subs.append(self.create_subscription(Clock, '/clock',
            lambda m: setattr(self, 'now', m.clock.sec + m.clock.nanosec * 1e-9), 10))
        self.head = self.create_publisher(CmdSetMotorPosition, '/head/cmd_pos', 10)
        self.randomize = self.create_publisher(Int32, '/sim/objects/randomize', 10) if allow_randomize else None
        self.tf = Buffer()
        self.listener = TransformListener(self.tf, self)

    def wait(self, seconds):
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            rclpy.spin_once(self, timeout_sec=.05)

    def capture(self, folder, seed, yaw):
        deadline = time.monotonic() + 25
        while True:
            self.wait(.2)
            try:
                if len(self.images) != 4 or len(self.info) != 4 or self.now is None:
                    raise ValueError('waiting for both RGB-D streams and calibration')
                if abs(self.joints.get('head_yaw_joint', 999) - yaw) > .02:
                    raise ValueError('waiting for head yaw feedback to settle')
                stamps = [stamp(m) for m in self.images.values()]
                if max(stamps) - min(stamps) > .08 or self.now - min(stamps) > .5:
                    raise ValueError('waiting for fresh, approximately synchronized frames')
                transforms = {}
                for camera in ('head', 'torso'):
                    m = self.images[f'{camera}_color']
                    t = self.tf.lookup_transform('pelvis', m.header.frame_id,
                        Time(seconds=m.header.stamp.sec, nanoseconds=m.header.stamp.nanosec))
                    transforms[camera] = {
                        'target': 'pelvis', 'source': m.header.frame_id,
                        'translation': [t.transform.translation.x, t.transform.translation.y, t.transform.translation.z],
                        'quaternion_xyzw': [t.transform.rotation.x, t.transform.rotation.y,
                                            t.transform.rotation.z, t.transform.rotation.w],
                        'stamp': stamp(t)}
                break
            except Exception as exc:
                if time.monotonic() > deadline:
                    raise RuntimeError(f'Cannot capture calibrated sensors: {exc}') from exc
        folder.mkdir(parents=True, exist_ok=False)
        metadata = {'seed': seed, 'split': 'unassigned' if seed is None else ('validation' if seed >= 100000 else 'train'),
                    'head_yaw_target': yaw, 'sim_time': self.now, 'task': self.task,
                    'object_names': self.names, 'joint_positions': self.joints.copy(),
                    'transforms': transforms, 'cameras': {}}
        for camera in ('head', 'torso'):
            for kind in ('color', 'depth'):
                key = f'{camera}_{kind}'
                m, info = self.images[key], self.info[key]
                rows = np.frombuffer(bytes(m.data), np.uint8).reshape(m.height, m.step)
                if kind == 'color':
                    if m.encoding not in ('rgb8', 'bgr8'):
                        raise ValueError(f'Unexpected color encoding: {m.encoding}')
                    pixels = rows[:, :m.width * 3].reshape(m.height, m.width, 3)
                    if m.encoding == 'rgb8':
                        pixels = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
                else:
                    if m.encoding != '16UC1':
                        raise ValueError(f'Unexpected depth encoding: {m.encoding}')
                    dtype = np.dtype('>u2' if m.is_bigendian else '<u2')
                    pixels = rows[:, :m.width * 2].copy().view(dtype).reshape(m.height, m.width).astype(np.uint16)
                if not cv2.imwrite(str(folder / f'{key}.png'), pixels):
                    raise RuntimeError(f'Failed writing {key}')
                metadata['cameras'][key] = {'stamp': stamp(m), 'frame': m.header.frame_id,
                    'encoding': m.encoding, 'width': m.width, 'height': m.height,
                    'K': list(info.k), 'D': list(info.d), 'P': list(info.p),
                    'distortion_model': info.distortion_model,
                    'depth_unit': 'millimetres' if kind == 'depth' else None,
                    'valid_depth_fraction': float(np.mean(pixels > 0)) if kind == 'depth' else None}
        (folder / 'metadata.json').write_text(json.dumps(metadata, indent=2))
        print(json.dumps({'saved': str(folder), 'seed': seed, 'yaw': yaw}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='/nssr_sim/datasets/pool2_stage1')
    parser.add_argument('--seeds', nargs='+', type=int, default=[11, 29, 47, 83, 137, 251, 419, 761, 100003, 100019, 100043, 100069])
    args = parser.parse_args()
    root = Path(args.output)
    if root.exists():
        raise RuntimeError('Output directory already exists; choose a new --output to preserve captures')
    rclpy.init()
    node = Recorder()
    try:
        deadline = time.monotonic() + 150
        while node.task.get('task') != 'sort2' or node.task.get('objects_from') != 'pool 2':
            node.wait(.5)
            if time.monotonic() > deadline:
                raise RuntimeError(f'Waiting for sort2 pool 2 timed out; last task: {node.task}')
        root.mkdir(parents=True)
        for seed in args.seeds:
            if node.randomize.get_subscription_count() == 0:
                raise RuntimeError('Development randomization subscriber is unavailable')
            node.randomize.publish(Int32(data=seed))
            node.wait(7)
            for view, yaw in enumerate((0., -.30, .30)):
                node.head.publish(CmdSetMotorPosition(cmds=[
                    SetMotorPosition(name=1, pos=0., spd=.5, cur=1.),
                    SetMotorPosition(name=2, pos=.40, spd=.5, cur=1.),
                    SetMotorPosition(name=3, pos=yaw, spd=.5, cur=1.)]))
                node.wait(4)
                node.capture(root / f'seed_{seed}_view_{view}', seed, yaw)
        (root / 'COMPLETE.json').write_text(json.dumps({'seeds': args.seeds,
            'captures': len(args.seeds) * 3, 'rgb_images': len(args.seeds) * 6}, indent=2))
        print('Collection complete', flush=True)
    finally:
        node.head.publish(CmdSetMotorPosition(cmds=[SetMotorPosition(name=3, pos=0., spd=.5, cur=1.)]))
        node.wait(.2)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
