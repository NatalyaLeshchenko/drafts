import rclpy
from manipulation import Robot

rclpy.init()
robot = Robot()
try:
    robot.spin(4)
    robot.command('head', {1: 0.0, 2: 0.40, 3: 0.0})
    robot.command('waist', {31: 0.0})
    robot.spin(5)
    robot.save()
finally:
    robot.destroy_node()
    rclpy.shutdown()
