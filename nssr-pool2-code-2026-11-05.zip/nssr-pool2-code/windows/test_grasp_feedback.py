import unittest
from grasp_feedback import PayloadGuard


class FeedbackTests(unittest.TestCase):
    def test_persistent_unloaded_hand_stops(self):
        g=PayloadGuard([0,0,8])
        self.assertFalse(g.update(0,[0,0,2],[.05]*6))
        self.assertTrue(g.update(.4,[0,0,2],[.05]*6))

    def test_brief_force_change_or_opposing_load_does_not_stop(self):
        g=PayloadGuard([0,0,8])
        self.assertFalse(g.update(0,[0,0,2],[.05]*6))
        self.assertFalse(g.update(.2,[0,0,7],[.05]*6))
        self.assertFalse(g.update(.8,[0,0,2],[.5]*6))


if __name__=='__main__':unittest.main()
