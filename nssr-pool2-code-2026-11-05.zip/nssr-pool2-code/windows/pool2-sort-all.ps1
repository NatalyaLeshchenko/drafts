﻿param([ValidateRange(1,6)][int]$MaxObjects=6,[ValidateSet('right-to-left','left-to-right','height')][string]$Order='right-to-left')
$ErrorActionPreference='Stop'
$workspaceRoot=Split-Path $PSScriptRoot
$logs=Join-Path $workspaceRoot 'nssr-uwt-polygon\logs'
$python=Join-Path $env:USERPROFILE 'isaac-win\Scripts\python.exe'
$env:PYTHONUTF8='1'
$run=Join-Path $logs ('sort-all-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $run -Force | Out-Null
for ($index=0;$index -lt $MaxObjects;$index++) {
    & (Join-Path $workspaceRoot 'vision\vision.ps1') -Action Observe
    if ($LASTEXITCODE -ne 0) { throw 'Observation failed; no new grasp started.' }
    & $python (Join-Path $workspaceRoot 'vision\select_pool2_target.py') --all-objects --allow-experimental --order $Order
    if ($LASTEXITCODE -ne 0) { throw 'Target selection failed.' }
    $choice=Get-Content (Join-Path $logs 'pool2-next-target.json') -Raw | ConvertFrom-Json
    if (!$choice.selected) {
        Copy-Item (Join-Path $logs 'pool2-next-target.json') (Join-Path $run 'stopped-selection.json')
        if ($choice.blocked_edge) {
            throw "Order preserved: edge object $($choice.blocked_edge.object) requires recovery ($($choice.blocked_edge.reason)). No middle object was attempted."
        }
        Write-Output 'No reliable unsorted target; inspect report. This does not imply all six are sorted.'
        return
    }
    $target=$null
    Copy-Item (Join-Path $choice.observation 'objects_fused.json') (Join-Path $logs 'pool2-targets.json')
    foreach ($candidate in @($choice.selected)) {
        $objectName=$candidate.object; $side=$candidate.side
        $rollArg=if ($candidate.palm_roll -eq 'auto') { '' } else { '--palm-roll '+$candidate.palm_roll }
        docker exec nssr-ros-win bash -lc "source /opt/ros/humble/setup.bash && python3 /windows-support/plan_pool2_grasp.py --object $objectName --side $side $rollArg 2>&1"
        if ($LASTEXITCODE -eq 0) { $target=$candidate; break }
        Copy-Item (Join-Path $logs 'pool2-grasp-plan.json') (Join-Path $run ("rejected-$index-$objectName.json"))
    }
    if (!$target) { throw 'The next edge object has no feasible grasp. Order preserved; do not reach through the middle.' }
    Write-Output "SORT $index : $($target.object)"
    try {
        & (Join-Path $PSScriptRoot 'pool2-pick-and-place.ps1') -Object $target.object -Side $target.side -PalmRoll $target.palm_roll -ReuseObservation -ReusePlan
        if ($LASTEXITCODE -ne 0) { throw 'Pick and place failed.' }
    } finally {
        $evidence=Join-Path $run ("$index-"+$target.object)
        New-Item -ItemType Directory -Path $evidence -Force | Out-Null
        Get-ChildItem -LiteralPath $logs -File -Filter 'pool2-*' | Copy-Item -Destination $evidence
    }
}
Write-Output 'Requested number of attempts completed; assess scene before declaring full sorting.'
