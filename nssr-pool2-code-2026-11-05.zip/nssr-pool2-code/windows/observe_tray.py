"""Observe the destination using public cameras and task metadata only."""
import json,time
from pathlib import Path
import rclpy
from std_msgs.msg import String
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from manipulation import Robot

rclpy.init()
r=Robot(); task={}
qos=QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL,reliability=ReliabilityPolicy.RELIABLE)
sub=r.create_subscription(String,'/sim/task',lambda m:task.update(json.loads(m.data)),qos)
try:
    r.spin(2)
    plan=json.loads(Path('/nssr_sim/logs/pool2-grasp-plan.json').read_text())['selected']
    if not task: raise RuntimeError('No task metadata')
    destination=task['categories'][plan['target']['category']]
    yaw=.95 if destination=='tray_left' else -.95
    deadline=time.monotonic()+20
    while True:
        r.command('head',{1:0.,2:.42,3:yaw})
        r.spin(.2)
        if all(abs(r.joints.get(n,99)-v)<.025 for n,v in
               [('head_roll_joint',0.),('head_pitch_joint',.42),('head_yaw_joint',yaw)]): break
        if time.monotonic()>deadline:
            raise RuntimeError('Head did not reach destination view: '+str({n:v for n,v in r.joints.items() if n.startswith('head_')}))
    r.spin(1)
    r.save('pool2-destination')
    Path('/nssr_sim/logs/pool2-delivery-task.json').write_text(json.dumps(task,indent=2))
    print(json.dumps({'task':task,'body_joints':{n:v for n,v in r.joints.items() if 'body' in n},'body_limits':{n:v for n,v in r.kinematics.limits.items() if 'body' in n}}),flush=True)
finally:
    r.destroy_node(); rclpy.shutdown()


