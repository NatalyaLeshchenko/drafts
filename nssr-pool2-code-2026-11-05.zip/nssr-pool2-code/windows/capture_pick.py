import sys
import rclpy
from manipulation import Robot

rclpy.init()
robot = Robot()
try:
    robot.spin(3)
    if not robot.joints:
        raise RuntimeError('No fresh robot state received')
    robot.save(sys.argv[1] if len(sys.argv) > 1 else 'sugar-current')
finally:
    robot.destroy_node()
    rclpy.shutdown()
