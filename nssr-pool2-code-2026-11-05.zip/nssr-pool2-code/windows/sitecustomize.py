"""Local transport adapter for the Windows simulator and container ROS bridge.

Only changes transport addresses, never robot state or task rules.
"""
import os

def install():
    if not (os.environ.get("NSSR_SIM_HOST") or os.environ.get("NSSR_BIND_LOOPBACK") == "1"):
        return
    import zmq

    if getattr(zmq.Socket, "_nssr_transport_installed", False):
        return

    _connect = zmq.Socket.connect
    _bind = zmq.Socket.bind

    def _local_connect(self, address, *args, **kwargs):
        host = os.environ.get("NSSR_SIM_HOST")
        if host and address in ("tcp://127.0.0.1:5556", "tcp://127.0.0.1:5557"):
            address = address.replace("127.0.0.1", host)
        return _connect(self, address, *args, **kwargs)

    def _local_bind(self, address, *args, **kwargs):
        if os.environ.get("NSSR_BIND_LOOPBACK") == "1" and address.startswith("tcp://*:"):
            address = address.replace("tcp://*:", "tcp://127.0.0.1:", 1)
        return _bind(self, address, *args, **kwargs)

    zmq.Socket.connect = _local_connect
    zmq.Socket.bind = _local_bind
    zmq.Socket._nssr_transport_installed = True


install()
