"""Locate the sugar box in the demo's right table area using RGB-D and known box height."""
import json
from pathlib import Path
import cv2
import numpy as np

folder = Path('/nssr_sim/logs')
metadata = json.loads((folder / 'sugar-baseline.json').read_text())
depth = np.load(folder / 'sugar-baseline-depth.npz')['head_depth']
camera = metadata['cameras']['head']
transform = np.array(camera['transform'])
intrinsic = np.array(camera['k']).reshape(3, 3)
v, u = np.mgrid[:depth.shape[0], :depth.shape[1]]
rays = np.stack(((u - intrinsic[0, 2]) / intrinsic[0, 0],
                 (v - intrinsic[1, 2]) / intrinsic[1, 1], np.ones_like(u)), -1)
world_rays = rays @ transform[:3, :3].T
points = rays * (depth / 1000.)[:, :, None] @ transform[:3, :3].T + transform[:3, 3]
plane_points = points[(u > 100) & (u < 600) & (v > 115) & (v < 235) & (depth > 0)]
for _ in range(5):
    design = np.c_[plane_points[:, :2], np.ones(len(plane_points))]
    plane = np.linalg.lstsq(design, plane_points[:, 2], rcond=None)[0]
    plane_points = plane_points[abs(plane_points[:, 2] - design @ plane) < .008]
relative_height = (points[:, :, 2] - plane[0] * points[:, :, 0] - plane[1] * points[:, :, 1] - plane[2]) / np.sqrt(1 + np.sum(plane[:2] ** 2))
mask = ((u > 480) & (u < 585) & (v > 240) & (v < 345) &
        (relative_height > .164) & (relative_height < .187))
if mask.sum() < 100:
    raise RuntimeError('Sugar top face was not found in the expected demo area')
# Recover metric XY from RGB rays and the known top elevation. Depth selects the
# surface; it is not used as the final metric range because its bias was measured.
top_z = -.180 + .176
surface = transform[:3, 3] + world_rays * ((top_z - transform[2, 3]) / world_rays[:, :, 2])[:, :, None]
rectangle = cv2.minAreaRect(surface[mask, :2].astype(np.float32))
sizes = sorted(rectangle[1])
if not (.025 < sizes[0] < .065 and .07 < sizes[1] < .125):
    raise RuntimeError(f'Detected surface does not match the sugar box: {sizes}')
estimate = {'center_xy': list(rectangle[0]), 'size_xy': list(rectangle[1]),
            'angle_deg': rectangle[2], 'top_z': top_z, 'height': .176,
            'method': 'RGB rays, depth-selected top face, known tabletop and box height',
            'top_face_pixels': int(mask.sum())}
(folder / 'sugar-estimate.json').write_text(json.dumps(estimate, indent=2))
print(json.dumps(estimate), flush=True)
