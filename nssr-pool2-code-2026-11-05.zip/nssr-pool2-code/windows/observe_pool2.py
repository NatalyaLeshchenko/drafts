"""Observe the current pool-2 scene using sensors; do not reset/randomize or move arms."""
import argparse
import time
from pathlib import Path
import rclpy
from bodyctrl_msgs.msg import CmdSetMotorPosition,SetMotorPosition
from collect_pool2 import Recorder


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError('Output already exists; select a new observation directory')
    rclpy.init()
    node = Recorder(allow_randomize=False)
    original = None
    try:
        deadline = time.monotonic()+45
        while not node.task or not node.joints:
            node.wait(.2)
            if time.monotonic()>deadline:
                raise RuntimeError('No task or robot state: start the simulator first')
        if node.task.get('task')!='sort2' or node.task.get('objects_from')!='pool 2':
            raise RuntimeError('Expected sort2 pool 2; observation will not change the task')
        original = [node.joints[f'head_{axis}_joint'] for axis in ('roll','pitch','yaw')]
        views=((0.,.4,0.),(-.3,.4,0.),(.3,.4,0.),(-.55,.43,-.35),(.55,.43,.35),(-.55,.43,.35),(.55,.43,-.35))
        for view,(yaw,pitch,roll) in enumerate(views):
            node.head.publish(CmdSetMotorPosition(cmds=[
                SetMotorPosition(name=i+1,pos=value,spd=.5,cur=1.)
                for i,value in enumerate((roll,pitch,yaw))]))
            deadline=time.monotonic()+60
            while max(abs(node.joints.get('head_'+axis+'_joint',999)-value) for axis,value in zip(('roll','pitch','yaw'),(roll,pitch,yaw)))>.025:
                if time.monotonic()>deadline:raise RuntimeError('Head feedback did not reach the requested view')
                node.wait(.2)
            node.wait(1)
            node.capture(args.output/f'observed_view_{view}',None,yaw)
        print(f'Observation saved: {args.output}',flush=True)
    finally:
        if original is not None:
            node.head.publish(CmdSetMotorPosition(cmds=[SetMotorPosition(name=i+1,pos=value,spd=.5,cur=1.) for i,value in enumerate(original)]))
            node.wait(.5)
        node.destroy_node()
        rclpy.shutdown()


if __name__=='__main__':
    main()
