"""Robot-only hand geometry, using the simulator's public command convention."""
import json
from pathlib import Path
import numpy as np

BOUNDS=json.loads(Path(__file__).with_name('robot-hand-mesh-bounds.json').read_text())
HULL_PATH=Path(__file__).with_name('robot-hand-collision-hulls.json')
HULLS=json.loads(HULL_PATH.read_text()) if HULL_PATH.exists() else BOUNDS

def commanded_joints(side,values,base):
    joints=dict(base)
    for i,finger in enumerate(('little','ring','middle','index')):
        angle=-1.333*(1-values[i])
        joints[f'{side}_{finger}_1_joint']=angle
        joints[f'{side}_{finger}_2_joint']=angle*1.1169
    sign=-1 if side=='left' else 1
    joints[f'{side}_thumb_1_joint']=-sign*1.246165*(1-values[5])
    joints[f'{side}_thumb_2_joint']=sign*.48*(1-values[4])
    joints[f'{side}_thumb_3_joint']=-.48*(1-values[4])*1.1425
    joints[f'{side}_thumb_4_joint']=joints[f'{side}_thumb_3_joint']*.7508
    return joints

def envelopes_tcp(k,side,joints,collision=False):
    inverse=np.linalg.inv(k.transform(side+'_tcp_link',joints));result={}
    for body,corners in (HULLS if collision else BOUNDS).items():
        if '/hand'+side not in body:continue
        t=inverse@k.actual_transform(body,joints)
        result[body]=np.array(corners)@t[:3,:3].T+t[:3,3]
    return result


def flat_hand_geometry(k, side, base, required_width, max_contact_height=None):
    """Select aperture/tilt using collision hulls, not a semantic object name."""
    from scipy.spatial.transform import Rotation
    candidates=[]
    closed=np.array([0.]*4+[.05,.12])
    for aperture in (.4,.6,.8,1.):
        opened=np.array([aperture]*4+[.95,.12]);states=[]
        for blend in np.linspace(0,1,9):
            command=opened*(1-blend)+closed*blend
            joints=commanded_joints(side,command,base)
            boxes=envelopes_tcp(k,side,joints)
            thumb=boxes[k.aliases[side+'_thumb_4']].mean(0)
            index=boxes[k.aliases[side+'_index_2']].mean(0)
            hulls=envelopes_tcp(k,side,joints,collision=True)
            states.append(((thumb+index)/2,thumb-index,hulls))
        midpoint,axis,hulls=states[0];axis=axis/np.linalg.norm(axis)
        gap=(hulls[k.aliases[side+'_thumb_4']]@axis).min()-(hulls[k.aliases[side+'_index_2']]@axis).max()
        if gap<required_width+.006:continue
        for degrees in range(-80,81,5):
            base_rotation=Rotation.from_euler('x',degrees,degrees=True).as_matrix()
            gap_axis=base_rotation@states[0][1]
            if abs(gap_axis[2])>.015:continue
            gap_axis/=np.linalg.norm(gap_axis)
            for roll in (-60,-40,-20,0,20,40,60):
                rotation=Rotation.from_rotvec(gap_axis*np.deg2rad(roll)).as_matrix()@base_rotation
                bottom=min(((np.concatenate(list(h.values()))-m)@rotation.T)[:,2].min() for m,_,h in states)
                candidates.append((float(bottom),-aperture,rotation,opened,closed,states,float(gap)))
    if not candidates:raise ValueError('No measured finger aperture fits observed width')
    feasible=[c for c in candidates if max_contact_height is not None and c[0]+max_contact_height>=.006]
    # Prefer less wrist twist once clearance fits, rather than the maximum theoretical clearance.
    if feasible:
        def posture_cost(c):
            axis=c[2]@np.array([1.,0.,0.])
            return abs(axis[2]),-c[1],-c[0]
        best=min(feasible,key=posture_cost)
    else:best=max(candidates,key=lambda c:c[:2])
    return best

if __name__=='__main__':
    from manipulation import Kinematics
    k=Kinematics();base=json.loads(Path('/nssr_sim/logs/pool2-before-grasp-grip.json').read_text())['joints']
    for side in ('left','right'):
        for values in ([1.,1.,1.,1.,.95,.12],[.18,.18,.18,.18,.35,.12],[0.,0.,0.,0.,.05,.12],[0.,0.,0.,0.,.5,.12]):
            joints=commanded_joints(side,values,base);envelopes=envelopes_tcp(k,side,joints)
            centers={finger:envelopes[k.aliases[f'{side}_{finger}']].mean(0) for finger in ('thumb_4','index_2','middle_2')}
            midpoint=(centers['thumb_4']+centers['index_2'])/2
            print(json.dumps({'side':side,'command':values,'mesh_min_z':float(np.concatenate(list(envelopes.values()))[:,2].min()),'tip_centers':{n:v.tolist() for n,v in centers.items()},'pinch_center':midpoint.tolist()}),flush=True)
